package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Пистолет Балкера: ПКМ - выстрел (7 урона по прямой, 40 блоков). Подкат - на G. */
public class BalkerPistolItem extends Item {
    public BalkerPistolItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) {
            // Клиентский откат: по нему же рендерер играет ход затвора и отдачу.
            // Сервер откат ставит сам (после успешного выстрела), клиент - сразу по клику.
            user.getItemCooldownManager().set(this, 15);
            return TypedActionResult.pass(stack);
        }
        if (user instanceof ServerPlayerEntity sp && Balker.shoot(sp)) {
            sp.getItemCooldownManager().set(this, 15);
            return TypedActionResult.success(stack);
        }
        return TypedActionResult.fail(stack);
    }
}

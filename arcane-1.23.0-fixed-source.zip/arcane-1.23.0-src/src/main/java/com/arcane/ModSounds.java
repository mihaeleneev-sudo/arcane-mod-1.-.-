package com.arcane;

import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * Звуки мода. Регистрации в реестре в 1.20.1 нет: событие создаётся по пути
 * "arcane:имя", а сам файл ищется в assets/arcane/sounds.json -> assets/arcane/sounds/...
 */
public final class ModSounds {
    /** Выстрел из пистолета Балкера. */
    public static final SoundEvent PISTOL_SHOT = SoundEvent.of(new Identifier(ArcaneMod.MOD_ID, "pistol_shot"));
    /** Извлечение пистолета (щёлки затвора). */
    public static final SoundEvent PISTOL_DRAW = SoundEvent.of(new Identifier(ArcaneMod.MOD_ID, "pistol_draw"));
    /** Извлечение трости. */
    public static final SoundEvent CANE_DRAW = SoundEvent.of(new Identifier(ArcaneMod.MOD_ID, "cane_draw"));
    /** Извлечение рации. */
    public static final SoundEvent RADIO_DRAW = SoundEvent.of(new Identifier(ArcaneMod.MOD_ID, "radio_draw"));

    private ModSounds() {}
}

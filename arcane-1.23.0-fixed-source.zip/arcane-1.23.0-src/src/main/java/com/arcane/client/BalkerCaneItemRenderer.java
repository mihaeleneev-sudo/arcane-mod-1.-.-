package com.arcane.client;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * 3D-рендер трости Балкера: тёмное дерево с латунными кольцами, чёрный навершник с изумрудом.
 * При извлечении (NBT DrawStart/DrawDur) трость поднимается, при вращении (клавиша G, NBT SpinUntil)
 * вокруг своей оси - быстро крутится.
 */
public class BalkerCaneItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/balker_cane.png");

    private static EntityModelLoader loader;
    private static ModelPart cane;

    public static void setLoader(EntityModelLoader l) {
        loader = l;
        cane = null;
    }

    private static boolean ensureModels() {
        if (loader == null) return false;
        if (cane == null) cane = loader.getModelPart(BalkerCaneModel.LAYER);
        return true;
    }

    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack m,
                       VertexConsumerProvider vcp, int light, int overlay) {
        if (!ensureModels()) return;
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean first = mode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;

        m.push();
        m.translate(0.5f, 0.5f, 0.5f);   // отменяем сдвиг центра предмета: начало координат - рука

        if (first && mc.player != null) {
            float td = mc.getTickDelta();
            float side = mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1.0f : 1.0f;

            float sway = MathHelper.sin((mc.player.age + td) * 0.07f) * 0.006f;
            m.translate(-0.07f, 0.10f + sway, -0.02f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 10.0f));
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -7.0f));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-5.0f));
            m.scale(0.5f, 0.5f, 0.5f);

            // извлечение: трость поднимается снизу
            float draw = BalkerWeaponFx.drawProgress(stack, mc);
            if (draw < 1.0f) {
                float k = 1.0f - BalkerWeaponFx.easeOutBack(draw);
                m.translate(0.0f, -0.35f * k, 0.12f * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-50.0f * k));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-18.0f * k));
            }
        } else if (mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
            m.translate(0.0f, -0.10f, -0.05f);
            m.scale(0.45f, 0.45f, 0.45f);
        } else if (mode == ModelTransformationMode.GUI) {
            m.scale(0.34f, 0.34f, 0.34f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(16.0f));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-38.0f));
            m.translate(0.0f, -0.42f, 0.0f);
        } else {
            m.scale(0.34f, 0.34f, 0.34f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-38.0f));
            m.translate(0.0f, -0.42f, 0.0f);
        }

        // вращение (клавиша G): трость крутится вокруг своей оси
        ModelPart shaft = cane.getChild("shaft");
        shaft.yaw = 0.0f;
        NbtCompound n = stack.getNbt();
        if (n != null && n.contains("SpinUntil") && mc.world != null) {
            long now = mc.world.getTime();
            long until = n.getLong("SpinUntil");
            if (now < until) {
                shaft.yaw = ((now % 8) / 8.0f) * 360.0f;
            }
        }

        cane.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), light, OverlayTexture.DEFAULT_UV);
        m.pop();
    }
}

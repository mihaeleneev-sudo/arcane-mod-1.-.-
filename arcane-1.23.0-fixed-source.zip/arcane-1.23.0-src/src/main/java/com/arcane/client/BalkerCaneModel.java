package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

/**
 * 3D-модель трости Балкера: тёмное дерево, латунные кольца и наконечник,
 *  * чёрный лаковый навершник с изумрудным камнем (WA Corporation).
 *  * При вращении (клавиша G) трость крутится вокруг своей оси.
 * Р¤Р°Р№Р» СЃРіРµРЅРµСЂРёСЂРѕРІР°РЅ: РґРµС‚Р°Р»Рё, UV-РєРѕРѕСЂРґРёРЅР°С‚С‹ Рё С‚РµРєСЃС‚СѓСЂР° assets/arcane/textures/entity/balker_cane.png СЃРѕРіР»Р°СЃРѕРІР°РЅС‹ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё.
 * РЎРёСЃС‚РµРјР° РєРѕРѕСЂРґРёРЅР°С‚: x РІРїСЂР°РІРѕ, y РІРІРµСЂС…, z РЅР°Р·Р°Рґ, СЃС‚РІРѕР» СЃРјРѕС‚СЂРёС‚ РІ -z, РЅР°С‡Р°Р»Рѕ Сѓ СЂСѓРєРѕСЏС‚Рё; РµРґРёРЅРёС†С‹ - 1/16 Р±Р»РѕРєР°.
 */
public final class BalkerCaneModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "balker_cane"), "main");

    private BalkerCaneModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_shaft = root.addChild("shaft",
                ModelPartBuilder.create().uv(0, 0).cuboid(-0.5f, -20.0f, -0.5f, 1.0f, 20.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_collar = p_shaft.addChild("collar",
                ModelPartBuilder.create().uv(4, 0).cuboid(-1.0f, -1.0f, -1.0f, 2.0f, 2.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_gem = p_shaft.addChild("gem",
                ModelPartBuilder.create().uv(12, 0).cuboid(-1.0f, -3.0f, -1.5f, 2.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_knob = p_shaft.addChild("knob",
                ModelPartBuilder.create().uv(18, 0).cuboid(-1.5f, 1.0f, -1.5f, 3.0f, 3.0f, 3.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_band1 = p_shaft.addChild("band1",
                ModelPartBuilder.create().uv(30, 0).cuboid(-1.0f, -8.0f, -1.0f, 2.0f, 1.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_band2 = p_shaft.addChild("band2",
                ModelPartBuilder.create().uv(38, 0).cuboid(-1.0f, -14.0f, -1.0f, 2.0f, 1.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_tip = p_shaft.addChild("tip",
                ModelPartBuilder.create().uv(46, 0).cuboid(-1.0f, -22.0f, -1.0f, 2.0f, 2.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        return TexturedModelData.of(data, 128, 64);
    }
}

package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/**
 * Общие мелочи анимации оружия Балкера.
 * Ход извлечения хранится прямо в NBT предмета (DrawStart/DrawDur), поэтому анимацию видят
 * и другие игроки - серверу не нужно ничего слать.
 */
public final class BalkerWeaponFx {

    private BalkerWeaponFx() {}

    /** Ход анимации извлечения: 0 - только началось, 1 - оружие в руке. */
    public static float drawProgress(ItemStack stack, MinecraftClient mc) {
        NbtCompound n = stack.getNbt();
        if (n == null || !n.contains("DrawStart") || mc.world == null) return 1.0f;
        long elapsed = mc.world.getTime() - n.getLong("DrawStart");
        int dur = Math.max(1, n.getInt("DrawDur"));
        if (elapsed < 0L || elapsed >= dur) return 1.0f;
        return (float) elapsed / (float) dur;
    }

    /** Плавное затухание с небольшим перелётом (для извлечения оружия). */
    public static float easeOutBack(float x) {
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        float p = x - 1.0f;
        return 1.0f + c3 * p * p * p + c1 * p * p;
    }
}

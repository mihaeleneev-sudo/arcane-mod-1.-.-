package com.arcane.client;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * 3D-рендер пистолета Балкера: в руке (с ходом затвора, отдачей и дульным пламенем при выстреле),
 * в третьем лице, в инвентаре и на земле.
 * Анимация извлечения берётся из NBT предмета (DrawStart/DrawDur) - её видят и другие игроки;
 * отдача и ход затвора - из клиентского отката после выстрела (ставится в BalkerPistolItem.use).
 */
public class BalkerPistolItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/balker_pistol.png");
    /** ход затвора назад, 1/16 блока */
    private static final float SLIDE_TRAVEL = 4.5f;
    /** отклонение взведённого ударника, радианы */
    private static final float HAMMER_COCKED = 0.55f;
    /** длительность кулдауна выстрела, тиков (совпадает с BalkerPistolItem) */
    private static final float COOLDOWN_TICKS = 15.0f;

    private static EntityModelLoader loader;
    private static ModelPart gun;

    /** Вызывается при (пере)создании рендереров сущностей: запоминаем загрузчик моделей и сбрасываем кэш. */
    public static void setLoader(EntityModelLoader l) {
        loader = l;
        gun = null;
    }

    private static boolean ensureModels() {
        if (loader == null) return false;
        if (gun == null) gun = loader.getModelPart(BalkerPistolModel.LAYER);
        return true;
    }

    /** Ход анимации извлечения: 0 - только началось, 1 - оружие в руке. */
    public static float drawProgress(ItemStack stack, MinecraftClient mc) {
        return BalkerWeaponFx.drawProgress(stack, mc);
    }

    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack m,
                       VertexConsumerProvider vcp, int light, int overlay) {
        if (!ensureModels()) return;
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean first = mode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;

        float slide = 0.0f;     // 0..1 - ход затвора назад
        float hammer = HAMMER_COCKED;
        float trigger = 0.0f;   // 0..1 - спуск нажат
        float kick = 0.0f;      // отдача всего оружия
        boolean flash = false;

        m.push();
        m.translate(0.5f, 0.5f, 0.5f);   // отменяем сдвиг центра предмета: начало координат - рука

        if (first && mc.player != null) {
            float td = mc.getTickDelta();
            float side = mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1.0f : 1.0f;

            // отдача: клиентский откат после выстрела (ставится в BalkerPistolItem.use)
            float cd = mc.player.getItemCooldownManager().getCooldownProgress(stack.getItem(), td);
            if (cd > 0.0f) {
                float t = (1.0f - cd) * (COOLDOWN_TICKS / 20.0f);   // секунд с момента выстрела
                if (t < 0.04f) {
                    slide = t / 0.04f;                 // затвор уходит назад
                } else if (t < 0.10f) {
                    slide = 1.0f;                      // крайнее положение
                } else if (t < 0.20f) {
                    slide = 1.0f - (t - 0.10f) / 0.10f; // затвор возвращается
                }
                flash = t < 0.05f;
                trigger = t < 0.12f ? 1.0f : 0.0f;
                // ударник: взведён -> спущен -> снова взведён
                if (t < 0.03f) {
                    hammer = HAMMER_COCKED * (1.0f - t / 0.03f);
                } else {
                    hammer = HAMMER_COCKED * MathHelper.clamp((t - 0.03f) / 0.30f, 0.0f, 1.0f);
                }
                float k = MathHelper.clamp(1.0f - t / 0.25f, 0.0f, 1.0f);
                kick = k * k;
            }

            // положение в руке: чуть выше и ближе к центру экрана, ствол смотрит вперёд
            float sway = MathHelper.sin((mc.player.age + td) * 0.09f) * 0.006f;
            m.translate(-0.10f, 0.04f + sway, -0.05f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 9.0f));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(4.0f));
            m.scale(0.45f, 0.45f, 0.45f);

            // извлечение оружия: поднимается снизу с лёгким перелётом
            float draw = drawProgress(stack, mc);
            if (draw < 1.0f) {
                float k = 1.0f - BalkerWeaponFx.easeOutBack(draw);
                m.translate(0.0f, -0.28f * k, 0.10f * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-65.0f * k));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(28.0f * k));
            }

            // отдача
            if (kick > 0.0f) {
                m.translate(0.0f, kick * 0.015f, kick * 0.09f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(kick * 10.0f));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(kick * 3.0f));
            }
        } else if (mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
            m.translate(0.0f, -0.12f, -0.05f);
            m.scale(0.42f, 0.42f, 0.42f);
        } else if (mode == ModelTransformationMode.GUI) {
            m.scale(0.42f, 0.42f, 0.42f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(22.0f));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
            m.translate(-0.17f, 0.11f, 0.0f);
        } else {
            // земля, рамка, голова и т.п.
            m.scale(0.42f, 0.42f, 0.42f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
            m.translate(-0.17f, 0.11f, 0.0f);
        }

        ModelPart slidePart = gun.getChild("slide");
        slidePart.pivotZ = SLIDE_TRAVEL * slide;
        ModelPart framePart = gun.getChild("frame");
        framePart.getChild("hammer").pitch = -hammer;
        framePart.getChild("trigger").pitch = -0.5f * trigger;
        ModelPart flashPart = gun.getChild("flash");
        flashPart.visible = false;

        gun.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), light, OverlayTexture.DEFAULT_UV);

        if (flash) {
            // дульное пламя - полностью освещённое
            flashPart.visible = true;
            flashPart.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), 0xF000F0, OverlayTexture.DEFAULT_UV);
            flashPart.visible = false;
        }
        m.pop();
    }
}

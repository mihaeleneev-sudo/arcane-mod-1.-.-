package com.arcane.client;

import com.arcane.Balker;
import com.arcane.ModItems;
import com.arcane.Packets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Меню кресла WA Corporation: установка и снятие Чипа WA, выбор персонажа (девять ячеек, пока открыт Балкер)
 * и покупка улучшений Балкера за изумруды. Все проверки выполняет сервер.
 *
 * Вёрстка: экран 400x240. Блоки идут сверху вниз без пересечений:
 * верхний ряд - заголовок и кнопка "Выйти";
 * блок Чипа WA (чип слева, кнопка установки справа, описание с переносом строк ниже);
 * ряд из девяти ячеек и кнопка выбора персонажа;
 * список улучшений: иконка, название, описание, цена и кнопка покупки справа.
 */
public class WaChairScreen extends Screen {
    private static final int W = 400;
    private static final int H = 240;

    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_DIM = 0xFFA0A0A8;
    private static final int COLOR_GOLD = 0xFFFFD060;
    private static final int COLOR_OK = 0xFF7BE08A;

    private int left;
    private int top;

    public WaChairScreen() {
        super(Text.translatable("screen.arcane.wa_chair"));
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = (this.height - H) / 2;
        build();
    }

    private static void send(int action, String arg) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(action);
        buf.writeString(arg);
        ClientPlayNetworking.send(Packets.WA_ACTION, buf);
    }

    /** Сервер прислал новое состояние: перестроить кнопки. */
    public void refresh() {
        build();
    }

    private int emeralds() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return 0;
        int n = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isOf(Items.EMERALD)) n += s.getCount();
        }
        return n;
    }

    // ---------- координаты блоков ----------

    private int chipTop()      { return top + 28; }
    private int chipBottom()   { return top + 76; }
    private int slotsTop()     { return top + 96; }
    private int upgradesTop()  { return top + 148; }
    private int rowY(int i)    { return upgradesTop() + 12 + i * 24; }

    /** Правая кнопка строки улучшений. */
    private int buyX()         { return left + W - 96; }
    /** Цена выводится справа от описания, но до кнопки покупки. */
    private int priceX()       { return left + W - 104; }

    private void build() {
        this.clearChildren();

        // Выйти - в правом верхнем углу, чтобы не спорить со списком улучшений.
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_leave"), b -> this.close())
                .dimensions(left + W - 70, top + 4, 60, 20).build());

        if (!ClientWa.chip) {
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_install"),
                    b -> send(Balker.ACT_INSTALL, "")).dimensions(left + W - 118, chipTop() + 4, 108, 20).build());
        } else {
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_remove"),
                    b -> send(Balker.ACT_REMOVE, "")).dimensions(left + W - 118, chipTop() + 4, 108, 20).build());

            // Выбор персонажа (пока открыт только Балкер) - справа от подписи под ячейками.
            ButtonWidget pick = ButtonWidget.builder(
                    Text.translatable(ClientWa.balker ? "screen.arcane.wa_selected" : "screen.arcane.wa_select"),
                    b -> send(Balker.ACT_SELECT, "balker")).dimensions(left + 66, slotsTop() + 28, 92, 20).build();
            pick.active = !ClientWa.balker;
            this.addDrawableChild(pick);

            if (ClientWa.balker) {
                String[] keys = {"pistol", "cane", "radio"};
                for (int i = 0; i < 3; i++) {
                    final String key = keys[i];
                    boolean owned = (ClientWa.mask & (1 << i)) != 0;
                    ButtonWidget buy = ButtonWidget.builder(Text.translatable(owned ? "screen.arcane.wa_bought" : "screen.arcane.wa_buy"),
                            b -> send(Balker.ACT_BUY, key)).dimensions(buyX(), rowY(i) - 2, 88, 20).build();
                    buy.active = !owned && emeralds() >= Balker.EMERALD_PRICE;
                    this.addDrawableChild(buy);
                }
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF5AC8FA);
        ctx.fill(left, top, left + W, top + H, 0xF0101820);
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_chair"), left + 10, top + 10, 0xFF5AC8FA, false);

        renderChip(ctx);
        if (ClientWa.chip) {
            renderSlots(ctx);
            renderUpgrades(ctx);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderChip(DrawContext ctx) {
        ctx.fill(left + 8, chipTop(), left + W - 8, chipBottom(), 0xFF1A2630);
        ctx.drawText(this.textRenderer, Text.translatable("wa.chip.name"), left + 16, chipTop() + 6, COLOR_TEXT, false);
        ctx.drawText(this.textRenderer, Text.translatable(ClientWa.chip ? "wa.chip.installed" : "wa.chip.available"),
                left + 16, chipTop() + 17, ClientWa.chip ? COLOR_OK : COLOR_GOLD, false);

        // Описание - отдельной строкой с переносом, чтобы не заезжать под кнопку справа.
        drawWrapped(ctx, Text.translatable("wa.chip.desc"), left + 16, chipTop() + 29, W - 24, 0.8f, COLOR_DIM);
    }

    private void renderSlots(DrawContext ctx) {
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_title"), left + 10, top + 84, 0xFF5AC8FA, false);

        // Девять ячеек: открыт только Балкер, остальные - заглушки.
        for (int i = 0; i < 9; i++) {
            int x = left + 8 + i * 36;
            int y = slotsTop();
            boolean open = i == 0;
            ctx.fill(x, y, x + 32, y + 28, open ? 0xFF5AC8FA : 0xFF3A3A44);
            ctx.fill(x + 1, y + 1, x + 31, y + 27, 0xFF14141A);
            if (open) {
                ctx.drawItem(new ItemStack(ModItems.BALKER_PISTOL), x + 8, y + 6);
            } else {
                ctx.drawText(this.textRenderer, Text.literal("?"), x + 13, y + 10, 0xFF55555F, false);
            }
        }

        ctx.drawText(this.textRenderer, Text.translatable("character.arcane.balker"), left + 8, slotsTop() + 32, COLOR_TEXT, false);
    }

    private void renderUpgrades(DrawContext ctx) {
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_upgrades"), left + 10, upgradesTop(), 0xFF5AC8FA, false);

        Item[] items = {ModItems.BALKER_PISTOL, ModItems.BALKER_CANE, ModItems.BALKER_RADIO};
        String[] keys = {"pistol", "cane", "radio"};
        for (int i = 0; i < 3; i++) {
            int y = rowY(i);
            boolean owned = (ClientWa.mask & (1 << i)) != 0;
            ctx.drawItem(new ItemStack(items[i]), left + 10, y + 1);
            ctx.drawText(this.textRenderer, Text.translatable("wa.upgrade." + keys[i]), left + 30, y,
                    owned ? COLOR_OK : COLOR_TEXT, false);
            ctx.drawText(this.textRenderer, Text.translatable("wa.upgrade." + keys[i] + ".desc"), left + 30, y + 10,
                    COLOR_DIM, false);
            ctx.drawText(this.textRenderer, Text.translatable("wa.price", Balker.EMERALD_PRICE), priceX(), y + 4,
                    COLOR_OK, false);
        }
    }

    /** Текст уменьшенным шрифтом с переносом по ширине. */
    private void drawWrapped(DrawContext ctx, Text text, int x, int y, int width, float scale, int color) {
        List<OrderedText> lines = this.textRenderer.wrapLines(text, (int) (width / scale));
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0.0f);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        int ly = 0;
        for (OrderedText line : lines) {
            ctx.drawText(this.textRenderer, line, 0, ly, color, false);
            ly += 10;
        }
        ctx.getMatrices().pop();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        send(Balker.ACT_LEAVE, "");
    }
}

package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

/**
 * 3D-модель рации Балкера: тёмный корпус, зелёный дисплей, оранжевая полоса WA,
 *  * антенна, боковой регулятор и клипса на пояс.
 *  * Механика рации не менялась - только внешний вид.
 * Р¤Р°Р№Р» СЃРіРµРЅРµСЂРёСЂРѕРІР°РЅ: РґРµС‚Р°Р»Рё, UV-РєРѕРѕСЂРґРёРЅР°С‚С‹ Рё С‚РµРєСЃС‚СѓСЂР° assets/arcane/textures/entity/balker_radio.png СЃРѕРіР»Р°СЃРѕРІР°РЅС‹ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё.
 * РЎРёСЃС‚РµРјР° РєРѕРѕСЂРґРёРЅР°С‚: x РІРїСЂР°РІРѕ, y РІРІРµСЂС…, z РЅР°Р·Р°Рґ, СЃС‚РІРѕР» СЃРјРѕС‚СЂРёС‚ РІ -z, РЅР°С‡Р°Р»Рѕ Сѓ СЂСѓРєРѕСЏС‚Рё; РµРґРёРЅРёС†С‹ - 1/16 Р±Р»РѕРєР°.
 */
public final class BalkerRadioModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "balker_radio"), "main");

    private BalkerRadioModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_body = root.addChild("body",
                ModelPartBuilder.create().uv(0, 0).cuboid(-2.0f, -3.0f, -2.0f, 4.0f, 6.0f, 4.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_screen = p_body.addChild("screen",
                ModelPartBuilder.create().uv(16, 0).cuboid(-1.0f, 1.0f, -3.0f, 2.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_speaker = p_body.addChild("speaker",
                ModelPartBuilder.create().uv(22, 0).cuboid(-1.0f, -2.0f, -3.0f, 2.0f, 3.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_antenna = p_body.addChild("antenna",
                ModelPartBuilder.create().uv(28, 0).cuboid(1.0f, 3.0f, -1.0f, 1.0f, 8.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_knob = p_body.addChild("knob",
                ModelPartBuilder.create().uv(32, 0).cuboid(-3.0f, 1.0f, -1.0f, 1.0f, 2.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_clip = p_body.addChild("clip",
                ModelPartBuilder.create().uv(38, 0).cuboid(-1.0f, 3.0f, 1.0f, 2.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        return TexturedModelData.of(data, 128, 64);
    }
}

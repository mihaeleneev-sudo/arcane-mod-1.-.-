package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

/**
 * 3D-модель пистолета Балкера (WA Corporation) в стиле CS: тёмный gunmetal,
 *  * оранжевые полосы WA, затвор с окном выброса и насечкой, рамка, спусковая скоба,
 *  * магазин, кувалда-ударник, дульный пламя при выстреле.
 *  * Узлы анимируются в BalkerPistolItemRenderer: slide (затвор), hammer, trigger, flash.
 * Р¤Р°Р№Р» СЃРіРµРЅРµСЂРёСЂРѕРІР°РЅ: РґРµС‚Р°Р»Рё, UV-РєРѕРѕСЂРґРёРЅР°С‚С‹ Рё С‚РµРєСЃС‚СѓСЂР° assets/arcane/textures/entity/balker_pistol.png СЃРѕРіР»Р°СЃРѕРІР°РЅС‹ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё.
 * РЎРёСЃС‚РµРјР° РєРѕРѕСЂРґРёРЅР°С‚: x РІРїСЂР°РІРѕ, y РІРІРµСЂС…, z РЅР°Р·Р°Рґ, СЃС‚РІРѕР» СЃРјРѕС‚СЂРёС‚ РІ -z, РЅР°С‡Р°Р»Рѕ Сѓ СЂСѓРєРѕСЏС‚Рё; РµРґРёРЅРёС†С‹ - 1/16 Р±Р»РѕРєР°.
 */
public final class BalkerPistolModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "balker_pistol"), "main");

    private BalkerPistolModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_slide = root.addChild("slide",
                ModelPartBuilder.create().uv(0, 0).cuboid(-1.0f, 2.0f, -13.0f, 2.0f, 3.0f, 13.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_front_sight = p_slide.addChild("front_sight",
                ModelPartBuilder.create().uv(30, 0).cuboid(-0.5f, 5.0f, -12.0f, 1.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_rear_sight = p_slide.addChild("rear_sight",
                ModelPartBuilder.create().uv(34, 0).cuboid(-1.0f, 5.0f, -1.0f, 2.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_frame = root.addChild("frame",
                ModelPartBuilder.create().uv(40, 0).cuboid(-1.0f, -1.0f, -6.0f, 2.0f, 3.0f, 8.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_barrel = p_frame.addChild("barrel",
                ModelPartBuilder.create().uv(60, 0).cuboid(-0.5f, 2.5f, -13.5f, 1.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_grip = p_frame.addChild("grip",
                ModelPartBuilder.create().uv(64, 0).cuboid(-1.0f, -6.0f, -1.0f, 2.0f, 6.0f, 4.0f),
                ModelTransform.of(0.0f, -1.0f, 0.0f, 0.20f, 0.0f, 0.0f));
        ModelPartData p_magazine = p_frame.addChild("magazine",
                ModelPartBuilder.create().uv(76, 0).cuboid(-1.0f, -7.0f, -1.0f, 2.0f, 2.0f, 3.0f),
                ModelTransform.of(0.0f, -1.0f, 0.0f, 0.20f, 0.0f, 0.0f));
        ModelPartData p_trigger = p_frame.addChild("trigger",
                ModelPartBuilder.create().uv(86, 0).cuboid(-0.5f, -2.0f, -0.5f, 1.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, -1.0f, -0.5f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_guard = p_frame.addChild("guard",
                ModelPartBuilder.create().uv(90, 0).cuboid(-1.0f, -3.0f, -3.0f, 2.0f, 1.0f, 5.0f).uv(104, 0).cuboid(-1.0f, -2.0f, -3.0f, 2.0f, 1.0f, 1.0f).uv(110, 0).cuboid(-1.0f, -2.0f, 1.0f, 2.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_hammer = p_frame.addChild("hammer",
                ModelPartBuilder.create().uv(116, 0).cuboid(-0.5f, -1.0f, -0.5f, 1.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 1.5f, 1.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_flash = root.addChild("flash",
                ModelPartBuilder.create().uv(120, 0).cuboid(-0.5f, 2.5f, -14.5f, 1.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        return TexturedModelData.of(data, 128, 64);
    }
}

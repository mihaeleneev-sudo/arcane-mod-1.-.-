package com.arcane.client;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * 3D-рендер рации Балкера: новый вид (тёмный корпус, зелёный дисплей, оранжевая полоса WA,
 * антенна и клипса). Механика рации не менялась - только внешний вид и анимация извлечения.
 */
public class BalkerRadioItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/balker_radio.png");

    private static EntityModelLoader loader;
    private static ModelPart radio;

    public static void setLoader(EntityModelLoader l) {
        loader = l;
        radio = null;
    }

    private static boolean ensureModels() {
        if (loader == null) return false;
        if (radio == null) radio = loader.getModelPart(BalkerRadioModel.LAYER);
        return true;
    }

    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack m,
                       VertexConsumerProvider vcp, int light, int overlay) {
        if (!ensureModels()) return;
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean first = mode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;

        m.push();
        m.translate(0.5f, 0.5f, 0.5f);   // отменяем сдвиг центра предмета: начало координат - рука

        if (first && mc.player != null) {
            float td = mc.getTickDelta();
            float side = mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1.0f : 1.0f;

            float sway = MathHelper.sin((mc.player.age + td) * 0.08f) * 0.006f;
            m.translate(-0.11f, 0.06f + sway, -0.03f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 14.0f));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(6.0f));
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -5.0f));
            m.scale(0.5f, 0.5f, 0.5f);

            // извлечение: рация поднимается снизу
            float draw = BalkerWeaponFx.drawProgress(stack, mc);
            if (draw < 1.0f) {
                float k = 1.0f - BalkerWeaponFx.easeOutBack(draw);
                m.translate(0.0f, -0.26f * k, 0.10f * k);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-45.0f * k));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(20.0f * k));
            }
        } else if (mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
            m.translate(0.0f, -0.10f, -0.05f);
            m.scale(0.45f, 0.45f, 0.45f);
        } else if (mode == ModelTransformationMode.GUI) {
            m.scale(0.45f, 0.45f, 0.45f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(18.0f));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-40.0f));
            m.translate(0.0f, 0.02f, 0.0f);
        } else {
            m.scale(0.45f, 0.45f, 0.45f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-40.0f));
            m.translate(0.0f, 0.02f, 0.0f);
        }

        radio.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), light, OverlayTexture.DEFAULT_UV);
        m.pop();
    }
}

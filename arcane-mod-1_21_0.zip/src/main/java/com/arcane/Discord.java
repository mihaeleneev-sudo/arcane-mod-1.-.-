package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * "Всадники тьмы": Раздор. Вместо способностей игрок получает НПС рядом с собой.
 * <p>
 * Проклятие (arcane_discord_curse) - у игрока есть Раздор. Скрытое проклятие (arcane_discord_latent) -
 * игрок пока ничего не знает: от него изредка идут чёрные пылинки, а первый же полученный от врага удар
 * с шансом пробуждает Раздора.
 * <p>
 * Клавиши (те же, что у других персонажей): Alt - позвать/отпустить, R - "Провокация", G - "Каннибализм"
 * (при слиянии "Бараж"), V - "Концентрация" (слияние, когда шкала полна).
 * Без способностей и проклятия Alt даёт "Кровь" (если здоровье не полное), из неё делается "Печать раздора".
 */
public final class Discord {
    public static final String CURSE_TAG = "arcane_discord_curse";
    public static final String LATENT_TAG = "arcane_discord_latent";

    public static final int SUMMON_COOLDOWN = 10 * 20;
    public static final int PROVOKE_COOLDOWN = 20 * 20;
    public static final int BITE_COOLDOWN = 15 * 20;
    public static final int BARRAGE_COOLDOWN = 3 * 20;
    public static final int BLOOD_COOLDOWN = 30 * 20;
    public static final int MERGE_TICKS = 20 * 20;

    /** Шкала концентрации от 0 до 100, пассивно растёт за 100 секунд. */
    public static final float METER_MAX = 100.0f;
    private static final float METER_PER_TICK = 0.05f;
    private static final float BITE_METER = 20.0f;
    private static final float BITE_DAMAGE = 4.0f;
    private static final float[] BARRAGE_DAMAGE = {6.0f, 6.0f, 9.0f};

    private static final DustParticleEffect BLACK_DUST = new DustParticleEffect(new Vector3f(0.04f, 0.0f, 0.07f), 1.1f);
    private static final DustParticleEffect PURPLE_DUST = new DustParticleEffect(new Vector3f(0.6f, 0.15f, 0.8f), 1.2f);
    private static final DustParticleEffect BLOOD_DUST = new DustParticleEffect(new Vector3f(0.65f, 0.02f, 0.02f), 1.0f);

    private static final Map<UUID, DiscordEntity> ENTITIES = new HashMap<>();
    private static final Map<UUID, Float> METER = new HashMap<>();
    private static final Map<UUID, Integer> MERGE_END = new HashMap<>();
    private static final Map<UUID, Integer> SUMMON_CD = new HashMap<>();
    private static final Map<UUID, Integer> PROVOKE_CD = new HashMap<>();
    private static final Map<UUID, Integer> BITE_CD = new HashMap<>();
    private static final Map<UUID, Integer> BARRAGE_CD = new HashMap<>();
    private static final Map<UUID, Integer> BLOOD_CD = new HashMap<>();
    private static final Set<UUID> SENT = new HashSet<>();

    private static final class Provoked {
        final UUID owner;
        final MobEntity mob;

        Provoked(UUID owner, MobEntity mob) {
            this.owner = owner;
            this.mob = mob;
        }
    }

    private static final class Hit {
        final UUID owner;
        final int at;
        final int index;

        Hit(UUID owner, int at, int index) {
            this.owner = owner;
            this.at = at;
            this.index = index;
        }
    }

    // речь Раздора
    private static final Map<UUID, Integer> SAY_CD = new HashMap<>();
    private static final Map<UUID, Integer> NEXT_IDLE = new HashMap<>();
    private static final Map<UUID, Integer> NEXT_COMBAT = new HashMap<>();
    private static final Map<UUID, Integer> HURT_CD = new HashMap<>();
    private static final Map<UUID, Integer> OWNER_LOW_CD = new HashMap<>();
    private static final Map<UUID, Integer> PVP_CD = new HashMap<>();
    private static final Map<String, Integer> LAST_SAY = new HashMap<>();
    private static final Set<UUID> IN_COMBAT = new HashSet<>();
    private static final Set<UUID> FULL_SAID = new HashSet<>();
    private static final Set<UUID> REVIVED = new HashSet<>();
    /** Слышат все игроки в этом радиусе от владельца. */
    public static final double SAY_RADIUS = 20.0;

    /** Сколько вариантов фразы в каждой категории (discord.say.<категория>.<номер> в lang). */
    private static final Map<String, Integer> SAY_COUNT = new HashMap<>();
    static {
        String[] cats = {"summon", "dismiss", "idle", "combat", "kill", "hurt", "low_hp", "provoke", "bite_go", "bite_low",
                "bite", "meter_full", "merge", "hit1", "hit2", "hit3", "split", "owner_low", "owner_pvp", "revive", "awake",
                "night", "rain", "nether", "end", "cave", "player_near"};
        int[] counts = {4, 2, 8, 5, 4, 3, 2, 4, 1, 1, 3, 3, 4, 1, 1, 3, 3, 3, 2, 2, 3, 1, 1, 1, 1, 1, 1};
        for (int i = 0; i < cats.length; i++) SAY_COUNT.put(cats[i], counts[i]);
    }

    private static final List<Provoked> PROVOKED = new ArrayList<>();
    private static final List<Hit> HITS = new ArrayList<>();

    private Discord() {}

    // ---------- состояние ----------

    public static boolean hasCurse(PlayerEntity p) {
        return p.getCommandTags().contains(CURSE_TAG);
    }

    public static boolean isLatent(PlayerEntity p) {
        return p.getCommandTags().contains(LATENT_TAG);
    }

    private static int left(Map<UUID, Integer> map, UUID id, int now) {
        return Math.max(0, map.getOrDefault(id, 0) - now);
    }

    public static int summonLeft(UUID id, int now) { return left(SUMMON_CD, id, now); }

    public static int provokeLeft(UUID id, int now) { return left(PROVOKE_CD, id, now); }

    public static int biteLeft(UUID id, int now) { return left(BITE_CD, id, now); }

    public static int barrageLeft(UUID id, int now) { return left(BARRAGE_CD, id, now); }

    public static boolean isMerged(UUID id, int now) {
        Integer end = MERGE_END.get(id);
        return end != null && now < end;
    }

    private static DiscordEntity entityOf(UUID owner) {
        DiscordEntity e = ENTITIES.get(owner);
        if (e != null && (e.isRemoved() || !e.isAlive())) {
            ENTITIES.remove(owner);
            return null;
        }
        return e;
    }

    private static void bar(ServerPlayerEntity p, String key, Object... args) {
        p.sendMessage(Text.translatable(key, args), true);
    }

    // ---------- получение ----------

    /** Заход в мир: шанс получить скрытое проклятие (оно нигде не отображается). */
    public static void onJoin(ServerPlayerEntity p) {
        if (Forms.character(p) != Form.NONE || hasCurse(p) || isLatent(p)) return;
        if (p.getRandom().nextFloat() < ArcConfig.discordLatentChance) p.addCommandTag(LATENT_TAG);
    }

    /** Любой урон игроку: от моба или игрока с шансом пробуждает Раздора. */
    public static void onPlayerDamaged(ServerPlayerEntity p, DamageSource source) {
        if (hasCurse(p)) {
            // владельца бьёт другой игрок: Раздор комментирует
            if (source.getAttacker() instanceof PlayerEntity att && att != p && entityOf(p.getUuid()) != null) {
                int now = p.getServer().getTicks();
                UUID id = p.getUuid();
                if (now >= PVP_CD.getOrDefault(id, 0)) {
                    PVP_CD.put(id, now + 400);
                    say(p, "owner_pvp", false);
                }
            }
            return;
        }
        if (!isLatent(p)) return;
        if (!(source.getAttacker() instanceof LivingEntity attacker) || attacker == p || attacker instanceof DiscordEntity) return;
        if (p.getRandom().nextFloat() >= ArcConfig.discordAwakenChance) return;
        grantCurse(p);
    }

    /** Печать, пробуждение или команда: игрок получает проклятие, появляется Раздор. */
    public static void grantCurse(ServerPlayerEntity p) {
        p.removeScoreboardTag(LATENT_TAG);
        p.addCommandTag(CURSE_TAG);
        METER.put(p.getUuid(), 0.0f);
        p.sendMessage(Text.translatable("message.arcane.discord_awake"), false);
        if (entityOf(p.getUuid()) == null) summon(p, "awake");
    }

    public static void clear(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        p.removeScoreboardTag(CURSE_TAG);
        p.removeScoreboardTag(LATENT_TAG);
        dismiss(id);
        METER.remove(id);
        MERGE_END.remove(id);
        REVIVED.remove(id);
        IN_COMBAT.remove(id);
        FULL_SAID.remove(id);
        PROVOKED.removeIf(pr -> pr.owner.equals(id));
        HITS.removeIf(h -> h.owner.equals(id));
        if (SENT.remove(id)) sendState(p, -1, -1, false);
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (hasCurse(oldP)) newP.addCommandTag(CURSE_TAG);
        else if (isLatent(oldP)) newP.addCommandTag(LATENT_TAG);
    }

    public static void onPlayerDeath(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (hasCurse(p)) REVIVED.add(id);
        IN_COMBAT.remove(id);
        FULL_SAID.remove(id);
        dismiss(id);
        METER.put(id, 0.0f);
        MERGE_END.remove(id);
        PROVOKED.removeIf(pr -> pr.owner.equals(id));
        HITS.removeIf(h -> h.owner.equals(id));
    }

    public static void onDisconnect(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        dismiss(id);
        MERGE_END.remove(id);
        SENT.remove(id);
        PROVOKED.removeIf(pr -> pr.owner.equals(id));
        HITS.removeIf(h -> h.owner.equals(id));
    }

    // ---------- Alt ----------

    /** Alt: с проклятием - позвать/отпустить Раздора, без силы - получить "Кровь". Возвращает true, если нажатие обработано. */
    public static boolean onAlt(ServerPlayerEntity p) {
        if (Forms.character(p) != Form.NONE) return false;
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();

        if (hasCurse(p)) {
            if (isMerged(id, now)) {
                bar(p, "message.arcane.discord_merged_busy");
                return true;
            }
            DiscordEntity e = entityOf(id);
            if (e != null) {
                say(p, "dismiss", true);
                dismiss(id);
                SUMMON_CD.put(id, now + SUMMON_COOLDOWN);
                bar(p, "message.arcane.discord_dismissed");
                return true;
            }
            int cd = summonLeft(id, now);
            if (cd > 0) {
                bar(p, "message.arcane.discord_cooldown", (cd + 19) / 20);
                return true;
            }
            summon(p, REVIVED.remove(id) ? "revive" : "summon");
            return true;
        }

        // без силы и без проклятия: "Кровь" раз в 30 секунд, только если здоровье не полное
        if (p.getHealth() >= p.getMaxHealth()) {
            bar(p, "message.arcane.discord_blood_full");
            return true;
        }
        int cd = left(BLOOD_CD, id, now);
        if (cd > 0) {
            bar(p, "message.arcane.discord_blood_cooldown", (cd + 19) / 20);
            return true;
        }
        BLOOD_CD.put(id, now + BLOOD_COOLDOWN);
        ItemStack blood = new ItemStack(ModItems.DISCORD_BLOOD);
        if (!p.getInventory().insertStack(blood)) p.dropItem(blood, false);
        p.getServerWorld().spawnParticles(BLOOD_DUST, p.getX(), p.getY() + 1.0, p.getZ(), 12, 0.3, 0.4, 0.3, 0.02);
        bar(p, "message.arcane.discord_blood_got");
        return true;
    }

    // ---------- призыв ----------

    private static void summon(ServerPlayerEntity p, String sayCategory) {
        ServerWorld w = p.getServerWorld();
        DiscordEntity e = ModEntities.DISCORD.create(w);
        if (e == null) return;
        Vec3d look = p.getRotationVec(1.0f);
        e.owner = p.getUuid();
        e.refreshPositionAndAngles(p.getX() - look.x * 1.5, p.getY(), p.getZ() - look.z * 1.5, p.getYaw(), 0.0f);
        w.spawnEntity(e);
        ENTITIES.put(p.getUuid(), e);
        w.spawnParticles(BLACK_DUST, e.getX(), e.getY() + 1.0, e.getZ(), 30, 0.4, 0.8, 0.4, 0.03);
        w.spawnParticles(ParticleTypes.SOUL, e.getX(), e.getY() + 1.0, e.getZ(), 10, 0.3, 0.6, 0.3, 0.02);
        w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_ILLUSIONER_PREPARE_MIRROR, SoundCategory.PLAYERS, 1.0f, 0.7f);
        NEXT_IDLE.put(p.getUuid(), p.getServer().getTicks() + 1200 + p.getRandom().nextInt(1200));
        if (sayCategory != null) say(p, sayCategory, true);
    }

    private static void dismiss(UUID owner) {
        DiscordEntity e = ENTITIES.remove(owner);
        if (e != null && !e.isRemoved()) e.discard();
    }

    public static void onEntityRemoved(DiscordEntity e) {
        if (e.owner != null) ENTITIES.remove(e.owner, e);
    }

    /** Раздора убили: отдыхает до следующего призыва. */
    public static void onEntityDied(DiscordEntity e) {
        if (e.owner == null) return;
        MinecraftServer server = e.getServer();
        if (server != null) SUMMON_CD.put(e.owner, server.getTicks() + SUMMON_COOLDOWN);
        ServerPlayerEntity o = e.ownerPlayer();
        if (o != null) bar(o, "message.arcane.discord_died");
    }

    // ---------- умение 1: Провокация (R) ----------

    public static void skill1(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        DiscordEntity e = requireEntity(p, now);
        if (e == null) return;
        int cd = provokeLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.discord_cooldown", (cd + 19) / 20);
            return;
        }
        MobEntity target = findProvokeTarget(p, e);
        if (target == null) {
            bar(p, "message.arcane.discord_no_enemy");
            return;
        }
        PROVOKED.removeIf(pr -> pr.owner.equals(id));
        PROVOKED.add(new Provoked(id, target));
        e.setTarget(target);
        PROVOKE_CD.put(id, now + PROVOKE_COOLDOWN);
        ServerWorld w = p.getServerWorld();
        w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_RAVAGER_ROAR, SoundCategory.PLAYERS, 1.0f, 1.3f);
        w.spawnParticles(PURPLE_DUST, target.getX(), target.getY() + target.getHeight() + 0.3, target.getZ(), 20, 0.3, 0.2, 0.3, 0.02);
        bar(p, "message.arcane.discord_provoked");
        say(p, "provoke", true);
    }

    private static MobEntity findProvokeTarget(ServerPlayerEntity p, DiscordEntity e) {
        LivingEntity current = e.getTarget();
        if (current instanceof MobEntity m && m instanceof Monster && m.isAlive() && m.squaredDistanceTo(p) < 20.0 * 20.0) return m;
        List<MobEntity> list = p.getWorld().getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(16.0),
                m -> m instanceof Monster && m.isAlive() && !(m instanceof DiscordEntity));
        MobEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (MobEntity m : list) {
            double d = m.squaredDistanceTo(p);
            if (d < bestDist) {
                bestDist = d;
                best = m;
            }
        }
        return best;
    }

    // ---------- умение 2: Каннибализм (G) / Бараж при слиянии ----------

    public static void skill2(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        if (isMerged(id, now)) {
            barrage(p, now);
            return;
        }
        DiscordEntity e = requireEntity(p, now);
        if (e == null) return;
        int cd = biteLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.discord_cooldown", (cd + 19) / 20);
            return;
        }
        if (p.getHealth() <= BITE_DAMAGE + 2.0f) {
            bar(p, "message.arcane.discord_bite_low");
            say(p, "bite_low", false);
            return;
        }
        BITE_CD.put(id, now + BITE_COOLDOWN);
        e.wantsBite = true;
        e.biteTimeout = 100;
        e.setTarget(null);
        bar(p, "message.arcane.discord_bite_go");
        say(p, "bite_go", true);
    }

    /** Вызывается самим Раздором, когда он добежал до хозяина. */
    public static void onBite(ServerPlayerEntity owner, DiscordEntity e) {
        if (owner.getHealth() > BITE_DAMAGE + 1.0f) {
            owner.damage(owner.getDamageSources().magic(), BITE_DAMAGE);
        }
        e.heal(12.0f);
        e.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 1));
        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 0));
        e.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 0));
        UUID id = owner.getUuid();
        METER.put(id, Math.min(METER_MAX, METER.getOrDefault(id, 0.0f) + BITE_METER));
        ServerWorld w = owner.getServerWorld();
        w.spawnParticles(BLOOD_DUST, owner.getX(), owner.getY() + 1.2, owner.getZ(), 20, 0.3, 0.4, 0.3, 0.03);
        w.spawnParticles(PURPLE_DUST, e.getX(), e.getY() + 1.0, e.getZ(), 20, 0.4, 0.6, 0.4, 0.03);
        w.playSound(null, owner.getX(), owner.getY(), owner.getZ(), SoundEvents.ENTITY_PHANTOM_BITE, SoundCategory.PLAYERS, 1.2f, 0.6f);
        say(owner, "bite", true);
    }

    // ---------- умение 3: Концентрация (V) ----------

    public static void skill3(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        if (isMerged(id, now)) return;
        DiscordEntity e = requireEntity(p, now);
        if (e == null) return;
        float meter = METER.getOrDefault(id, 0.0f);
        if (meter < METER_MAX) {
            bar(p, "message.arcane.discord_meter_low", (int) meter);
            return;
        }
        merge(p, e, now);
    }

    private static void merge(ServerPlayerEntity p, DiscordEntity e, int now) {
        UUID id = p.getUuid();
        METER.put(id, 0.0f);
        MERGE_END.put(id, now + MERGE_TICKS);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(PURPLE_DUST, e.getX(), e.getY() + 1.0, e.getZ(), 40, 0.4, 0.8, 0.4, 0.05);
        dismiss(id);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, MERGE_TICKS, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, MERGE_TICKS, 0));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, MERGE_TICKS, 0));
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WITHER_AMBIENT, SoundCategory.PLAYERS, 1.0f, 0.6f);
        bar(p, "message.arcane.discord_merged");
        say(p, "merge", true);
    }

    private static void endMerge(ServerPlayerEntity p) {
        MERGE_END.remove(p.getUuid());
        if (p.isAlive()) {
            summon(p, null);
            bar(p, "message.arcane.discord_split");
            say(p, "split", true);
        }
    }

    // ---------- Бараж ----------

    private static void barrage(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        int cd = barrageLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.discord_cooldown", (cd + 19) / 20);
            return;
        }
        if (findFront(p, 5.0) == null) {
            bar(p, "message.arcane.discord_no_target");
            return;
        }
        BARRAGE_CD.put(id, now + BARRAGE_COOLDOWN);
        HITS.add(new Hit(id, now, 0));
        HITS.add(new Hit(id, now + 6, 1));
        HITS.add(new Hit(id, now + 12, 2));
    }

    private static LivingEntity findFront(ServerPlayerEntity p, double range) {
        Vec3d look = p.getRotationVec(1.0f);
        List<LivingEntity> list = p.getWorld().getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().stretch(look.multiply(range)).expand(1.5),
                e -> e != p && e.isAlive() && !(e instanceof DiscordEntity));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            Vec3d to = e.getPos().add(0.0, e.getHeight() / 2.0, 0.0).subtract(p.getEyePos());
            double dist = to.length();
            if (dist > range + 1.0 || dist < 0.001) continue;
            if (to.normalize().dotProduct(look) < 0.5) continue;
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    private static void doHit(ServerPlayerEntity p, int index) {
        LivingEntity target = findFront(p, 5.0);
        if (target == null) return;
        Vec3d look = p.getRotationVec(1.0f);
        target.timeUntilRegen = 0;
        target.damage(p.getDamageSources().playerAttack(p), BARRAGE_DAMAGE[index]);
        if (index == 2) target.takeKnockback(1.1, -look.x, -look.z);
        ServerWorld w = p.getServerWorld();
        Vec3d at = target.getPos().add(0.0, target.getHeight() / 2.0, 0.0);
        w.spawnParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 14, 0.3, 0.3, 0.3, 0.3);
        w.spawnParticles(PURPLE_DUST, at.x, at.y, at.z, 10, 0.3, 0.3, 0.3, 0.05);
        w.spawnParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        say(p, "hit" + (index + 1), true);
        SoundEvent s = index == 2 ? SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK : SoundEvents.ENTITY_PLAYER_ATTACK_STRONG;
        w.playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, 1.0f, 0.8f + index * 0.15f);
    }

    // ---------- общее ----------

    /** Умениям нужен живой Раздор рядом (при слиянии его нет). */
    private static DiscordEntity requireEntity(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        if (isMerged(id, now)) {
            bar(p, "message.arcane.discord_merged_busy");
            return null;
        }
        DiscordEntity e = entityOf(id);
        if (e == null) bar(p, "message.arcane.discord_not_here");
        return e;
    }

    private static void sendState(ServerPlayerEntity p, int meter, int mergeLeft, boolean summoned) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(meter);
        buf.writeInt(mergeLeft);
        buf.writeBoolean(summoned);
        ServerPlayNetworking.send(p, Packets.DISCORD, buf);
    }

    // ---------- речь Раздора ----------

    /** Фраза Раздора в чат: слышат все игроки в 20 блоках от владельца. force - не ждать паузу между репликами. */
    public static void say(ServerPlayerEntity owner, String category, boolean force) {
        Integer n = SAY_COUNT.get(category);
        if (n == null || owner.getServer() == null) return;
        UUID id = owner.getUuid();
        int now = owner.getServer().getTicks();
        if (!force && now < SAY_CD.getOrDefault(id, 0)) return;
        SAY_CD.put(id, now + 60);

        int idx = 1 + owner.getRandom().nextInt(n);
        String lastKey = id + category;
        if (n > 1 && LAST_SAY.getOrDefault(lastKey, 0) == idx) idx = idx % n + 1;   // не повторяться подряд
        LAST_SAY.put(lastKey, idx);

        Text msg = Text.translatable("message.arcane.discord_say", Text.translatable("entity.arcane.discord"),
                Text.translatable("discord.say." + category + "." + idx));
        for (ServerPlayerEntity sp : owner.getServerWorld().getPlayers()) {
            if (sp.squaredDistanceTo(owner) <= SAY_RADIUS * SAY_RADIUS) sp.sendMessage(msg, false);
        }
    }

    /** Раздор получил урон. */
    public static void onEntityHurt(DiscordEntity e) {
        ServerPlayerEntity o = e.ownerPlayer();
        if (o == null || e.getServer() == null) return;
        UUID id = o.getUuid();
        int now = e.getServer().getTicks();
        if (now < HURT_CD.getOrDefault(id, 0)) return;
        HURT_CD.put(id, now + 400);
        say(o, e.getHealth() < e.getMaxHealth() * 0.3f ? "low_hp" : "hurt", false);
    }

    /** Кто-то умер: если его убил Раздор, он это комментирует. */
    public static void onKill(LivingEntity victim, DamageSource source) {
        if (!(source.getAttacker() instanceof DiscordEntity d)) return;
        ServerPlayerEntity o = d.ownerPlayer();
        if (o != null && !(victim instanceof PlayerEntity)) say(o, "kill", false);
    }

    private static String idleCategory(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        List<String> opts = new ArrayList<>();
        if (w.getRegistryKey() == World.NETHER) {
            opts.add("nether");
        } else if (w.getRegistryKey() == World.END) {
            opts.add("end");
        } else {
            long dt = w.getTimeOfDay() % 24000L;
            if (dt >= 13000L && dt <= 23000L) opts.add("night");
            if (w.isRaining()) opts.add("rain");
            if (p.getY() < 45.0 && !w.isSkyVisible(p.getBlockPos())) opts.add("cave");
        }
        for (ServerPlayerEntity o : w.getPlayers()) {
            if (o != p && !o.isSpectator() && o.squaredDistanceTo(p) < 144.0) {
                opts.add("player_near");
                break;
            }
        }
        if (!opts.isEmpty() && p.getRandom().nextFloat() < 0.4f) return opts.get(p.getRandom().nextInt(opts.size()));
        return "idle";
    }

    /** Раздор сам по себе: бормочет раз в 1-2 минуты, комментирует начало боя, полную шкалу и плохое самочувствие владельца. */
    private static void tickSpeech(ServerPlayerEntity p, int t) {
        UUID id = p.getUuid();
        DiscordEntity e = entityOf(id);

        float meter = METER.getOrDefault(id, 0.0f);
        if (meter >= METER_MAX) {
            if (FULL_SAID.add(id) && e != null) say(p, "meter_full", false);
        } else {
            FULL_SAID.remove(id);
        }

        if (p.getHealth() < 6.0f && e != null && t >= OWNER_LOW_CD.getOrDefault(id, 0)) {
            OWNER_LOW_CD.put(id, t + 600);
            say(p, "owner_low", false);
        }

        if (e == null) {
            IN_COMBAT.remove(id);
            return;
        }
        if (e.getTarget() != null) {
            if (IN_COMBAT.add(id) && t >= NEXT_COMBAT.getOrDefault(id, 0)) {
                NEXT_COMBAT.put(id, t + 300);
                say(p, "combat", false);
            }
        } else {
            IN_COMBAT.remove(id);
        }

        if (t >= NEXT_IDLE.getOrDefault(id, Integer.MAX_VALUE) && e.getTarget() == null) {
            NEXT_IDLE.put(id, t + 1200 + p.getRandom().nextInt(1200));
            say(p, idleCategory(p), false);
        }
    }

    // ---------- тик ----------

    public static void tick(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            if (!hasCurse(p)) {
                if (SENT.remove(id)) sendState(p, -1, -1, false);
                // скрытое проклятие: изредка идут чёрные пылинки
                if (t % 40 == 0 && isLatent(p) && p.isAlive() && p.getRandom().nextInt(4) == 0) {
                    p.getServerWorld().spawnParticles(BLACK_DUST, p.getX(), p.getY() + 1.0, p.getZ(), 2, 0.3, 0.5, 0.3, 0.005);
                }
                continue;
            }
            if (!p.isAlive()) continue;

            Integer end = MERGE_END.get(id);
            boolean merged = end != null && t < end;
            if (end != null && !merged) {
                endMerge(p);
            }
            if (merged) {
                if (t % 2 == 0) {
                    p.getServerWorld().spawnParticles(PURPLE_DUST, p.getX(), p.getY() + 1.0, p.getZ(), 3, 0.35, 0.7, 0.35, 0.01);
                    p.getServerWorld().spawnParticles(BLACK_DUST, p.getX(), p.getY() + 0.5, p.getZ(), 2, 0.3, 0.5, 0.3, 0.01);
                }
            } else {
                METER.put(id, Math.min(METER_MAX, METER.getOrDefault(id, 0.0f) + METER_PER_TICK));
                // Раздор остался в другом измерении: зовём заново
                DiscordEntity e = entityOf(id);
                if (e != null && e.getWorld() != p.getWorld()) {
                    dismiss(id);
                    summon(p, null);
                }
            }

            tickSpeech(p, t);

            if (t % 10 == 0) {
                int mergeLeft = merged ? end - t : -1;
                sendState(p, METER.getOrDefault(id, 0.0f).intValue(), mergeLeft, entityOf(id) != null);
                SENT.add(id);
            }
        }

        tickProvoked(t);
        tickHits(server, t);
    }

    /** Спровоцированный моб: все враждебные вокруг идут на него, пока он не умрёт. */
    private static void tickProvoked(int t) {
        if (t % 10 != 0 || PROVOKED.isEmpty()) return;
        Iterator<Provoked> it = PROVOKED.iterator();
        while (it.hasNext()) {
            Provoked pr = it.next();
            MobEntity mob = pr.mob;
            if (!mob.isAlive() || mob.isRemoved()) {
                it.remove();
                continue;
            }
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 30, 0, false, false));
            ((ServerWorld) mob.getWorld()).spawnParticles(PURPLE_DUST, mob.getX(), mob.getY() + mob.getHeight() + 0.4, mob.getZ(), 3, 0.2, 0.1, 0.2, 0.01);
            List<MobEntity> near = mob.getWorld().getEntitiesByClass(MobEntity.class, mob.getBoundingBox().expand(14.0),
                    m -> m != mob && m.isAlive() && m instanceof Monster && !(m instanceof DiscordEntity));
            for (MobEntity m : near) m.setTarget(mob);
            DiscordEntity e = entityOf(pr.owner);
            if (e != null && e.getTarget() != mob) e.setTarget(mob);
        }
    }

    private static void tickHits(MinecraftServer server, int t) {
        if (HITS.isEmpty()) return;
        Iterator<Hit> it = HITS.iterator();
        while (it.hasNext()) {
            Hit h = it.next();
            if (t < h.at) continue;
            it.remove();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(h.owner);
            if (p != null && p.isAlive()) doHit(p, h.index);
        }
    }
}

package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Печать раздора: ПКМ - принять проклятие и получить Раздора (только игроку без силы). */
public class DiscordSealItem extends Item {
    public DiscordSealItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (Forms.character(sp) != Form.NONE) {
                sp.sendMessage(Text.translatable("message.arcane.discord_has_power"), true);
                return TypedActionResult.fail(stack);
            }
            if (Discord.hasCurse(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.already_has"), true);
                return TypedActionResult.fail(stack);
            }
            Discord.grantCurse(sp);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack);
    }
}

package com.arcane.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * Рисует поверх модели игрока: костюм Саира, красную кожу Эйро, золотое свечение Шута.
 * Это не предмет брони, поэтому снять нельзя - оно существует только пока включена форма.
 */
public class FormFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier SAIR_TEX = new Identifier("arcane", "textures/entity/sair_costume.png");
    private static final Identifier EIRO_TEX = new Identifier("arcane", "textures/entity/eiro_overlay.png");
    private static final Identifier JESTER_TEX = new Identifier("arcane", "textures/entity/jester_glow.png");

    private final PlayerEntityModel<AbstractClientPlayerEntity> sair;
    private final PlayerEntityModel<AbstractClientPlayerEntity> sairSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> eiro;
    private final PlayerEntityModel<AbstractClientPlayerEntity> eiroSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> jester;
    private final PlayerEntityModel<AbstractClientPlayerEntity> jesterSlim;

    public FormFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context,
                               EntityModelLoader loader) {
        super(context);
        this.sair = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_LAYER), false);
        this.sairSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_SLIM_LAYER), true);
        this.eiro = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.EIRO_LAYER), false);
        this.eiroSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.EIRO_SLIM_LAYER), true);
        this.jester = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.JESTER_LAYER), false);
        this.jesterSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.JESTER_SLIM_LAYER), true);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        int form = ClientForms.get(player.getUuid());
        if (form == 0 || player.isInvisible()) return;

        boolean slim = "slim".equals(player.getModel());
        PlayerEntityModel<AbstractClientPlayerEntity> m;
        RenderLayer layer;
        int usedLight = light;

        if (form == 1) {
            m = slim ? sairSlim : sair;
            layer = RenderLayer.getEntityCutoutNoCull(SAIR_TEX);
        } else if (form == 2) {
            m = slim ? eiroSlim : eiro;
            layer = RenderLayer.getEntityTranslucent(EIRO_TEX);
        } else if (form == 3) {
            m = slim ? jesterSlim : jester;
            layer = RenderLayer.getEntityTranslucent(JESTER_TEX);
            usedLight = LightmapTextureManager.MAX_LIGHT_COORDINATE; // светится даже в темноте
        } else {
            return;
        }

        PlayerEntityModel<AbstractClientPlayerEntity> base = this.getContextModel();

        // повторяем позу основной модели игрока
        base.copyStateTo(m);
        m.sneaking = base.sneaking;
        m.leftArmPose = base.leftArmPose;
        m.rightArmPose = base.rightArmPose;
        m.animateModel(player, limbAngle, limbDistance, tickDelta);
        m.setAngles(player, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        m.setVisible(false);
        m.body.visible = true;
        m.leftArm.visible = true;
        m.rightArm.visible = true;
        m.leftLeg.visible = true;
        m.rightLeg.visible = true;
        if (form == 1) m.hat.visible = true;   // у Саира голову закрывает плетёная шляпа
        else m.head.visible = true;

        VertexConsumer vc = vertexConsumers.getBuffer(layer);
        m.render(matrices, vc, usedLight, LivingEntityRenderer.getOverlay(player, 0.0f), 1.0f, 1.0f, 1.0f, 1.0f);
    }
}

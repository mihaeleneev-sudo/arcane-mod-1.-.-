# Arcane (Fabric 1.20.1), версия 1.3.0
Персонажи: Саир (катана), Эйро (огонь и бросок блока), Шут (8 карт).
Управление: Alt - превращение, R - способность Эйро (бросок блока).
Сила: Осколок/Кристалл Аркана (Саир), Сердце Эйро (Эйро), Карта Таро: Шут (Шут).
Команда для операторов: /arcane character sair|eiro|jester|none
Конфиг: config/arcane.properties (shardChance, eiroHeartChance, jesterCardChance, legendName)
Нужен Fabric API 0.92.2+1.20.1; мод ставится и на сервер, и клиентам.

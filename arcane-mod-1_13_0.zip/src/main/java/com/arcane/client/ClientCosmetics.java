package com.arcane.client;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Что надето на игроках (для рендера) и что есть у самого игрока (для меню кастомизации). */
public final class ClientCosmetics {
    private static final Map<UUID, String> FACES = new ConcurrentHashMap<>();

    private static volatile String character = "none";
    private static final Set<String> OWNED = ConcurrentHashMap.newKeySet();
    private static final Set<String> WORN = ConcurrentHashMap.newKeySet();

    private ClientCosmetics() {}

    public static String face(UUID id) { return FACES.getOrDefault(id, ""); }

    public static void setFace(UUID id, String face) {
        if (face == null || face.isEmpty()) FACES.remove(id);
        else FACES.put(id, face);
    }

    public static void setState(String characterKey, java.util.List<String> owned, java.util.List<String> worn) {
        character = characterKey;
        OWNED.clear();
        OWNED.addAll(owned);
        WORN.clear();
        WORN.addAll(worn);
    }

    public static String character() { return character; }

    public static boolean owns(String id) { return OWNED.contains(id); }

    public static boolean worn(String id) { return WORN.contains(id); }

    public static void clear() {
        FACES.clear();
        OWNED.clear();
        WORN.clear();
        character = "none";
    }
}

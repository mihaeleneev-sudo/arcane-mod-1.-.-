package com.arcane.client;

import com.arcane.Cosmetics;
import com.arcane.CraftCatalog;
import com.arcane.Packets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Меню кастомизации (клавиша B). Две вкладки:
 * 1) "Крафты" - рецепты предметов персонажей, с кнопкой крафта из инвентаря;
 * 2) "Кастомизация" - аксессуары персонажа (маска на лицо и т.п.) и предпросмотр.
 */
public class CustomizationScreen extends Screen {
    private static final int W = 330;
    private static final int H = 226;
    private static final int PER_PAGE = 7;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_DIM = 0xFFA0A0A8;
    private static final int COLOR_GOLD = 0xFFFFD060;

    private int left;
    private int top;
    private int tab = 0;        // 0 - крафты, 1 - кастомизация
    private int page = 0;
    private int selected = 0;

    // ячейки предметов, над которыми можно показать подсказку (заполняется при рисовании)
    private final List<int[]> hoverBoxes = new ArrayList<>();
    private final List<ItemStack> hoverStacks = new ArrayList<>();

    public CustomizationScreen() {
        super(Text.translatable("screen.arcane.customize.title"));
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = (this.height - H) / 2;
        build();
        sendAction(0, "");   // запрос актуального состояния у сервера
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Пришли новые данные от сервера. */
    public void refresh() {
        build();
    }

    private static void sendAction(int action, String arg) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(action);
        buf.writeString(arg);
        ClientPlayNetworking.send(Packets.COSMETIC_ACTION, buf);
    }

    // ---------- кнопки ----------

    private void build() {
        this.clearChildren();

        this.addDrawableChild(tabButton(0, "screen.arcane.tab.crafts", left + 10));
        this.addDrawableChild(tabButton(1, "screen.arcane.tab.cosmetics", left + 10 + 150));

        if (tab == 0) buildCrafts();
        else buildCosmetics();

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> this.close())
                .dimensions(left + W - 70, top + H - 26, 60, 20).build());
    }

    private ButtonWidget tabButton(int index, String langKey, int x) {
        ButtonWidget b = ButtonWidget.builder(Text.translatable(langKey), btn -> {
            tab = index;
            page = 0;
            selected = 0;
            build();
        }).dimensions(x, top + 8, 140, 20).build();
        b.active = tab != index;
        return b;
    }

    private void buildCrafts() {
        List<CraftCatalog.Entry> entries = CraftCatalog.ENTRIES;
        int pages = Math.max(1, (entries.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index >= entries.size()) break;
            CraftCatalog.Entry en = entries.get(index);
            Text label = new ItemStack(en.result()).getName();
            ButtonWidget b = ButtonWidget.builder(label, btn -> {
                selected = index;
                build();
            }).dimensions(left + 10, top + 36 + i * 22, 135, 20).build();
            b.active = index != selected;
            this.addDrawableChild(b);
        }

        if (pages > 1) {
            ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> {
                page--;
                build();
            }).dimensions(left + 10, top + H - 26, 30, 20).build();
            prev.active = page > 0;
            this.addDrawableChild(prev);
            ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> {
                page++;
                build();
            }).dimensions(left + 115, top + H - 26, 30, 20).build();
            next.active = page < pages - 1;
            this.addDrawableChild(next);
        }

        if (selected >= 0 && selected < entries.size()) {
            CraftCatalog.Entry en = entries.get(selected);
            Recipe<?> recipe = findRecipe(en);
            ButtonWidget craft = ButtonWidget.builder(Text.translatable("screen.arcane.craft"),
                    b -> sendAction(3, en.recipe)).dimensions(left + 160, top + H - 52, 100, 20).build();
            craft.active = recipe != null && this.client != null && this.client.player != null
                    && CraftCatalog.canCraft(this.client.player, recipe);
            this.addDrawableChild(craft);
        }
    }

    private void buildCosmetics() {
        String character = ClientCosmetics.character();
        int row = 0;
        for (Cosmetics.Def def : Cosmetics.ALL) {
            if (!def.form.key.equals(character)) continue;
            boolean owned = ClientCosmetics.owns(def.id);
            boolean worn = ClientCosmetics.worn(def.id);
            Text label = Text.translatable(worn ? "screen.arcane.unequip" : (owned ? "screen.arcane.equip" : "screen.arcane.locked"));
            ButtonWidget b = ButtonWidget.builder(label,
                    btn -> sendAction(worn ? 2 : 1, worn ? def.slot.key : def.id))
                    .dimensions(left + W - 100, top + 82 + row * 24, 90, 20).build();
            b.active = owned;
            this.addDrawableChild(b);
            row++;
            if (row >= 5) break;
        }
    }

    private Recipe<?> findRecipe(CraftCatalog.Entry en) {
        if (this.client == null || this.client.world == null) return null;
        Optional<? extends Recipe<?>> opt = this.client.world.getRecipeManager().get(en.recipeId());
        return opt.isPresent() ? opt.get() : null;
    }

    // ---------- рисование ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF555560);
        ctx.fill(left, top, left + W, top + H, 0xF0101018);

        hoverBoxes.clear();
        hoverStacks.clear();

        if (tab == 0) renderCrafts(ctx);
        else renderCosmetics(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);

        for (int i = 0; i < hoverBoxes.size(); i++) {
            int[] r = hoverBoxes.get(i);
            if (mouseX >= r[0] && mouseX < r[0] + r[2] && mouseY >= r[1] && mouseY < r[1] + r[3]) {
                ctx.drawItemTooltip(this.textRenderer, hoverStacks.get(i), mouseX, mouseY);
                break;
            }
        }
    }

    private void slotBox(DrawContext ctx, int x, int y, ItemStack stack) {
        ctx.fill(x, y, x + 18, y + 18, 0xFF303038);
        ctx.fill(x + 1, y + 1, x + 17, y + 17, 0xFF1A1A22);
        if (stack != null && !stack.isEmpty()) {
            ctx.drawItem(stack, x + 1, y + 1);
            hoverBoxes.add(new int[]{x, y, 18, 18});
            hoverStacks.add(stack);
        }
    }

    private void renderCrafts(DrawContext ctx) {
        List<CraftCatalog.Entry> entries = CraftCatalog.ENTRIES;
        if (selected < 0 || selected >= entries.size()) return;
        CraftCatalog.Entry en = entries.get(selected);
        ItemStack result = new ItemStack(en.result());

        int x0 = left + 160;
        ctx.drawText(this.textRenderer, result.getName(), x0, top + 38, COLOR_GOLD, false);
        ctx.drawText(this.textRenderer,
                Text.translatable("screen.arcane.craft.for", Text.translatable("character.arcane." + en.form.key)),
                x0, top + 50, COLOR_DIM, false);

        Recipe<?> recipe = findRecipe(en);
        if (recipe == null) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.craft.no_recipe"), x0, top + 80, COLOR_DIM, false);
            return;
        }

        // сетка 3x3
        int gx = x0;
        int gy = top + 68;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) slotBox(ctx, gx + c * 19, gy + r * 19, ItemStack.EMPTY);
        }
        List<Ingredient> ings = recipe.getIngredients();
        int width = recipe instanceof ShapedRecipe sr ? sr.getWidth() : 3;
        for (int i = 0; i < ings.size(); i++) {
            ItemStack[] options = ings.get(i).getMatchingStacks();
            if (options.length == 0) continue;
            ItemStack shown = options[(int) ((Util.getMeasuringTimeMs() / 1000L) % options.length)];
            int col = i % width;
            int row = i / width;
            if (col > 2 || row > 2) continue;
            slotBox(ctx, gx + col * 19, gy + row * 19, shown);
        }

        // стрелка и результат
        ctx.drawText(this.textRenderer, Text.literal("->"), gx + 3 * 19 + 8, gy + 24, COLOR_TEXT, false);
        slotBox(ctx, gx + 3 * 19 + 32, gy + 19, result);

        boolean can = this.client != null && this.client.player != null && CraftCatalog.canCraft(this.client.player, recipe);
        if (!can) {
            ctx.drawText(this.textRenderer, Text.translatable("message.arcane.craft_missing"),
                    x0, top + H - 66, 0xFFFF6060, false);
        }
    }

    private void renderCosmetics(DrawContext ctx, int mouseX, int mouseY) {
        String character = ClientCosmetics.character();

        // предпросмотр: игрок с надетыми аксессуарами
        if (this.client != null && this.client.player != null) {
            int px = left + 70;
            int py = top + 190;
            ctx.fill(left + 10, top + 36, left + 130, top + 200, 0xFF14141C);
            InventoryScreen.drawEntity(ctx, px, py, 60, (float) (px - mouseX), (float) (py - 90 - mouseY), this.client.player);
        }

        int x0 = left + 140;
        if (character.equals("none")) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.no_character"), x0, top + 40, COLOR_DIM, false);
            return;
        }
        ctx.drawText(this.textRenderer,
                Text.translatable("screen.arcane.character", Text.translatable("character.arcane." + character)),
                x0, top + 38, COLOR_GOLD, false);

        // слот "Лицо"
        ItemStack wornFace = ItemStack.EMPTY;
        for (Cosmetics.Def def : Cosmetics.ALL) {
            if (def.slot == Cosmetics.Slot.FACE && def.form.key.equals(character) && ClientCosmetics.worn(def.id)) {
                wornFace = new ItemStack(def.item());
            }
        }
        ctx.drawText(this.textRenderer, Text.translatable(Cosmetics.Slot.FACE.langKey()), x0, top + 54, COLOR_TEXT, false);
        slotBox(ctx, x0 + 40, top + 49, wornFace);
        if (wornFace.isEmpty()) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.slot_empty"), x0 + 64, top + 54, COLOR_DIM, false);
        } else {
            ctx.drawText(this.textRenderer, wornFace.getName(), x0 + 64, top + 54, COLOR_DIM, false);
        }

        ctx.fill(x0, top + 74, left + W - 10, top + 75, 0xFF555560);

        // список аксессуаров персонажа
        int row = 0;
        boolean anyLocked = false;
        for (Cosmetics.Def def : Cosmetics.ALL) {
            if (!def.form.key.equals(character)) continue;
            ItemStack stack = new ItemStack(def.item());
            boolean owned = ClientCosmetics.owns(def.id);
            anyLocked |= !owned;
            int y = top + 82 + row * 24;
            slotBox(ctx, x0, y + 1, stack);
            ctx.drawText(this.textRenderer, stack.getName(), x0 + 24, y + 2, owned ? COLOR_TEXT : COLOR_DIM, false);
            ctx.drawText(this.textRenderer, Text.translatable(def.slot.langKey()), x0 + 24, y + 12, COLOR_DIM, false);
            row++;
            if (row >= 5) break;
        }
        if (row == 0) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.no_cosmetics"), x0, top + 84, COLOR_DIM, false);
        } else if (anyLocked) {
            List<net.minecraft.text.OrderedText> lines = this.textRenderer.wrapLines(
                    Text.translatable("screen.arcane.locked_hint"), W - 150);
            int y = top + H - 26 - lines.size() * 10 - 4;
            for (net.minecraft.text.OrderedText line : lines) {
                ctx.drawText(this.textRenderer, line, x0, y, COLOR_DIM, false);
                y += 10;
            }
        }
    }
}

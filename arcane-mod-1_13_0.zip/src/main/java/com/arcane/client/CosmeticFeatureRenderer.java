package com.arcane.client;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Рисует аксессуары кастомизации на игроке (сейчас - маску на лице). Работает отдельно от превращения:
 * маска видна и в обычном виде Эйро, и в форме демона (тогда игрок и так рисуется на 15% больше).
 */
public class CosmeticFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    public CosmeticFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        if (player.isInvisible()) return;
        String face = ClientCosmetics.face(player.getUuid());
        if (face.isEmpty()) return;

        if (face.equals("oni_mask")) {
            boolean demon = ClientForms.get(player.getUuid()) == 2;   // Эйро в форме демона
            matrices.push();
            this.getContextModel().head.rotate(matrices);   // следует за поворотом и наклоном головы
            OniMaskModel.render(matrices, vertexConsumers, light, demon ? OniMaskModel.DEMON : OniMaskModel.HUMAN);
            matrices.pop();
        }
    }
}

package com.arcane.client;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Маска Они: изогнутая "оболочка" из квадратиков, на которую натянута текстура (фото маски).
 * Координаты - в единицах модели головы (1/16 блока): лицо игрока смотрит в -Z, голова 8x8x8 с центром у шеи.
 * Середина маски выпирает вперёд, края (уши и рога) отгибаются назад, чтобы не уходить в голову.
 */
public final class OniMaskModel {
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/oni_mask.png");

    /** Подгонка под версию Эйро: [dy, dz, scale]. Эйро в форме демона чуть больше и кожа толще. */
    public static final float[] HUMAN = {0.0f, 0.0f, 1.0f};
    public static final float[] DEMON = {0.0f, -0.12f, 1.02f};

    private static final float WIDTH = 12.2f;       // вся картинка (рога и уши) по ширине
    private static final int COLS = 16;
    private static final float[] V = rowEdges();    // границы рядов по высоте картинки (0..1)
    private static final int ROWS = V.length - 1;

    private OniMaskModel() {}

    private static float[] rowEdges() {
        float forehead = 170.0f / 900.0f;   // на этой высоте картинки заканчиваются рога и начинается лоб
        float[] e = new float[13];
        e[0] = 0.0f;
        e[1] = forehead * 0.5f;
        e[2] = forehead;
        for (int k = 1; k <= 10; k++) e[2 + k] = forehead + (1.0f - forehead) * k / 10.0f;
        return e;
    }

    /** Высота (ось Y, вниз положительная) точки картинки: рога вытянуты вверх, лицо вписано в голову. */
    private static float yOf(float v) {
        float forehead = 170.0f / 900.0f;
        if (v <= forehead) return -12.8f + (v / forehead) * (-8.6f + 12.8f);
        return -8.6f + ((v - forehead) / (1.0f - forehead)) * (1.2f + 8.6f);
    }

    /** Глубина (ось Z): впереди лица выпуклость, дальше к ушам и рогам изгиб назад. */
    private static float zOf(float x) {
        float ax = Math.abs(x);
        if (ax <= 4.1f) {
            float t = ax / 4.1f;
            return -4.55f - 0.45f * (1.0f - t * t);
        }
        float t = (ax - 4.1f) / (WIDTH / 2.0f - 4.1f);
        return -4.55f + 2.4f * t * t;
    }

    /** Рисует маску в системе координат головы (после ModelPart.rotate головы). */
    public static void render(MatrixStack matrices, VertexConsumerProvider vcp, int light, float[] variant) {
        float dy = variant[0];
        float dz = variant[1];
        float s = variant[2];

        matrices.push();
        matrices.scale(1.0f / 16.0f, 1.0f / 16.0f, 1.0f / 16.0f);

        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));

        for (int r = 0; r < ROWS; r++) {
            float v0 = V[r];
            float v1 = V[r + 1];
            float y0 = yOf(v0) * s + dy;
            float y1 = yOf(v1) * s + dy;
            for (int c = 0; c < COLS; c++) {
                float u0 = c / (float) COLS;
                float u1 = (c + 1) / (float) COLS;
                float x0 = (u0 - 0.5f) * WIDTH * s;
                float x1 = (u1 - 0.5f) * WIDTH * s;
                float z0 = zOf(x0) * s + dz;
                float z1 = zOf(x1) * s + dz;

                vertex(vc, pos, nrm, x0, y0, z0, u0, v0, light);
                vertex(vc, pos, nrm, x0, y1, z0, u0, v1, light);
                vertex(vc, pos, nrm, x1, y1, z1, u1, v1, light);
                vertex(vc, pos, nrm, x1, y0, z1, u1, v0, light);
            }
        }
        matrices.pop();
    }

    private static void vertex(VertexConsumer vc, Matrix4f pos, Matrix3f nrm,
                               float x, float y, float z, float u, float v, int light) {
        vc.vertex(pos, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(nrm, 0.0f, 0.0f, -1.0f)
                .next();
    }
}

package com.arcane.client;

import com.arcane.ArcaneMod;
import com.arcane.ModEntities;
import com.arcane.Packets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public class ArcaneClient implements ClientModInitializer {
    public static final EntityModelLayer SAIR_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume"), "main");
    public static final EntityModelLayer EIRO_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "eiro_overlay"), "main");
    // варианты для скинов с тонкими руками (Alex)
    public static final EntityModelLayer SAIR_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_slim"), "main");
    public static final EntityModelLayer EIRO_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "eiro_overlay_slim"), "main");
    public static final EntityModelLayer JESTER_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "jester_glow"), "main");
    public static final EntityModelLayer JESTER_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "jester_glow_slim"), "main");
    public static final EntityModelLayer SAIR_UP_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_up"), "main");
    public static final EntityModelLayer SAIR_UP_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_up_slim"), "main");
    public static final EntityModelLayer KING_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "king_overlay"), "main");
    public static final EntityModelLayer KING_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "king_overlay_slim"), "main");
    public static final EntityModelLayer MECHA_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "mecha_plating"), "main");
    public static final EntityModelLayer MECHA_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "mecha_plating_slim"), "main");

    public static final EntityModelLayer COFFIN_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "fovius_coffin"), "main");

    private static KeyBinding transformKey;
    private static KeyBinding abilityKey;
    private static KeyBinding laserKey;
    private static boolean laserDown = false;
    private static boolean abilityDown = false;
    private static KeyBinding slashKey;
    private static KeyBinding kingHornKey;
    private static KeyBinding kingAttackKey;
    private static KeyBinding kingReturnKey;
    private static KeyBinding kingInvisKey;
    private static KeyBinding challengeKey;
    private static KeyBinding menuKey;
    private static boolean slashDown = false;

    @Override
    public void onInitializeClient() {
        // Клавиша превращения (по умолчанию левый Alt, меняется в настройках управления)
        transformKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.transform", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "key.categories.arcane"));

        // Клавиша способности: бросок блока (по умолчанию R)
        abilityKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.ability", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.arcane"));

        // Клавиша лучей Меха (удерживать, по умолчанию G)
        laserKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.laser", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.arcane"));

        // Король: H - Рог, J - Атака защитников, K - Возврат, L - Невидимость (с Желанием)
        kingHornKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.king_horn", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.arcane"));
        kingAttackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.king_attack", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.arcane"));
        kingReturnKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.king_return", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.arcane"));
        kingInvisKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.king_invis", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, "key.categories.arcane"));

        // Улучшенный Саир: V - "Разрез" (удерживать - ещё и вертикальный удар), C - "Вызов" (дуэль)
        slashKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.slash", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.arcane"));
        challengeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.challenge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.arcane"));

        // Меню кастомизации: крафты предметов персонажей и аксессуары (по умолчанию B)
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.arcane"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    client.setScreen(new CustomizationScreen());
                }
            }
            abilityDown = pollKey(abilityKey, abilityDown, Packets.ABILITY, client);
            while (kingHornKey.wasPressed()) sendKing(0, client);
            while (kingAttackKey.wasPressed()) sendKing(1, client);
            while (kingReturnKey.wasPressed()) sendKing(2, client);
            while (kingInvisKey.wasPressed()) sendKing(3, client);
            while (transformKey.wasPressed()) {
                if (client.player != null) {
                    ClientPlayNetworking.send(Packets.TOGGLE, PacketByteBufs.create());
                }
            }
            VoiceHud.tick();
            CardHud.tick();
            MechaHud.tick();
            StaticHud.tick();
            CooldownHud.tick();
            ClientForms.tick();

            boolean slash = slashKey.isPressed() && client.player != null && client.currentScreen == null;
            if (slash != slashDown) {
                slashDown = slash;
                PacketByteBuf sb = PacketByteBufs.create();
                sb.writeBoolean(slash);
                ClientPlayNetworking.send(Packets.SLASH, sb);
            }
            while (challengeKey.wasPressed()) {
                if (client.player != null) ClientPlayNetworking.send(Packets.CHALLENGE, PacketByteBufs.create());
            }

            laserDown = pollKey(laserKey, laserDown, Packets.LASER, client);
        });

        // Данные от сервера
        ClientPlayNetworking.registerGlobalReceiver(Packets.SYNC, (client, handler, buf, sender) -> {
            UUID id = buf.readUuid();
            int form = buf.readInt();
            client.execute(() -> ClientForms.set(id, form));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.VOICE, (client, handler, buf, sender) -> {
            int index = buf.readInt();
            client.execute(() -> VoiceHud.show(index));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.CARDS, (client, handler, buf, sender) -> {
            boolean fresh = buf.readBoolean();
            int n = buf.readInt();
            int[] ids = new int[n];
            int[] ticks = new int[n];
            for (int i = 0; i < n; i++) {
                ids[i] = buf.readInt();
                ticks[i] = buf.readInt();
            }
            client.execute(() -> CardHud.setHand(fresh, ids, ticks));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.MECHA, (client, handler, buf, sender) -> {
            int metal = buf.readInt();
            int formTicks = buf.readInt();
            client.execute(() -> MechaHud.set(metal, formTicks));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.COOLDOWNS, (client, handler, buf, sender) -> {
            int n = buf.readInt();
            java.util.List<String> keys = new java.util.ArrayList<>();
            int[] lefts = new int[n];
            int[] totals = new int[n];
            for (int i = 0; i < n; i++) {
                keys.add(buf.readString());
                lefts[i] = buf.readInt();
                totals[i] = buf.readInt();
            }
            client.execute(() -> CooldownHud.set(keys, lefts, totals));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.STATIC, (client, handler, buf, sender) -> {
            int gauge = buf.readInt();
            int over = buf.readInt();
            client.execute(() -> StaticHud.set(gauge, over));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.RAGE, (client, handler, buf, sender) -> {
            int rage = buf.readInt();
            client.execute(() -> RageHud.set(rage));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.DUEL, (client, handler, buf, sender) -> {
            int wins = buf.readInt();
            int guard = buf.readInt();
            boolean duel = buf.readBoolean();
            client.execute(() -> DuelHud.set(wins, guard, duel));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.COSMETIC_SYNC, (client, handler, buf, sender) -> {
            UUID id = buf.readUuid();
            String face = buf.readString(64);
            client.execute(() -> ClientCosmetics.setFace(id, face));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.COSMETIC_STATE, (client, handler, buf, sender) -> {
            String character = buf.readString(64);
            int nOwned = buf.readInt();
            java.util.List<String> owned = new java.util.ArrayList<>();
            for (int i = 0; i < nOwned; i++) owned.add(buf.readString(64));
            int nWorn = buf.readInt();
            java.util.List<String> worn = new java.util.ArrayList<>();
            for (int i = 0; i < nWorn; i++) worn.add(buf.readString(64));
            client.execute(() -> {
                ClientCosmetics.setState(character, owned, worn);
                if (client.currentScreen instanceof CustomizationScreen screen) screen.refresh();
            });
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ClientCosmetics.clear();
            DuelHud.clear();
            RageHud.clear();
            StaticHud.clear();
            CooldownHud.clear();
            slashDown = false;
            ClientForms.clear();
            CardHud.clear();
            MechaHud.clear();
            laserDown = false;
            abilityDown = false;
        });

        // Модели костюма и кожи
        EntityModelLayerRegistry.registerModelLayer(SAIR_LAYER, () -> createSairLayer(false));
        EntityModelLayerRegistry.registerModelLayer(SAIR_SLIM_LAYER, () -> createSairLayer(true));
        EntityModelLayerRegistry.registerModelLayer(EIRO_LAYER, () -> createEiroLayer(false));
        EntityModelLayerRegistry.registerModelLayer(EIRO_SLIM_LAYER, () -> createEiroLayer(true));
        EntityModelLayerRegistry.registerModelLayer(JESTER_LAYER, () -> createJesterLayer(false));
        EntityModelLayerRegistry.registerModelLayer(JESTER_SLIM_LAYER, () -> createJesterLayer(true));
        EntityModelLayerRegistry.registerModelLayer(SAIR_UP_LAYER, () -> createSairUpLayer(false));
        EntityModelLayerRegistry.registerModelLayer(SAIR_UP_SLIM_LAYER, () -> createSairUpLayer(true));
        EntityRendererRegistry.register(ModEntities.DUELIST, DuelistRenderer::new);
        EntityRendererRegistry.register(ModEntities.LILITH, LilithRenderer::new);
        EntityRendererRegistry.register(ModEntities.OUTLAW, OutlawRenderer::new);
        EntityRendererRegistry.register(ModEntities.GUARDIAN_WARRIOR, ZombieEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.GUARDIAN_ARCHER, SkeletonEntityRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(KING_LAYER, () -> createKingLayer(false));
        EntityModelLayerRegistry.registerModelLayer(KING_SLIM_LAYER, () -> createKingLayer(true));
        EntityModelLayerRegistry.registerModelLayer(COFFIN_LAYER, () -> createCoffinLayer());
        EntityModelLayerRegistry.registerModelLayer(OniMaskModel.LAYER, OniMaskModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(CowboyHatModel.LAYER, CowboyHatModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(MECHA_LAYER, () -> createMechaLayer(false));
        EntityModelLayerRegistry.registerModelLayer(MECHA_SLIM_LAYER, () -> createMechaLayer(true));

        // Ковбойская шляпа Хантера: в руках вместо дробовика рисуется винтовка Винчестер (только внешний вид, механика та же).
        // Модель выбирается по предмету-"оверрайду" в models/item/hunter_shotgun.json.
        net.minecraft.client.item.ModelPredicateProviderRegistry.register(com.arcane.ModItems.HUNTER_SHOTGUN,
                new Identifier(ArcaneMod.MOD_ID, "winchester"),
                (stack, world, entity, seed) -> {
                    net.minecraft.entity.Entity holder = entity != null ? entity : MinecraftClient.getInstance().player;
                    return holder != null && ClientCosmetics.has(holder.getUuid(), "cowboy_hat") ? 1.0f : 0.0f;
                });

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer pr) {
                helper.register(new FormFeatureRenderer(pr, context.getModelLoader()));
                helper.register(new CosmeticFeatureRenderer(pr, context.getModelLoader()));
            }
        });

        HudRenderCallback.EVENT.register(VoiceHud::render);
        HudRenderCallback.EVENT.register(CardHud::render);
        HudRenderCallback.EVENT.register(MechaHud::render);
        HudRenderCallback.EVENT.register(DuelHud::render);
        HudRenderCallback.EVENT.register(RageHud::render);
        HudRenderCallback.EVENT.register(StaticHud::render);
        HudRenderCallback.EVENT.register(CooldownHud::render);
    }

    /** Костюм Саира: "одежда" чуть больше тела + высокая плетёная шляпа вместо головы. Текстура 128x64. */
    private static TexturedModelData createSairLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.3f), slim);
        data.getRoot().addChild("hat",
                ModelPartBuilder.create().uv(64, 0)
                        .cuboid(-5.0f, -11.0f, -5.0f, 10.0f, 12.0f, 10.0f, new Dilation(0.0f)),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 64);
    }

    /**
     * Следит за клавишей и шлёт серверу true при нажатии и false при отпускании.
     * Очень быстрый тап (короче такта) тоже не теряется.
     */
    private static boolean pollKey(KeyBinding key, boolean wasDown, Identifier packetId, MinecraftClient client) {
        boolean tapped = false;
        while (key.wasPressed()) tapped = true;
        boolean down = key.isPressed() && client.player != null && client.currentScreen == null;
        if (tapped && !down && !wasDown) {
            sendKey(packetId, true);
            sendKey(packetId, false);
        } else if (down != wasDown) {
            sendKey(packetId, down);
        }
        return down;
    }

    /** Клавиша, соответствующая умению (для надписи в квадратике отката). */
    public static KeyBinding keyFor(String id) {
        return switch (id) {
            case "transform" -> transformKey;
            case "ability" -> abilityKey;
            case "laser" -> laserKey;
            case "slash" -> slashKey;
            case "challenge" -> challengeKey;
            case "horn" -> kingHornKey;
            case "king_attack" -> kingAttackKey;
            case "king_return" -> kingReturnKey;
            case "king_invis" -> kingInvisKey;
            default -> null;
        };
    }

    private static void sendKing(int action, MinecraftClient client) {
        if (client.player == null || client.currentScreen != null) return;
        PacketByteBuf b = PacketByteBufs.create();
        b.writeInt(action);
        ClientPlayNetworking.send(Packets.KING, b);
    }

    private static void sendKey(Identifier packetId, boolean pressed) {
        PacketByteBuf b = PacketByteBufs.create();
        b.writeBoolean(pressed);
        ClientPlayNetworking.send(packetId, b);
    }

    /** Улучшенный Саир: вместо высокой шляпы широкая японская шляпа Дэву (4 ступени). Текстура 128x64. */
    private static TexturedModelData createSairUpLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.3f), slim);
        data.getRoot().addChild("hat",
                ModelPartBuilder.create()
                        .uv(64, 24).cuboid(-7.0f, -8.0f, -7.0f, 14.0f, 1.0f, 14.0f)
                        .uv(64, 42).cuboid(-5.0f, -10.0f, -5.0f, 10.0f, 2.0f, 10.0f)
                        .uv(64, 55).cuboid(-3.0f, -12.0f, -3.0f, 6.0f, 2.0f, 6.0f)
                        .uv(92, 55).cuboid(-1.0f, -13.0f, -1.0f, 2.0f, 1.0f, 2.0f),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 64);
    }

    /**
     * Король: золотая корона (восемь зубцов) вместо шапки и "скелет" поверх тела для Желания.
     * Текстура 128x64: скелет в обычной раскладке, корона справа.
     */
    private static TexturedModelData createKingLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.3f), slim);
        data.getRoot().addChild("hat",
                ModelPartBuilder.create()
                        .uv(64, 0).cuboid(-4.5f, -9.0f, -4.5f, 9.0f, 2.0f, 9.0f)
                        .uv(64, 12).cuboid(-4.5f, -11.0f, -4.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(2.5f, -11.0f, -4.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(-4.5f, -11.0f, 2.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(2.5f, -11.0f, 2.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(-1.0f, -11.0f, -4.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(-1.0f, -11.0f, 2.5f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(-4.5f, -11.0f, -1.0f, 2.0f, 2.0f, 2.0f)
                        .uv(64, 12).cuboid(2.5f, -11.0f, -1.0f, 2.0f, 2.0f, 2.0f),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 64);
    }

    /** Огромный металлический гроб Фовиуса за спиной (10x24x5, текстура 64x64). */
    private static TexturedModelData createCoffinLayer() {
        ModelData data = new ModelData();
        data.getRoot().addChild("coffin",
                ModelPartBuilder.create().uv(0, 0).cuboid(-5.0f, 0.0f, 0.0f, 10.0f, 24.0f, 5.0f),
                ModelTransform.pivot(0.0f, -3.0f, 2.5f));
        return TexturedModelData.of(data, 64, 64);
    }

    /** Стальная броня Меха и золотые трещины (одна модель, две текстуры). Текстуры 64x64. */
    private static TexturedModelData createMechaLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.28f), slim);
        return TexturedModelData.of(data, 64, 64);
    }

    /** Золотое свечение Шута: тонкий слой чуть шире тела. Текстура 64x64. */
    private static TexturedModelData createJesterLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.12f), slim);
        return TexturedModelData.of(data, 64, 64);
    }

    /** Кожа Эйро: тонкий слой почти вплотную к телу. Текстура 64x64. */
    private static TexturedModelData createEiroLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.08f), slim);
        return TexturedModelData.of(data, 64, 64);
    }
}

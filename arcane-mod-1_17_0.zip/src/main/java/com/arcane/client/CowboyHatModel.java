package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * Ковбойская шляпа Хантера: 3D-модель из блоков - поля с загнутыми боковинами, тулья с вмятиной,
 * тёмная лента, золотая пряжка с аркановым камнем. Текстура 64x64 (assets/arcane/textures/entity/cowboy_hat.png).
 * Размеры - в единицах модели (1/16 блока) относительно головы: верх головы y = -8, лицо смотрит в -Z.
 */
public final class CowboyHatModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "cowboy_hat"), "main");
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/cowboy_hat.png");

    private CowboyHatModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("brim",
                ModelPartBuilder.create().uv(0, 0).cuboid(-6.50f, 0.0f, -7.0f, 13.0f, 1.0f, 13.0f),
                ModelTransform.of(0.0f, -9.30f, 0.0f, 0.0f, 0.0f, 0.0f));
        root.addChild("crown",
                ModelPartBuilder.create().uv(0, 14).cuboid(-4.50f, -13.30f, -4.50f, 9.0f, 4.0f, 9.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        root.addChild("crown_top",
                ModelPartBuilder.create().uv(0, 27).cuboid(-3.50f, -14.30f, -3.50f, 7.0f, 1.0f, 7.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        root.addChild("band",
                ModelPartBuilder.create().uv(0, 35).cuboid(-5.0f, -11.30f, -5.0f, 10.0f, 2.0f, 10.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        root.addChild("curl_l",
                ModelPartBuilder.create().uv(0, 47).cuboid(0.0f, -0.50f, -5.50f, 3.0f, 1.0f, 11.0f),
                ModelTransform.of(5.80f, -9.0f, -0.50f, 0.0f, 0.0f, -0.55f));
        root.addChild("curl_r",
                ModelPartBuilder.create().uv(28, 47).cuboid(-3.0f, -0.50f, -5.50f, 3.0f, 1.0f, 11.0f),
                ModelTransform.of(-5.80f, -9.0f, -0.50f, 0.0f, 0.0f, 0.55f));
        root.addChild("buckle",
                ModelPartBuilder.create().uv(36, 14).cuboid(-1.50f, -11.80f, -5.50f, 3.0f, 3.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        root.addChild("gem",
                ModelPartBuilder.create().uv(46, 14).cuboid(-0.50f, -10.80f, -5.80f, 1.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        return TexturedModelData.of(data, 64, 64);
    }

    /** Рисует шляпу в системе координат головы (после ModelPart.rotate головы). */
    public static void render(ModelPart model, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));
        model.render(matrices, vc, light, OverlayTexture.DEFAULT_UV);
    }
}

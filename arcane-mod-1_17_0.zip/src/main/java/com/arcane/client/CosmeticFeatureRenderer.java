package com.arcane.client;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Рисует аксессуары кастомизации на игроке. Аксессуар виден только пока включено превращение
 * персонажа (Alt): маска Они - только у Эйро в форме демона. В обычном виде ничего не рисуется.
 */
public class CosmeticFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private final ModelPart oniMask;
    private final ModelPart cowboyHat;

    public CosmeticFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context,
                                   EntityModelLoader loader) {
        super(context);
        this.oniMask = loader.getModelPart(OniMaskModel.LAYER);
        this.cowboyHat = loader.getModelPart(CowboyHatModel.LAYER);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        if (player.isInvisible()) return;
        String face = ClientCosmetics.face(player.getUuid());
        if (face.isEmpty()) return;

        int form = ClientForms.get(player.getUuid());
        if (form == 2 && ClientCosmetics.has(player.getUuid(), "oni_mask")) {   // 2 - Эйро в превращении
            matrices.push();
            this.getContextModel().head.rotate(matrices);   // следует за поворотом и наклоном головы
            OniMaskModel.render(this.oniMask, matrices, vertexConsumers, light);
            matrices.pop();
        }
        if (form == 7 && ClientCosmetics.has(player.getUuid(), "cowboy_hat")) {   // 7 - Хантер в превращении
            matrices.push();
            this.getContextModel().head.rotate(matrices);
            if (!player.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD).isEmpty()) {
                matrices.translate(0.0f, -0.0625f, 0.0f);   // шляпа чуть выше, если на голове шлем
            }
            CowboyHatModel.render(this.cowboyHat, matrices, vertexConsumers, light);
            matrices.pop();
        }
    }
}

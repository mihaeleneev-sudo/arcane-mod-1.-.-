package com.arcane;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

/**
 * Квест "Сожги икону": в древнем храме Саира подожги икону - ПКМ по ней огнивом или огненным шаром.
 * Отдельного предмета нет: используется тот же блок иконы, что и для молитв (сам блок остаётся на месте).
 * Награда - Маска Они в меню кастомизации (B). Выполнен ли квест, видно по тому, есть ли маска в гардеробе.
 */
public final class IconQuest {
    public static final String MASK_ID = "oni_mask";

    private IconQuest() {}

    private static boolean isFire(ItemStack s) {
        return s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE);
    }

    /** В какой руке игрок держит огниво или огненный шар (null - ни в какой). Основная рука важнее. */
    public static Hand fireHand(ServerPlayerEntity p) {
        if (isFire(p.getMainHandStack())) return Hand.MAIN_HAND;
        if (isFire(p.getOffHandStack())) return Hand.OFF_HAND;
        return null;
    }

    /** Игрок ударил огнём по иконе. Огниво теряет прочность, шар расходуется (в творческом - нет). */
    public static void burn(ServerPlayerEntity p, Hand hand, BlockPos pos) {
        Cosmetics.Def mask = Cosmetics.byId(MASK_ID);
        if (mask == null) return;
        if (Cosmetics.owns(p, mask)) {
            p.sendMessage(Text.translatable("message.arcane.icon_quest_done"), true);
            return;
        }

        ItemStack held = p.getStackInHand(hand);
        if (!p.getAbilities().creativeMode) {
            if (held.isOf(Items.FIRE_CHARGE)) held.decrement(1);
            else held.damage(1, p, player -> player.sendToolBreakStatus(hand));
        }

        ServerWorld w = p.getServerWorld();
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5;
        w.spawnParticles(ParticleTypes.FLAME, x, y, z, 60, 0.4, 0.5, 0.4, 0.06);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.3, z, 25, 0.4, 0.5, 0.4, 0.03);
        w.playSound(null, pos, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.BLOCKS, 1.0f, 0.7f);
        w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 0.8f, 0.6f);

        Cosmetics.unlock(p, mask);
        p.sendMessage(Text.translatable("message.arcane.icon_burned"), false);
        w.playSound(null, p.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }
}

package com.arcane;

import net.minecraft.advancement.Advancement;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/**
 * Достижения мода. Сами достижения описаны в data/arcane/advancements, а выдаёт их код (триггер "impossible").
 * "Снайперский бред": попасть пулей Хантера по цели с расстояния от SNIPER_DISTANCE блоков.
 * Награда - Ковбойская шляпа в меню кастомизации Хантера (B). Дистанцию можно поменять одной цифрой ниже.
 */
public final class Achievements {
    public static final Identifier SNIPER_ID = new Identifier(ArcaneMod.MOD_ID, "sniper_delirium");
    public static final String SNIPER_CRITERION = "slug_far";
    public static final double SNIPER_DISTANCE = 40.0;
    public static final String HAT_ID = "cowboy_hat";

    private Achievements() {}

    public static void sniperDelirium(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        if (server != null) {
            Advancement adv = server.getAdvancementLoader().get(SNIPER_ID);
            if (adv != null) p.getAdvancementTracker().grantCriterion(adv, SNIPER_CRITERION);
        }
        Cosmetics.Def hat = Cosmetics.byId(HAT_ID);
        if (hat != null && !Cosmetics.owns(p, hat)) Cosmetics.unlock(p, hat);
    }
}

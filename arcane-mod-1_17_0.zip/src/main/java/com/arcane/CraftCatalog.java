package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Список крафтов предметов персонажей для вкладки "Крафты". Сами рецепты лежат в data/arcane/recipes,
 * здесь только перечень: чей предмет и какой рецепт показывать. Крафт из меню использует тот же рецепт.
 */
public final class CraftCatalog {
    public static final class Entry {
        public final Form form;
        public final String recipe;
        private final Supplier<Item> result;

        Entry(Form form, String recipe, Supplier<Item> result) {
            this.form = form;
            this.recipe = recipe;
            this.result = result;
        }

        public Item result() { return result.get(); }

        public Identifier recipeId() { return new Identifier(ArcaneMod.MOD_ID, recipe); }
    }

    public static final List<Entry> ENTRIES = List.of(
            new Entry(Form.ZEUS, "zeus_vest", () -> ModItems.ZEUS_VEST),
            new Entry(Form.KING, "king_crown", () -> ModItems.KING_CROWN),
            new Entry(Form.HUNTER, "forged_documents", () -> ModItems.FORGED_DOCUMENTS),
            new Entry(Form.FOVIUS, "metal_cross", () -> ModItems.METAL_CROSS),
            new Entry(Form.FOVIUS, "sister_soul", () -> ModItems.SISTER_SOUL),
            new Entry(Form.FOVIUS, "iron_coffin", () -> ModItems.IRON_COFFIN),
            new Entry(Form.FOVIUS, "coffin_of_revenge", () -> ModItems.COFFIN_OF_REVENGE)
    );

    private CraftCatalog() {}

    public static Entry find(String recipe) {
        for (Entry e : ENTRIES) if (e.recipe.equals(recipe)) return e;
        return null;
    }

    /**
     * Подбирает по одному предмету из основного инвентаря на каждый ингредиент.
     * Возвращает номера ячеек (по одной на ингредиент) или null, если материалов не хватает.
     */
    public static int[] plan(PlayerInventory inv, List<Ingredient> ingredients) {
        int size = inv.main.size();
        int[] counts = new int[size];
        for (int i = 0; i < size; i++) counts[i] = inv.main.get(i).getCount();

        List<Integer> used = new ArrayList<>();
        for (Ingredient ing : ingredients) {
            if (ing.isEmpty()) continue;
            int found = -1;
            for (int s = 0; s < size; s++) {
                if (counts[s] > 0 && ing.test(inv.main.get(s))) {
                    found = s;
                    break;
                }
            }
            if (found < 0) return null;
            counts[found]--;
            used.add(found);
        }
        int[] result = new int[used.size()];
        for (int i = 0; i < result.length; i++) result[i] = used.get(i);
        return result;
    }

    public static boolean canCraft(PlayerEntity p, Recipe<?> recipe) {
        return plan(p.getInventory(), recipe.getIngredients()) != null;
    }

    /** Крафт из меню: забирает материалы из инвентаря и выдаёт результат. */
    public static void craft(ServerPlayerEntity p, String recipeName) {
        Entry entry = find(recipeName);
        if (entry == null) return;   // только рецепты из списка
        Optional<? extends Recipe<?>> opt = p.getServer().getRecipeManager().get(entry.recipeId());
        if (opt.isEmpty()) return;
        Recipe<?> recipe = opt.get();
        if (recipe.getType() != RecipeType.CRAFTING) return;

        int[] slots = plan(p.getInventory(), recipe.getIngredients());
        if (slots == null) {
            p.sendMessage(Text.translatable("message.arcane.craft_missing"), true);
            return;
        }
        for (int s : slots) p.getInventory().main.get(s).decrement(1);
        ItemStack out = recipe.getOutput(p.getWorld().getRegistryManager()).copy();
        p.getInventory().offerOrDrop(out);
        p.getInventory().markDirty();
        p.sendMessage(Text.translatable("message.arcane.craft_done", out.getName()), true);
    }
}

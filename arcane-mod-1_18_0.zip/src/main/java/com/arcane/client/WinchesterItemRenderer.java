package com.arcane.client;

import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Рисует винчестер как 3D-модель вместо плоской иконки: в руках (от первого лица с прицеливанием, отдачей и работой рычага),
 * в третьем лице, в инвентаре, на земле и в рамке. Анимации берутся из перезарядки дробовика (кулдаун предмета):
 * отдача сразу после выстрела, затем передёргивание рычага и взвод курка.
 */
public class WinchesterItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/winchester.png");
    private static final float COCKED = 0.75f;   // курок взведён
    private static final float FIRED = 0.10f;    // курок спущен
    private static final float LEVER_OPEN = 0.87f;

    private static EntityModelLoader loader;
    private static ModelPart gun;
    private static ModelPart arms;

    /** Вызывается при (пере)создании рендереров сущностей: запоминаем загрузчик моделей и сбрасываем кэш. */
    public static void setLoader(EntityModelLoader l) {
        loader = l;
        gun = null;
        arms = null;
    }

    private static boolean ensureModels() {
        if (loader == null) return false;
        if (gun == null) gun = loader.getModelPart(WinchesterModel.LAYER);
        if (arms == null) arms = loader.getModelPart(WinchesterModel.ARMS_LAYER);
        return true;
    }

    @Override
    public void render(ItemStack stack, ModelTransformationMode mode, MatrixStack m,
                       VertexConsumerProvider vcp, int light, int overlay) {
        if (!ensureModels()) return;
        MinecraftClient mc = MinecraftClient.getInstance();

        boolean first = mode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND;

        float lever = 0.0f;
        float hammer = COCKED;

        m.push();
        m.translate(0.5f, 0.5f, 0.5f);   // отменяем сдвиг центра предмета: начало координат - рука

        if (first && mc.player != null) {
            float td = mc.getTickDelta();
            float side = mode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND ? -1.0f : 1.0f;

            // убираем стандартный взмах предмета рукой: у оружия своя отдача
            float sw = mc.player.getHandSwingProgress(td);
            if (sw > 0.0f) {
                float f = MathHelper.sin(sw * sw * (float) Math.PI);
                float g = MathHelper.sin(MathHelper.sqrt(sw) * (float) Math.PI);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 45.0f));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * 80.0f));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * g * 20.0f));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (-45.0f + 20.0f * f)));
                float l = -0.4f * MathHelper.sin(MathHelper.sqrt(sw) * (float) Math.PI);
                float mm = 0.2f * MathHelper.sin(MathHelper.sqrt(sw) * (float) Math.PI * 2.0f);
                float n = -0.2f * MathHelper.sin(sw * (float) Math.PI);
                m.translate(-side * l, -mm, -n);
            }

            float aim = WinchesterAim.get(td);

            // прогресс перезарядки: 1 сразу после выстрела -> 0 когда готов
            float cd = mc.player.getItemCooldownManager().getCooldownProgress(stack.getItem(), td);
            float t = 1.0f - cd;   // 0..1 с момента выстрела
            boolean reloading = cd > 0.0f;

            // отдача: резкий толчок назад и вверх, быстро затухает
            float rec = reloading ? Math.max(0.0f, 1.0f - t / 0.16f) : 0.0f;
            rec = rec * rec;
            // рычаг: открывается и закрывается на середине перезарядки, курок взводится
            if (reloading) {
                float u = (t - 0.22f) / 0.5f;
                if (u > 0.0f && u < 1.0f) lever = MathHelper.sin(u * (float) Math.PI) * LEVER_OPEN;
                float h = MathHelper.clamp((t - 0.22f) / 0.2f, 0.0f, 1.0f);
                hammer = FIRED + (COCKED - FIRED) * h;
            }

            // положение: от руки к центру экрана при прицеливании (рука у (0.56; -0.52; -0.72) в системе вида)
            m.translate(side * -0.56f * aim, 0.364f * aim, 0.42f * aim);
            float sway = MathHelper.sin((mc.player.age + td) * 0.08f) * 0.004f * (1.0f - 0.7f * aim);
            m.translate(0.0f, sway, 0.0f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 5.0f * (1.0f - aim)));   // от бедра стволом к центру
            m.translate(0.0f, rec * 0.012f, rec * (0.11f - 0.05f * aim));
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rec * (8.0f - 3.0f * aim)));
            m.scale(0.62f, 0.62f, 0.62f);
        } else if (mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND
                || mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND) {
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));   // ствол вперёд по руке
            m.translate(0.0f, 0.0f, -0.05f);
            m.scale(0.55f, 0.55f, 0.55f);
        } else if (mode == ModelTransformationMode.GUI) {
            m.scale(0.42f, 0.42f, 0.42f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(28.0f));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
            m.translate(0.0f, 0.0f, 7.5f / 16.0f);   // центр винтовки в центр иконки
        } else {
            // земля, рамка, голова и т.п.
            m.scale(0.42f, 0.42f, 0.42f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
            m.translate(0.0f, 0.0f, 7.5f / 16.0f);
        }

        gun.getChild("lever").pitch = lever;
        gun.getChild("hammer").pitch = hammer;
        gun.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX)), light, OverlayTexture.DEFAULT_UV);

        if (first && mc.player != null) {
            // руки игрока на оружии (текстура - его скин)
            arms.render(m, vcp.getBuffer(RenderLayer.getEntitySolid(mc.player.getSkinTexture())), light, OverlayTexture.DEFAULT_UV);
        }
        m.pop();
    }
}

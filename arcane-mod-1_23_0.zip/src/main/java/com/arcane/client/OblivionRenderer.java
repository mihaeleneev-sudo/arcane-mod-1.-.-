package com.arcane.client;

import com.arcane.OblivionEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Забвение: кровавая сфера (см. OblivionModel) со светящимися прожилками. */
public class OblivionRenderer extends MobEntityRenderer<OblivionEntity, OblivionModel> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/oblivion.png");

    public OblivionRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new OblivionModel(ctx.getPart(OblivionModel.LAYER)), 0.3f);
        this.addFeature(new OblivionGlowFeature(this));
    }

    @Override
    public Identifier getTexture(OblivionEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(OblivionEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.8f, 1.8f, 1.8f);
    }
}

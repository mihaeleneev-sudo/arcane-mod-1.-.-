package com.arcane.client;

import com.arcane.DiscordEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Раздор - высокая фигура в чёрно-белой броне с красными трещинами: шипастый шлем-корона с крестом,
 * огромный наплечник с шипами справа, рваный плащ, цепи со звёздами на руках.
 * Модель собрана из блоков, текстура 128x128 (textures/entity/discord.png), красное свечение - discord_glow.png.
 * Развёртка и код блока createLayer сгенерированы скриптом, поэтому правьте их вместе.
 */
public class DiscordModel extends EntityModel<DiscordEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(new Identifier("arcane", "discord"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart coatBack;

    public DiscordModel(ModelPart root) {
        super(RenderLayer::getEntityCutoutNoCull);
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.coatBack = this.body.getChild("coat_back");
    }

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData headData = root.addChild("head",
                ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f)
                .uv(32, 0).cuboid(-1.0f, -15.0f, -4.0f, 2.0f, 7.0f, 1.0f)
                .uv(38, 0).cuboid(-4.0f, -12.0f, -4.0f, 1.0f, 4.0f, 1.0f)
                .uv(42, 0).cuboid(3.0f, -12.0f, -4.0f, 1.0f, 4.0f, 1.0f)
                .uv(46, 0).cuboid(-4.0f, -12.0f, 3.0f, 1.0f, 4.0f, 1.0f)
                .uv(50, 0).cuboid(3.0f, -12.0f, 3.0f, 1.0f, 4.0f, 1.0f)
                .uv(54, 0).cuboid(-1.0f, -13.0f, 3.0f, 2.0f, 5.0f, 1.0f)
                .uv(60, 0).cuboid(4.0f, -8.0f, -1.0f, 2.0f, 6.0f, 3.0f)
                .uv(70, 0).cuboid(-6.0f, -8.0f, -1.0f, 2.0f, 6.0f, 3.0f),
                ModelTransform.pivot(0.0f, -3.0f, 0.0f));
        ModelPartData bodyData = root.addChild("body",
                ModelPartBuilder.create()
                .uv(80, 0).cuboid(-5.0f, 0.0f, -2.0f, 10.0f, 12.0f, 5.0f)
                .uv(0, 17).cuboid(-5.0f, 8.0f, -3.0f, 10.0f, 2.0f, 6.0f)
                .uv(32, 17).cuboid(-6.0f, -3.0f, 2.0f, 12.0f, 7.0f, 2.0f)
                .uv(60, 17).cuboid(2.0f, -2.0f, -3.0f, 3.0f, 6.0f, 1.0f)
                .uv(68, 17).cuboid(-5.0f, -2.0f, -3.0f, 3.0f, 6.0f, 1.0f)
                .uv(76, 17).cuboid(-2.0f, 9.0f, -4.0f, 4.0f, 11.0f, 1.0f)
                .uv(86, 17).cuboid(2.0f, 10.0f, -3.0f, 4.0f, 13.0f, 1.0f)
                .uv(96, 17).cuboid(-6.0f, 10.0f, -3.0f, 4.0f, 10.0f, 1.0f),
                ModelTransform.pivot(0.0f, -3.0f, 0.0f));
        ModelPartData coatbackData = bodyData.addChild("coat_back",
                ModelPartBuilder.create()
                .uv(106, 17).cuboid(-6.0f, 0.0f, 0.0f, 3.0f, 17.0f, 1.0f)
                .uv(114, 17).cuboid(-3.0f, 0.0f, 0.0f, 3.0f, 19.0f, 1.0f)
                .uv(0, 37).cuboid(0.0f, 0.0f, 0.0f, 3.0f, 14.0f, 1.0f)
                .uv(8, 37).cuboid(3.0f, 0.0f, 0.0f, 3.0f, 18.0f, 1.0f),
                ModelTransform.pivot(0.0f, 8.0f, 2.0f));
        ModelPartData coatlData = bodyData.addChild("coat_l",
                ModelPartBuilder.create()
                .uv(16, 37).cuboid(0.0f, 0.0f, -2.0f, 1.0f, 15.0f, 5.0f),
                ModelTransform.pivot(5.0f, 8.0f, 0.0f));
        ModelPartData coatrData = bodyData.addChild("coat_r",
                ModelPartBuilder.create()
                .uv(28, 37).cuboid(-1.0f, 0.0f, -2.0f, 1.0f, 12.0f, 5.0f),
                ModelTransform.pivot(-5.0f, 8.0f, 0.0f));
        ModelPartData rightarmData = root.addChild("right_arm",
                ModelPartBuilder.create()
                .uv(40, 37).cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f)
                .uv(56, 37).cuboid(-4.0f, -3.0f, -3.0f, 8.0f, 3.0f, 7.0f)
                .uv(86, 37).cuboid(-4.0f, -9.0f, -3.0f, 2.0f, 6.0f, 1.0f)
                .uv(92, 37).cuboid(-1.0f, -10.0f, 0.0f, 2.0f, 7.0f, 1.0f)
                .uv(98, 37).cuboid(-4.0f, -8.0f, 2.0f, 1.0f, 5.0f, 1.0f)
                .uv(102, 37).cuboid(-9.0f, -3.0f, 0.0f, 5.0f, 1.0f, 1.0f)
                .uv(0, 57).cuboid(-3.0f, 6.0f, -3.0f, 5.0f, 6.0f, 5.0f)
                .uv(20, 57).cuboid(-2.0f, 12.0f, -2.0f, 4.0f, 3.0f, 4.0f)
                .uv(36, 57).cuboid(0.0f, 15.0f, 0.0f, 1.0f, 6.0f, 1.0f)
                .uv(40, 57).cuboid(-1.0f, 21.0f, -1.0f, 3.0f, 3.0f, 3.0f),
                ModelTransform.pivot(-7.0f, -1.0f, 0.0f));
        ModelPartData leftarmData = root.addChild("left_arm",
                ModelPartBuilder.create()
                .uv(52, 57).cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f)
                .uv(68, 57).cuboid(-3.0f, -3.0f, -3.0f, 7.0f, 3.0f, 6.0f)
                .uv(94, 57).cuboid(0.0f, -7.0f, -1.0f, 1.0f, 4.0f, 1.0f)
                .uv(98, 57).cuboid(-2.0f, 6.0f, -3.0f, 5.0f, 6.0f, 5.0f)
                .uv(0, 73).cuboid(-2.0f, 12.0f, -2.0f, 4.0f, 3.0f, 4.0f)
                .uv(16, 73).cuboid(0.0f, 15.0f, 0.0f, 1.0f, 6.0f, 1.0f)
                .uv(20, 73).cuboid(-1.0f, 21.0f, -1.0f, 3.0f, 3.0f, 3.0f),
                ModelTransform.pivot(7.0f, -1.0f, 0.0f));
        ModelPartData rightlegData = root.addChild("right_leg",
                ModelPartBuilder.create()
                .uv(32, 73).cuboid(-2.0f, 0.0f, -2.0f, 5.0f, 15.0f, 5.0f)
                .uv(52, 73).cuboid(-3.0f, 4.0f, -3.0f, 6.0f, 4.0f, 1.0f)
                .uv(66, 73).cuboid(-3.0f, 10.0f, -3.0f, 6.0f, 5.0f, 6.0f),
                ModelTransform.pivot(-2.0f, 9.0f, 0.0f));
        ModelPartData leftlegData = root.addChild("left_leg",
                ModelPartBuilder.create()
                .uv(90, 73).cuboid(-2.0f, 0.0f, -2.0f, 5.0f, 15.0f, 5.0f)
                .uv(110, 73).cuboid(-3.0f, 4.0f, -3.0f, 6.0f, 4.0f, 1.0f)
                .uv(0, 93).cuboid(-3.0f, 10.0f, -3.0f, 6.0f, 5.0f, 6.0f),
                ModelTransform.pivot(3.0f, 9.0f, 0.0f));
        return TexturedModelData.of(data, 128, 128);
    }

    @Override
    public void setAngles(DiscordEntity entity, float limbAngle, float limbDistance, float animationProgress,
                          float headYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0f;
        this.head.yaw = headYaw * rad;
        this.head.pitch = headPitch * rad;

        float swing = MathHelper.cos(limbAngle * 0.6662f) * 1.1f * limbDistance;
        float breathe = MathHelper.sin(animationProgress * 0.067f) * 0.03f;
        this.rightArm.pitch = swing * 0.8f;
        this.leftArm.pitch = -swing * 0.8f;
        this.rightArm.roll = 0.08f + breathe;
        this.leftArm.roll = -0.08f - breathe;
        this.rightLeg.pitch = -swing;
        this.leftLeg.pitch = swing;

        // в бою руки подняты, удар - взмах правой рукой
        if (entity.isAttacking()) {
            this.rightArm.pitch -= 0.7f;
            this.leftArm.pitch -= 0.7f;
        }
        float atk = entity.handSwingProgress;
        if (atk > 0.0f) {
            this.rightArm.pitch = -1.9f * MathHelper.sin(atk * (float) Math.PI);
            this.body.yaw = MathHelper.sin(MathHelper.sqrt(atk) * (float) Math.PI * 2.0f) * 0.2f;
        } else {
            this.body.yaw = 0.0f;
        }

        // плащ отлетает назад при движении
        this.coatBack.pitch = 0.05f + Math.abs(swing) * 0.5f + breathe;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        this.root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}

package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Шкала крови Забвения (слева внизу) и красная пелена кровавой ночи для всех игроков. */
public final class OblivionHud {
    private static final int BAR_W = 100;
    private static int meter = -1;       // -1: Забвения нет
    private static boolean summoned = false;
    private static int night = 0;        // 0 - обычная ночь, 1 - кровавая, 2 - дождь жалит

    private OblivionHud() {}

    public static void set(int m, boolean here) {
        meter = m;
        summoned = here;
    }

    public static void setNight(int state) {
        night = state;
    }

    /** Есть ли у игрока Забвение. */
    public static boolean has() {
        return meter >= 0;
    }

    public static void clear() {
        meter = -1;
        summoned = false;
        night = 0;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        if (night > 0) {
            ctx.fill(0, 0, w, h, 0x2CA01010);
            Text t = Text.translatable(night == 2 ? "hud.arcane.blood_night_sting" : "hud.arcane.blood_night");
            ctx.drawCenteredTextWithShadow(mc.textRenderer, t, w / 2, 12, 0xFFE03030);
        }

        if (meter < 0) return;
        int x = 10;
        int y = h - 58;
        Text title = Text.translatable("hud.arcane.oblivion_blood").append(Text.literal(" " + meter + "/100"));
        ctx.drawTextWithShadow(mc.textRenderer, title, x, y - 11, summoned ? 0xFFE04040 : 0xFF8A5A5A);
        ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
        int fill = BAR_W * Math.max(0, Math.min(100, meter)) / 100;
        ctx.fill(x, y, x + fill, y + 8, meter >= 100 ? 0xFFD02020 : 0xFF8A1010);
        ctx.fill(x, y, x + fill, y + 2, 0xFFFF6060);
        // риски по 10 единиц: столько стоит один страж
        for (int i = 1; i < 10; i++) ctx.fill(x + i * 10, y + 5, x + i * 10 + 1, y + 8, 0x66000000);
    }
}

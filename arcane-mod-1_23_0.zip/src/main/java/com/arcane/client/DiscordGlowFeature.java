package com.arcane.client;

import com.arcane.DiscordEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Светящиеся красные трещины и крест Раздора (светятся в темноте, как глаза паука). */
public class DiscordGlowFeature extends FeatureRenderer<DiscordEntity, DiscordModel> {
    private static final Identifier GLOW = new Identifier("arcane", "textures/entity/discord_glow.png");
    private static final int FULL_BRIGHT = 15728880;

    public DiscordGlowFeature(FeatureRendererContext<DiscordEntity, DiscordModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, DiscordEntity entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress,
                       float headYaw, float headPitch) {
        if (entity.isInvisible()) return;
        this.getContextModel().render(matrices, vertexConsumers.getBuffer(RenderLayer.getEyes(GLOW)),
                FULL_BRIGHT, OverlayTexture.DEFAULT_UV, 1.0f, 1.0f, 1.0f, 1.0f);
    }
}

package com.arcane.client;

import com.arcane.OblivionEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Светящиеся алые прожилки сферы Забвения. */
public class OblivionGlowFeature extends FeatureRenderer<OblivionEntity, OblivionModel> {
    private static final Identifier GLOW = new Identifier("arcane", "textures/entity/oblivion_glow.png");
    private static final int FULL_BRIGHT = 15728880;

    public OblivionGlowFeature(FeatureRendererContext<OblivionEntity, OblivionModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, OblivionEntity entity,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress,
                       float headYaw, float headPitch) {
        if (entity.isInvisible()) return;
        this.getContextModel().render(matrices, vertexConsumers.getBuffer(RenderLayer.getEyes(GLOW)),
                FULL_BRIGHT, OverlayTexture.DEFAULT_UV, 1.0f, 1.0f, 1.0f, 1.0f);
    }
}

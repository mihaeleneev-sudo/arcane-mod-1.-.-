package com.arcane.client;

import com.arcane.DiscordEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Раздор: собственная 3D-модель (см. DiscordModel) с красным свечением трещин и креста. */
public class DiscordRenderer extends MobEntityRenderer<DiscordEntity, DiscordModel> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/discord.png");

    public DiscordRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new DiscordModel(ctx.getPart(DiscordModel.LAYER)), 0.6f);
        this.addFeature(new DiscordGlowFeature(this));
    }

    @Override
    public Identifier getTexture(DiscordEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(DiscordEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(0.92f, 0.92f, 0.92f);
    }
}

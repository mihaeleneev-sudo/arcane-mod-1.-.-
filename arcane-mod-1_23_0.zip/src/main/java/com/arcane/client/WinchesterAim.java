package com.arcane.client;

import com.arcane.ModItems;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/**
 * Прицеливание винчестера (только внешний вид): пока зажат Shift, винтовка выходит в центр экрана, поле зрения сужается.
 * Работает, когда в основной руке дробовик Хантера и надета ковбойская шляпа (то есть показывается винчестер).
 */
public final class WinchesterAim {
    private static float prev = 0.0f;
    private static float cur = 0.0f;

    private WinchesterAim() {}

    public static void tick(MinecraftClient c) {
        prev = cur;
        boolean want = c.player != null
                && c.currentScreen == null
                && c.player.isSneaking()
                && c.player.getMainHandStack().isOf(ModItems.HUNTER_SHOTGUN)
                && ClientCosmetics.has(c.player.getUuid(), "cowboy_hat")
                && c.options.getPerspective().isFirstPerson();
        cur = MathHelper.clamp(cur + (want ? 0.22f : -0.18f), 0.0f, 1.0f);
    }

    /** Плавный прогресс прицеливания 0..1. */
    public static float get(float tickDelta) {
        float a = MathHelper.lerp(tickDelta, prev, cur);
        return a * a * (3.0f - 2.0f * a);
    }

    /** Во сколько раз уменьшить поле зрения (1 - без зума). */
    public static double fovFactor(float tickDelta) {
        return 1.0 - 0.30 * get(tickDelta);
    }
}

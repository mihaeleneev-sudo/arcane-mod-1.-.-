package com.arcane.client;

/** Состояние WA Corporation на клиенте (приходит пакетом WA_STATE) и таймер интерфейса "Карман". */
public final class ClientWa {
    public static boolean accepted = false;
    public static boolean chip = false;
    public static boolean balker = false;
    public static int mask = 0;        // бит 0 - пистолет, 1 - трость, 2 - рация
    public static int pocket = 0;      // выбранное оружие
    public static boolean radioPoint = false;

    public static int pocketMask = 0;
    public static int pocketSel = 0;
    public static int pocketShowTicks = 0;   // сколько ещё тиков показывать "Карман"

    private ClientWa() {}

    public static void clear() {
        accepted = false;
        chip = false;
        balker = false;
        mask = 0;
        pocket = 0;
        radioPoint = false;
        pocketShowTicks = 0;
    }

    public static void showPocket(int m, int sel) {
        pocketMask = m;
        pocketSel = sel;
        pocketShowTicks = 100;
    }
}

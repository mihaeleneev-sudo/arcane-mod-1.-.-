package com.arcane.client;

import com.arcane.Balker;
import com.arcane.ModItems;
import com.arcane.Packets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

/**
 * Меню кресла WA Corporation: установка и снятие Чипа WA, выбор персонажа (девять ячеек, пока открыт Балкер)
 * и покупка улучшений Балкера за изумруды. Все проверки выполняет сервер.
 */
public class WaChairScreen extends Screen {
    private static final int W = 360;
    private static final int H = 240;
    private int left;
    private int top;

    public WaChairScreen() {
        super(Text.translatable("screen.arcane.wa_chair"));
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = (this.height - H) / 2;
        build();
    }

    private static void send(int action, String arg) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(action);
        buf.writeString(arg);
        ClientPlayNetworking.send(Packets.WA_ACTION, buf);
    }

    /** Сервер прислал новое состояние: перестроить кнопки. */
    public void refresh() {
        build();
    }

    private int emeralds() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return 0;
        int n = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isOf(Items.EMERALD)) n += s.getCount();
        }
        return n;
    }

    private void build() {
        this.clearChildren();
        // чип
        if (!ClientWa.chip) {
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_install"),
                    b -> send(Balker.ACT_INSTALL, "")).dimensions(left + W - 130, top + 46, 120, 20).build());
        } else {
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_remove"),
                    b -> send(Balker.ACT_REMOVE, "")).dimensions(left + W - 130, top + 46, 120, 20).build());
            // Балкер
            ButtonWidget pick = ButtonWidget.builder(Text.translatable(ClientWa.balker ? "screen.arcane.wa_selected" : "screen.arcane.wa_select"),
                    b -> send(Balker.ACT_SELECT, "balker")).dimensions(left + 10 + 112, top + 98, 70, 20).build();
            pick.active = !ClientWa.balker || true;
            this.addDrawableChild(pick);
            if (ClientWa.balker) {
                String[] keys = {"pistol", "cane", "radio"};
                for (int i = 0; i < 3; i++) {
                    final String key = keys[i];
                    boolean owned = (ClientWa.mask & (1 << i)) != 0;
                    ButtonWidget buy = ButtonWidget.builder(Text.translatable(owned ? "screen.arcane.wa_bought" : "screen.arcane.wa_buy"),
                            b -> send(Balker.ACT_BUY, key)).dimensions(left + W - 90, top + 148 + i * 26, 80, 20).build();
                    buy.active = !owned && emeralds() >= Balker.EMERALD_PRICE;
                    this.addDrawableChild(buy);
                }
            }
        }
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.arcane.wa_leave"), b -> this.close())
                .dimensions(left + W - 90, top + H - 28, 80, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF5AC8FA);
        ctx.fill(left, top, left + W, top + H, 0xF0101820);
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_chair"), left + 10, top + 10, 0xFF5AC8FA, false);

        // улучшение: Чип WA
        ctx.fill(left + 10, top + 38, left + W - 10, top + 74, 0xFF1A2630);
        ctx.drawText(this.textRenderer, Text.translatable("wa.chip.name"), left + 16, top + 43, 0xFFFFFFFF, false);
        ctx.drawText(this.textRenderer, Text.translatable(ClientWa.chip ? "wa.chip.installed" : "wa.chip.available"),
                left + 16, top + 54, ClientWa.chip ? 0xFF7BE08A : 0xFFFFD060, false);
        ctx.drawText(this.textRenderer, Text.translatable("wa.chip.desc"), left + 16, top + 64, 0xFFA0A0A8, false);

        if (ClientWa.chip) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_title"), left + 10, top + 82, 0xFF5AC8FA, false);
            // девять ячеек: один Балкер
            for (int i = 0; i < 9; i++) {
                int x = left + 10 + (i % 9) * 36;
                int y = top + 94;
                boolean open = i == 0;
                ctx.fill(x, y, x + 32, y + 28, open ? (ClientWa.balker ? 0xFFFFD060 : 0xFF5AC8FA) : 0xFF3A3A44);
                ctx.fill(x + 1, y + 1, x + 31, y + 27, 0xFF14141A);
                if (open) {
                    ctx.drawItem(new ItemStack(ModItems.BALKER_PISTOL), x + 8, y + 6);
                } else {
                    ctx.drawText(this.textRenderer, Text.literal("?"), x + 13, y + 10, 0xFF55555F, false);
                }
            }
            ctx.drawText(this.textRenderer, Text.translatable("character.arcane.balker"), left + 10, top + 126, 0xFFFFFFFF, false);

            if (ClientWa.balker) {
                ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.wa_upgrades"), left + 10, top + 138, 0xFF5AC8FA, false);
                Item[] items = {ModItems.BALKER_PISTOL, ModItems.BALKER_CANE, ModItems.BALKER_RADIO};
                String[] keys = {"pistol", "cane", "radio"};
                for (int i = 0; i < 3; i++) {
                    int y = top + 148 + i * 26;
                    boolean owned = (ClientWa.mask & (1 << i)) != 0;
                    ctx.drawItem(new ItemStack(items[i]), left + 14, y + 2);
                    ctx.drawText(this.textRenderer, Text.translatable("wa.upgrade." + keys[i]), left + 36, y + 2,
                            owned ? 0xFF7BE08A : 0xFFFFFFFF, false);
                    ctx.drawText(this.textRenderer, Text.translatable("wa.upgrade." + keys[i] + ".desc"), left + 36, y + 12,
                            0xFFA0A0A8, false);
                    ctx.drawText(this.textRenderer, Text.translatable("wa.price", Balker.EMERALD_PRICE), left + W - 170, y + 6,
                            0xFF7BE08A, false);
                }
            }
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        send(Balker.ACT_LEAVE, "");
    }
}

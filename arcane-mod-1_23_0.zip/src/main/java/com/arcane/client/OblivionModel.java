package com.arcane.client;

import com.arcane.OblivionEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Забвение - кровавая сфера: три вложенных куба, повёрнутых друг относительно друга (издали выглядят как шар),
 * и четыре капли крови, вращающиеся вокруг. Текстура 64x32 (textures/entity/oblivion.png),
 * свечение - oblivion_glow.png с той же раскладкой.
 */
public class OblivionModel extends EntityModel<OblivionEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(new Identifier("arcane", "oblivion"), "main");
    private static final float CENTER_Y = 19.5f;

    private final ModelPart root;
    private final ModelPart core;
    private final ModelPart shellA;
    private final ModelPart shellB;
    private final ModelPart[] drops = new ModelPart[4];

    public OblivionModel(ModelPart root) {
        super(RenderLayer::getEntityCutoutNoCull);
        this.root = root;
        this.core = root.getChild("core");
        this.shellA = root.getChild("shell_a");
        this.shellB = root.getChild("shell_b");
        for (int i = 0; i < drops.length; i++) drops[i] = root.getChild("drop" + i);
    }

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("core",
                ModelPartBuilder.create().uv(0, 0).cuboid(-4.0f, -4.0f, -4.0f, 8.0f, 8.0f, 8.0f),
                ModelTransform.pivot(0.0f, CENTER_Y, 0.0f));
        root.addChild("shell_a",
                ModelPartBuilder.create().uv(0, 16).cuboid(-4.0f, -4.0f, -4.0f, 8.0f, 8.0f, 8.0f),
                ModelTransform.pivot(0.0f, CENTER_Y, 0.0f));
        root.addChild("shell_b",
                ModelPartBuilder.create().uv(32, 0).cuboid(-3.0f, -3.0f, -3.0f, 6.0f, 6.0f, 6.0f),
                ModelTransform.pivot(0.0f, CENTER_Y, 0.0f));
        for (int i = 0; i < 4; i++) {
            root.addChild("drop" + i,
                    ModelPartBuilder.create().uv(32 + 8 * i, 16).cuboid(-1.0f, -1.0f, -1.0f, 2.0f, 2.0f, 2.0f),
                    ModelTransform.pivot(0.0f, CENTER_Y, 0.0f));
        }
        return TexturedModelData.of(data, 64, 32);
    }

    @Override
    public void setAngles(OblivionEntity entity, float limbAngle, float limbDistance, float animationProgress,
                          float headYaw, float headPitch) {
        float t = animationProgress;
        float quarter = (float) Math.PI / 4.0f;
        this.core.yaw = t * 0.03f;
        this.core.pitch = t * 0.02f;
        this.shellA.yaw = quarter + t * 0.05f;
        this.shellA.roll = t * 0.02f;
        this.shellB.pitch = quarter + t * 0.04f;
        this.shellB.roll = quarter - t * 0.03f;
        for (int i = 0; i < drops.length; i++) {
            float a = t * 0.07f + i * (float) (Math.PI / 2.0);
            this.drops[i].setPivot(MathHelper.cos(a) * 8.0f, CENTER_Y + MathHelper.sin(t * 0.09f + i * 1.7f) * 2.5f,
                    MathHelper.sin(a) * 8.0f);
            this.drops[i].yaw = a;
        }
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        this.root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}

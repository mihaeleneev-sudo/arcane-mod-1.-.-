package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

/**
 * 3D-модель винтовки Винчестер (рычажная): ствол, магазинная трубка, цевьё, ствольная коробка с аркановыми камнями,
 * деревянный приклад с латунным затыльником, подвижные рычаг и курок. Плюс две руки (текстура - скин игрока).
 * Система координат: x вправо, y вверх, z назад, ствол смотрит в -z, начало у рукояти; единицы - 1/16 блока.
 * Файл создан генератором вместе с текстурой assets/arcane/textures/entity/winchester.png (128x64).
 */
public final class WinchesterModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "winchester"), "main");
    public static final EntityModelLayer ARMS_LAYER =
            new EntityModelLayer(new Identifier("arcane", "winchester_arms"), "main");

    private WinchesterModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_receiver = root.addChild("receiver",
                ModelPartBuilder.create().uv(88, 0).cuboid(-1.0f, -2.5f, -4.0f, 2.0f, 5.0f, 8.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_barrel = root.addChild("barrel",
                ModelPartBuilder.create().uv(0, 0).cuboid(-1.0f, 0.5f, -26.0f, 2.0f, 2.0f, 22.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_tube = root.addChild("tube",
                ModelPartBuilder.create().uv(48, 0).cuboid(-1.0f, -1.5f, -22.0f, 2.0f, 2.0f, 18.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_forend = root.addChild("forend",
                ModelPartBuilder.create().uv(0, 24).cuboid(-1.5f, -2.0f, -17.0f, 3.0f, 3.0f, 9.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_band = root.addChild("band",
                ModelPartBuilder.create().uv(68, 24).cuboid(-1.5f, -2.0f, -21.0f, 3.0f, 5.0f, 1.0f).uv(88, 24).cuboid(-1.5f, -2.0f, -8.0f, 3.0f, 3.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_sights = root.addChild("sights",
                ModelPartBuilder.create().uv(96, 24).cuboid(-0.5f, 2.5f, -25.0f, 1.0f, 2.0f, 1.0f).uv(108, 24).cuboid(-1.5f, 2.5f, -8.0f, 3.0f, 1.0f, 1.0f).uv(116, 24).cuboid(-1.5f, 3.5f, -8.0f, 1.0f, 1.0f, 1.0f).uv(120, 24).cuboid(0.5f, 3.5f, -8.0f, 1.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_trigger = root.addChild("trigger",
                ModelPartBuilder.create().uv(100, 24).cuboid(-0.5f, -4.5f, 1.5f, 1.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_gems = root.addChild("gems",
                ModelPartBuilder.create().uv(124, 24).cuboid(1.0f, -0.5f, -2.0f, 1.0f, 1.0f, 1.0f).uv(0, 36).cuboid(-2.0f, -0.5f, -2.0f, 1.0f, 1.0f, 1.0f).uv(80, 24).cuboid(1.0f, -2.0f, 0.0f, 1.0f, 2.0f, 3.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_stock = root.addChild("stock",
                ModelPartBuilder.create().uv(24, 24).cuboid(-1.0f, -3.0f, 0.0f, 2.0f, 5.0f, 5.0f).uv(108, 0).cuboid(-1.0f, -4.5f, 5.0f, 2.0f, 7.0f, 6.0f).uv(58, 24).cuboid(-1.0f, -5.0f, 11.0f, 2.0f, 8.0f, 1.0f),
                ModelTransform.of(0.0f, 0.5f, 4.0f, 0.1f, 0.0f, 0.0f));
        ModelPartData p_lever = root.addChild("lever",
                ModelPartBuilder.create().uv(64, 24).cuboid(-0.5f, -6.0f, -0.5f, 1.0f, 6.0f, 1.0f).uv(38, 24).cuboid(-0.5f, -6.5f, -0.5f, 1.0f, 1.0f, 9.0f).uv(76, 24).cuboid(-0.5f, -6.5f, 7.5f, 1.0f, 5.0f, 1.0f),
                ModelTransform.of(0.0f, -2.5f, -2.5f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_hammer = root.addChild("hammer",
                ModelPartBuilder.create().uv(104, 24).cuboid(-0.5f, 0.0f, -0.5f, 1.0f, 2.0f, 1.0f),
                ModelTransform.of(0.0f, 1.0f, 3.5f, 0.9f, 0.0f, 0.0f));
        return TexturedModelData.of(data, 128, 64);
    }

    /** Две руки игрока (рисуются текстурой скина, 64x64): правая у приклада, левая под цевьём. */
    public static TexturedModelData createArmsLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_arm_r = root.addChild("arm_r",
                ModelPartBuilder.create().uv(40, 16).cuboid(-2.0f, -12.0f, -2.0f, 4.0f, 12.0f, 4.0f),
                ModelTransform.of(0.0f, -1.5f, 6.0f, -0.93f, 0.0f, -0.2f));
        ModelPartData p_arm_l = root.addChild("arm_l",
                ModelPartBuilder.create().uv(40, 16).cuboid(-2.0f, -12.0f, -2.0f, 4.0f, 12.0f, 4.0f),
                ModelTransform.of(0.0f, -3.0f, -12.0f, -0.9f, 0.0f, 0.38f));
        return TexturedModelData.of(data, 64, 64);
    }
}

package com.arcane.client;

import com.arcane.BloodGuardEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Кровавый страж: гуманоид из крови (своя текстура поверх модели игрока). */
public class BloodGuardRenderer extends BipedEntityRenderer<BloodGuardEntity, PlayerEntityModel<BloodGuardEntity>> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/blood_guard.png");

    public BloodGuardRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(BloodGuardEntity entity) {
        return TEXTURE;
    }
}

package com.arcane.client;

import com.arcane.ModItems;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** "Карман": три ячейки слева на экране (пистолет, трость, рация), выбранная подсвечена. */
public final class PocketHud {
    private PocketHud() {}

    public static void tick() {
        if (ClientWa.pocketShowTicks > 0) ClientWa.pocketShowTicks--;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (ClientWa.pocketShowTicks <= 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        int h = mc.getWindow().getScaledHeight();
        int x = 6;
        int y0 = h / 2 - 33;
        ItemStack[] stacks = {new ItemStack(ModItems.BALKER_PISTOL), new ItemStack(ModItems.BALKER_CANE),
                new ItemStack(ModItems.BALKER_RADIO)};
        String[] keys = {"pistol", "cane", "radio"};
        ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("hud.arcane.pocket"), x, y0 - 12, 0xFF9AD8FF);
        for (int i = 0; i < 3; i++) {
            int y = y0 + i * 24;
            boolean owned = (ClientWa.pocketMask & (1 << i)) != 0;
            boolean sel = ClientWa.pocketSel == i && owned;
            ctx.fill(x - 1, y - 1, x + 23, y + 23, sel ? 0xFFFFD060 : 0xFF3A3A44);
            ctx.fill(x, y, x + 22, y + 22, owned ? 0xCC10181E : 0xCC0A0A0E);
            if (owned) {
                ctx.drawItem(stacks[i], x + 3, y + 3);
            } else {
                ctx.drawText(mc.textRenderer, Text.literal("?"), x + 8, y + 7, 0xFF55555F, false);
            }
            ctx.drawText(mc.textRenderer, Text.literal(String.valueOf(i + 1)), x + 2, y + 2, owned ? 0xFFFFFFFF : 0xFF55555F, true);
            if (sel) {
                ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("wa.upgrade." + keys[i]), x + 28, y + 7, 0xFFFFD060);
            }
        }
    }
}

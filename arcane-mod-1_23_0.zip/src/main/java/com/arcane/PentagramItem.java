package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Пентаграмма из девяти Крови: ПКМ - с шансом 50% игрок умирает, иначе получает Забвение. */
public class PentagramItem extends Item {
    public PentagramItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (Forms.character(sp) != Form.NONE || Discord.hasCurse(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.oblivion_has_power"), true);
                return TypedActionResult.fail(stack);
            }
            if (Oblivion.has(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.already_has"), true);
                return TypedActionResult.fail(stack);
            }
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
            sp.getServerWorld().spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, sp.getX(), sp.getY() + 0.2, sp.getZ(), 40, 0.8, 0.1, 0.8, 0.02);
            if (sp.getRandom().nextFloat() < Oblivion.PENTAGRAM_DEATH_CHANCE) {
                sp.sendMessage(Text.translatable("message.arcane.oblivion_pentagram_death"), false);
                sp.kill();
            } else {
                Oblivion.grant(sp);
            }
        }
        return TypedActionResult.success(stack);
    }
}

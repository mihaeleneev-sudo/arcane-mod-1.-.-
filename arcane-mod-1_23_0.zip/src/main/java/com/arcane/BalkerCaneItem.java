package com.arcane;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.util.Rarity;

/** Трость Балкера: ближний бой. Вращение - на G, во время него удар превращается в контрудар. */
public class BalkerCaneItem extends SwordItem {
    public BalkerCaneItem() {
        super(ToolMaterials.IRON, 1, -2.2f, new FabricItemSettings().maxCount(1).rarity(Rarity.UNCOMMON));
    }
}

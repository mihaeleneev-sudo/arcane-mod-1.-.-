package com.arcane;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.entity.ai.brain.EntityLookTarget;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.WalkTarget;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.village.VillagerProfession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Зелёный житель (деревенский дурачок) сам подходит к игроку без персонажа и предлагает работу в WA Corporation.
 * Каждый житель предлагает один раз за мир (см. {@link WaState}); ответ даётся кнопками ДА / НЕТ в чате.
 */
public final class WaRecruit {
    private static final double SEARCH_RADIUS = 24.0;
    private static final double OFFER_DISTANCE = 3.5;
    private static final int APPROACH_TIMEOUT = 20 * 40;

    private static final class Approach {
        final UUID villager;
        final int startTick;

        Approach(UUID villager, int startTick) {
            this.villager = villager;
            this.startTick = startTick;
        }
    }

    private static final Map<UUID, Approach> APPROACH = new HashMap<>();

    private WaRecruit() {}

    private static boolean eligible(ServerPlayerEntity p, WaState.Data d) {
        return p.isAlive() && !p.isSpectator() && !d.pending && !d.accepted
                && Forms.character(p) == Form.NONE && !Discord.hasCurse(p) && !Oblivion.has(p)
                && !WaRoom.inRoom(p);
    }

    private static boolean isGreen(VillagerEntity v) {
        return v.isAlive() && !v.isBaby() && v.getVillagerData().getProfession() == VillagerProfession.NITWIT;
    }

    public static void tick(MinecraftServer server, int t) {
        if (t % 10 != 0) return;
        WaState st = WaState.get(server);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            WaState.Data d = st.of(id);
            if (!eligible(p, d)) {
                APPROACH.remove(id);
                continue;
            }
            Approach ap = APPROACH.get(id);
            VillagerEntity v = null;
            if (ap != null) {
                if (p.getServerWorld().getEntity(ap.villager) instanceof VillagerEntity found && isGreen(found)
                        && !st.wasOffered(found.getUuid())) {
                    v = found;
                }
                if (v == null || t - ap.startTick > APPROACH_TIMEOUT) {
                    APPROACH.remove(id);
                    continue;
                }
            } else if (t % 40 == 0) {
                List<VillagerEntity> list = p.getServerWorld().getEntitiesByClass(VillagerEntity.class,
                        p.getBoundingBox().expand(SEARCH_RADIUS),
                        e -> isGreen(e) && !st.wasOffered(e.getUuid()));
                double best = Double.MAX_VALUE;
                for (VillagerEntity e : list) {
                    double dist = e.squaredDistanceTo(p);
                    if (dist < best) {
                        best = dist;
                        v = e;
                    }
                }
                if (v == null) continue;
                APPROACH.put(id, new Approach(v.getUuid(), t));
            } else {
                continue;
            }

            if (v.squaredDistanceTo(p) <= OFFER_DISTANCE * OFFER_DISTANCE) {
                APPROACH.remove(id);
                offer(p, v, st, d);
            } else {
                v.getBrain().remember(MemoryModuleType.WALK_TARGET, new WalkTarget(new EntityLookTarget(p, false), 0.65f, 2));
                v.getBrain().remember(MemoryModuleType.LOOK_TARGET, new EntityLookTarget(p, true));
                v.getNavigation().startMovingTo(p, 0.65);
            }
        }
    }

    private static void offer(ServerPlayerEntity p, VillagerEntity v, WaState st, WaState.Data d) {
        st.markOffered(v.getUuid());
        d.pending = true;
        st.markDirty();

        MutableText yes = Text.translatable("wa.offer.yes").setStyle(Style.EMPTY
                .withColor(Formatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/arcanewa yes"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.translatable("wa.offer.yes_hint"))));
        MutableText no = Text.translatable("wa.offer.no").setStyle(Style.EMPTY
                .withColor(Formatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/arcanewa no"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.translatable("wa.offer.no_hint"))));

        p.sendMessage(Text.translatable("wa.offer.title").formatted(Formatting.GREEN, Formatting.BOLD), false);
        p.sendMessage(Text.translatable("wa.offer.text", p.getName()).formatted(Formatting.WHITE), false);
        p.sendMessage(Text.literal("  ").append(yes).append(Text.literal("    ")).append(no), false);
        p.getServerWorld().playSound(null, v.getX(), v.getY(), v.getZ(), SoundEvents.ENTITY_VILLAGER_TRADE,
                SoundCategory.NEUTRAL, 1.0f, 1.0f);
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("arcanewa")
                .then(CommandManager.literal("yes").executes(ctx -> {
                    answer(ctx.getSource().getPlayerOrThrow(), true);
                    return 1;
                }))
                .then(CommandManager.literal("no").executes(ctx -> {
                    answer(ctx.getSource().getPlayerOrThrow(), false);
                    return 1;
                }))
                .then(CommandManager.literal("room").executes(ctx -> {
                    returnToRoom(ctx.getSource().getPlayerOrThrow());
                    return 1;
                })));
    }

    private static void answer(ServerPlayerEntity p, boolean yes) {
        WaState st = WaState.get(p.getServer());
        WaState.Data d = st.of(p.getUuid());
        if (!d.pending) return;
        d.pending = false;
        if (yes) {
            d.accepted = true;
            st.markDirty();
            p.sendMessage(Text.translatable("wa.offer.accepted"), false);
            WaRoom.enter(p);
            Balker.sendState(p);
        } else {
            st.markDirty();
            p.sendMessage(Text.translatable("wa.offer.declined"), false);
        }
    }

    /** Тем, кто уже согласился, комната доступна снова: через зелёного жителя или /arcanewa room. */
    public static boolean returnToRoom(ServerPlayerEntity p) {
        WaState.Data d = WaState.get(p.getServer()).of(p.getUuid());
        if (!d.accepted) {
            p.sendMessage(Text.translatable("message.arcane.wa_not_hired"), true);
            return false;
        }
        if (WaRoom.inRoom(p)) return false;
        WaRoom.enter(p);
        Balker.sendState(p);
        return true;
    }

    public static boolean isGreenVillager(net.minecraft.entity.Entity e) {
        return e instanceof VillagerEntity v && isGreen(v);
    }
}

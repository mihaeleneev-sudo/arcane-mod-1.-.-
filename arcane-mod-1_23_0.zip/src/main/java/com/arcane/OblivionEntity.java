package com.arcane;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

/**
 * Забвение - летающая кровавая сфера. Парит над плечом владельца и никого не бьёт:
 * защищает её стража (см. {@link BloodGuardEntity}), а управляет ею владелец (см. {@link Oblivion}).
 * Не сохраняется в мире: исчезает вместе с выходом владельца.
 */
public class OblivionEntity extends PathAwareEntity {
    public UUID owner;

    public OblivionEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
        this.setCustomNameVisible(true);
        this.setPersistent();
        this.setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createOblivionAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 50.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.4)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0);
    }

    public ServerPlayerEntity ownerPlayer() {
        MinecraftServer s = this.getServer();
        if (s == null || owner == null) return null;
        return s.getPlayerManager().getPlayer(owner);
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        ServerPlayerEntity o = ownerPlayer();
        if (o == null || !o.isAlive()) {
            this.discard();
            return;
        }
        // парит по кругу над плечом владельца
        double angle = this.age * 0.06;
        double tx = o.getX() + Math.cos(angle) * 1.3;
        double ty = o.getY() + 2.4 + Math.sin(this.age * 0.1) * 0.15;
        double tz = o.getZ() + Math.sin(angle) * 1.3;
        Vec3d to = new Vec3d(tx - this.getX(), ty - this.getY(), tz - this.getZ());
        if (to.length() > 24.0) {
            this.requestTeleport(tx, ty, tz);
            this.setVelocity(Vec3d.ZERO);
        } else {
            Vec3d v = to.multiply(0.25);
            double len = v.length();
            if (len > 0.9) v = v.multiply(0.9 / len);
            this.setVelocity(v);
        }
    }

    /** ПКМ окровавленным кинжалом владельца - жертвоприношение. */
    @Override
    protected ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!stack.isOf(ModItems.BLOODY_DAGGER)) return ActionResult.PASS;
        if (!this.getWorld().isClient && player instanceof ServerPlayerEntity sp && owner != null && sp.getUuid().equals(owner)) {
            Oblivion.offerDagger(sp, this, hand);
        }
        return ActionResult.success(this.getWorld().isClient);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (owner != null && source.getAttacker() instanceof PlayerEntity pl && pl.getUuid().equals(owner)) return false;
        // парит где угодно: не задыхается в стене и не тонет
        if (source == this.getDamageSources().inWall() || source == this.getDamageSources().drown()) return false;
        boolean hurt = super.damage(source, amount);
        if (hurt && amount > 0.0f) Oblivion.onEntityHurt(this);
        return hurt;
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        Oblivion.onEntityDied(this);
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        Oblivion.onEntityRemoved(this);
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBreatheInWater() {
        return true;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }
}

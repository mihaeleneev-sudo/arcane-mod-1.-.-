package com.arcane;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Кровавый страж Забвения. Защищает сферу, а не игрока: бьёт врагов возле неё и тех, кто её ударил.
 * Владельца не трогает и от него не страдает.
 */
public class BloodGuardEntity extends PathAwareEntity {
    public UUID owner;

    public BloodGuardEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createGuardAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 24.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.2);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
        this.goalSelector.add(5, new StayNearSphereGoal(this));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        // враги возле сферы (в кровавую ночь они заражены и сферу не трогают, стража их тоже)
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, LivingEntity.class, 5, true, false,
                e -> e instanceof Monster && !Oblivion.nightActiveIn(this.getWorld()) && nearSphere(e, 10.0)));
    }

    private boolean nearSphere(LivingEntity e, double radius) {
        OblivionEntity s = sphere();
        return s != null && e.squaredDistanceTo(s) <= radius * radius;
    }

    public OblivionEntity sphere() {
        return owner == null ? null : Oblivion.sphereOf(owner);
    }

    public ServerPlayerEntity ownerPlayer() {
        MinecraftServer s = this.getServer();
        if (s == null || owner == null) return null;
        return s.getPlayerManager().getPlayer(owner);
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        OblivionEntity s = sphere();
        if (s == null) {
            this.discard();
            return;
        }
        LivingEntity tgt = this.getTarget();
        if (tgt != null && (!tgt.isAlive() || tgt.squaredDistanceTo(s) > 16.0 * 16.0)) {
            this.setTarget(null);
            tgt = null;
        }
        // защищает сферу от того, кто её ударил
        if (tgt == null && this.age % 10 == 0) {
            LivingEntity att = s.getAttacker();
            if (att != null && att.isAlive() && !(att instanceof OblivionEntity) && !(att instanceof BloodGuardEntity)
                    && !(att.getUuid().equals(owner)) && att.squaredDistanceTo(s) < 16.0 * 16.0) {
                this.setTarget(att);
            }
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (owner != null && source.getAttacker() instanceof PlayerEntity pl && pl.getUuid().equals(owner)) return false;
        return super.damage(source, amount);
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }

    /** Держится у сферы (по земле возле владельца), при большом отрыве телепортируется. */
    private static final class StayNearSphereGoal extends Goal {
        private final BloodGuardEntity mob;

        StayNearSphereGoal(BloodGuardEntity mob) {
            this.mob = mob;
            this.setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            OblivionEntity s = mob.sphere();
            return s != null && mob.getTarget() == null && mob.squaredDistanceTo(s) > 49.0;
        }

        @Override
        public boolean shouldContinue() {
            OblivionEntity s = mob.sphere();
            return s != null && mob.getTarget() == null && !mob.getNavigation().isIdle() && mob.squaredDistanceTo(s) > 12.0;
        }

        @Override
        public void tick() {
            OblivionEntity s = mob.sphere();
            ServerPlayerEntity o = mob.ownerPlayer();
            if (s == null || o == null) return;
            if (mob.squaredDistanceTo(o) > 24.0 * 24.0) {
                mob.requestTeleport(o.getX(), o.getY(), o.getZ());
            } else {
                mob.getNavigation().startMovingTo(o, 1.25);
            }
        }
    }
}

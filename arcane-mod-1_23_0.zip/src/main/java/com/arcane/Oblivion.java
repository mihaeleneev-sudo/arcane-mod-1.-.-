package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * "Всадники тьмы": Забвение - летающая кровавая сфера, которая следует за владельцем.
 * <p>
 * Клавиши: Alt - позвать/отпустить, R - 1 "Запас" (4 здоровья владельца -> +5 крови), G - 2 "Стража"
 * (до 3 кровавых существ по 10 крови), V - 3 "Кровавая ночь" (при полной шкале; повторное нажатие -
 * кровавый дождь начинает жалить). Кинжал для жертвоприношений: убил им врага - он стал окровавленным,
 * ПКМ по Забвению с таким кинжалом - +10 крови.
 */
public final class Oblivion {
    public static final String CURSE_TAG = "arcane_oblivion_curse";

    public static final int SUMMON_COOLDOWN = 10 * 20;
    public static final int STORE_COOLDOWN = 2 * 20;
    public static final int GUARD_COOLDOWN = 12 * 20;
    public static final int NIGHT_COOLDOWN = 3 * 20;

    public static final float METER_MAX = 100.0f;
    private static final float STORE_HP = 4.0f;
    private static final float STORE_GAIN = 5.0f;
    private static final float DAGGER_GAIN = 10.0f;
    private static final float GUARD_COST = 10.0f;
    private static final int GUARD_COUNT = 3;
    public static final float PENTAGRAM_DEATH_CHANCE = 0.5f;

    private static final long NIGHT_START = 13000L;
    private static final long NIGHT_END = 23000L;
    private static final int NIGHT_MAX_TICKS = 10200;
    private static final float RAIN_DAMAGE = 1.0f;

    private static final DustParticleEffect BLOOD_DUST = new DustParticleEffect(new Vector3f(0.65f, 0.02f, 0.02f), 1.2f);
    private static final DustParticleEffect DARK_BLOOD = new DustParticleEffect(new Vector3f(0.35f, 0.0f, 0.03f), 1.0f);

    private static final Map<UUID, OblivionEntity> ENTITIES = new HashMap<>();
    private static final Map<UUID, List<BloodGuardEntity>> GUARDS = new HashMap<>();
    private static final Map<UUID, Float> METER = new HashMap<>();
    private static final Map<UUID, Integer> SUMMON_CD = new HashMap<>();
    private static final Map<UUID, Integer> STORE_CD = new HashMap<>();
    private static final Map<UUID, Integer> GUARD_CD = new HashMap<>();
    private static final Map<UUID, Integer> NIGHT_CD = new HashMap<>();
    private static final Set<UUID> SENT = new HashSet<>();

    // кровавая ночь (одна на сервер)
    private static UUID nightOwner = null;
    private static RegistryKey<World> nightWorld = null;
    private static int nightStartTick = 0;
    private static boolean nightDamage = false;

    // речь
    private static final Map<UUID, Integer> SAY_CD = new HashMap<>();
    private static final Map<UUID, Integer> NEXT_IDLE = new HashMap<>();
    private static final Map<UUID, Integer> HURT_CD = new HashMap<>();
    private static final Map<UUID, Integer> OWNER_LOW_CD = new HashMap<>();
    private static final Map<String, Integer> LAST_SAY = new HashMap<>();
    private static final Set<UUID> FULL_SAID = new HashSet<>();
    private static final Set<UUID> REVIVED = new HashSet<>();
    public static final double SAY_RADIUS = 20.0;

    private static final Map<String, Integer> SAY_COUNT = new HashMap<>();
    static {
        String[] cats = {"summon", "dismiss", "idle", "hurt", "low_hp", "owner_low", "skill1", "skill1_low", "guards", "guards_few", "guards_none", "dagger_bloody", "offer", "meter_full", "night", "night_damage", "night_end", "revive", "awake"};
        int[] counts = {3, 2, 6, 3, 2, 3, 3, 2, 3, 2, 2, 3, 3, 3, 3, 2, 2, 2, 3};
        for (int i = 0; i < cats.length; i++) SAY_COUNT.put(cats[i], counts[i]);
    }

    private Oblivion() {}

    // ---------- состояние ----------

    public static boolean has(PlayerEntity p) {
        return p.getCommandTags().contains(CURSE_TAG);
    }

    private static int left(Map<UUID, Integer> map, UUID id, int now) {
        return Math.max(0, map.getOrDefault(id, 0) - now);
    }

    public static int summonLeft(UUID id, int now) { return left(SUMMON_CD, id, now); }

    public static int storeLeft(UUID id, int now) { return left(STORE_CD, id, now); }

    public static int guardLeft(UUID id, int now) { return left(GUARD_CD, id, now); }

    public static int nightLeft(UUID id, int now) { return left(NIGHT_CD, id, now); }

    public static boolean nightActive() {
        return nightOwner != null;
    }

    public static boolean nightActiveIn(World w) {
        return nightOwner != null && w.getRegistryKey() == nightWorld;
    }

    /** Во время кровавой ночи зараженные враги не трогают владельца, сферу и стражу. */
    public static boolean shields(MobEntity mob, LivingEntity target) {
        if (nightOwner == null || mob.getWorld().isClient || mob.getWorld().getRegistryKey() != nightWorld) return false;
        if (target instanceof OblivionEntity || target instanceof BloodGuardEntity) return true;
        return target instanceof PlayerEntity p && p.getUuid().equals(nightOwner);
    }

    public static OblivionEntity sphereOf(UUID owner) {
        return entityOf(owner);
    }

    private static OblivionEntity entityOf(UUID owner) {
        OblivionEntity e = ENTITIES.get(owner);
        if (e != null && (e.isRemoved() || !e.isAlive())) {
            ENTITIES.remove(owner);
            return null;
        }
        return e;
    }

    private static void bar(ServerPlayerEntity p, String key, Object... args) {
        p.sendMessage(Text.translatable(key, args), true);
    }

    private static float meter(UUID id) {
        return METER.getOrDefault(id, 0.0f);
    }

    // ---------- получение ----------

    /** Пентаграмма сработала: игрок получает Забвение. */
    public static void grant(ServerPlayerEntity p) {
        Discord.clear(p);
        p.addCommandTag(CURSE_TAG);
        METER.put(p.getUuid(), 0.0f);
        p.sendMessage(Text.translatable("message.arcane.oblivion_awake"), false);
        if (entityOf(p.getUuid()) == null) summon(p, "awake");
    }

    public static void clear(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (id.equals(nightOwner) && p.getServer() != null) endNight(p.getServer());
        p.removeScoreboardTag(CURSE_TAG);
        dismiss(id);
        METER.remove(id);
        REVIVED.remove(id);
        FULL_SAID.remove(id);
        if (SENT.remove(id)) sendState(p, -1, false);
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (has(oldP)) newP.addCommandTag(CURSE_TAG);
    }

    public static void onPlayerDeath(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (has(p)) REVIVED.add(id);
        FULL_SAID.remove(id);
        dismiss(id);
        METER.put(id, 0.0f);
    }

    public static void onDisconnect(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        dismiss(id);
        SENT.remove(id);
        if (id.equals(nightOwner) && p.getServer() != null) endNight(p.getServer());
    }

    public static void onJoin(ServerPlayerEntity p) {
        sendNight(p, nightState());
    }

    // ---------- Alt ----------

    public static boolean onAlt(ServerPlayerEntity p) {
        if (!has(p) || Forms.character(p) != Form.NONE) return false;
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        OblivionEntity e = entityOf(id);
        if (e != null) {
            say(p, "dismiss", true);
            dismiss(id);
            SUMMON_CD.put(id, now + SUMMON_COOLDOWN);
            bar(p, "message.arcane.oblivion_dismissed");
            return true;
        }
        int cd = summonLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return true;
        }
        summon(p, REVIVED.remove(id) ? "revive" : "summon");
        return true;
    }

    // ---------- призыв ----------

    private static void summon(ServerPlayerEntity p, String sayCategory) {
        ServerWorld w = p.getServerWorld();
        OblivionEntity e = ModEntities.OBLIVION.create(w);
        if (e == null) return;
        e.owner = p.getUuid();
        e.refreshPositionAndAngles(p.getX(), p.getY() + 2.4, p.getZ(), p.getYaw(), 0.0f);
        w.spawnEntity(e);
        ENTITIES.put(p.getUuid(), e);
        w.spawnParticles(BLOOD_DUST, e.getX(), e.getY() + 0.5, e.getZ(), 30, 0.5, 0.5, 0.5, 0.03);
        w.spawnParticles(ParticleTypes.CRIMSON_SPORE, e.getX(), e.getY() + 0.5, e.getZ(), 12, 0.4, 0.4, 0.4, 0.02);
        w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_ILLUSIONER_PREPARE_BLINDNESS, SoundCategory.PLAYERS, 1.0f, 0.6f);
        giveDagger(p);
        NEXT_IDLE.put(p.getUuid(), p.getServer().getTicks() + 1200 + p.getRandom().nextInt(1200));
        if (sayCategory != null) say(p, sayCategory, true);
    }

    private static void dismiss(UUID owner) {
        OblivionEntity e = ENTITIES.remove(owner);
        if (e != null && !e.isRemoved()) e.discard();
        discardGuards(owner);
    }

    private static void discardGuards(UUID owner) {
        List<BloodGuardEntity> list = GUARDS.remove(owner);
        if (list == null) return;
        for (BloodGuardEntity g : list) if (!g.isRemoved()) g.discard();
    }

    public static void onEntityRemoved(OblivionEntity e) {
        if (e.owner == null) return;
        ENTITIES.remove(e.owner, e);
        discardGuards(e.owner);
    }

    /** Сферу разбили: отдыхает до следующего призыва. */
    public static void onEntityDied(OblivionEntity e) {
        if (e.owner == null) return;
        MinecraftServer server = e.getServer();
        if (server != null) SUMMON_CD.put(e.owner, server.getTicks() + SUMMON_COOLDOWN);
        ServerPlayerEntity o = e.ownerPlayer();
        if (o != null) bar(o, "message.arcane.oblivion_died");
    }

    private static OblivionEntity requireEntity(ServerPlayerEntity p) {
        OblivionEntity e = entityOf(p.getUuid());
        if (e == null) bar(p, "message.arcane.oblivion_not_here");
        return e;
    }

    // ---------- кинжал ----------

    private static boolean isDagger(ItemStack s) {
        return s.isOf(ModItems.SACRIFICE_DAGGER) || s.isOf(ModItems.BLOODY_DAGGER);
    }

    private static void giveDagger(ServerPlayerEntity p) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (isDagger(p.getInventory().getStack(i))) return;
        }
        ItemStack dagger = new ItemStack(ModItems.SACRIFICE_DAGGER);
        if (!p.getInventory().insertStack(dagger)) p.dropItem(dagger, false);
        bar(p, "message.arcane.oblivion_dagger_given");
    }

    /** Владелец убил врага кинжалом: клинок стал кровавым. */
    public static void onKill(LivingEntity victim, DamageSource source) {
        if (!(source.getAttacker() instanceof ServerPlayerEntity p) || source.getSource() != p || p == victim) return;
        if (!has(p)) return;
        if (!(victim instanceof Monster) && !(victim instanceof PlayerEntity)) return;
        if (!p.getMainHandStack().isOf(ModItems.SACRIFICE_DAGGER)) return;
        p.setStackInHand(Hand.MAIN_HAND, new ItemStack(ModItems.BLOODY_DAGGER));
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(BLOOD_DUST, victim.getX(), victim.getY() + 0.8, victim.getZ(), 14, 0.3, 0.4, 0.3, 0.03);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.0f, 0.6f);
        bar(p, "message.arcane.oblivion_dagger_bloody");
        say(p, "dagger_bloody", false);
    }

    /** ПКМ по Забвению окровавленным кинжалом: +10 крови, клинок снова чистый. */
    public static void offerDagger(ServerPlayerEntity p, OblivionEntity e, Hand hand) {
        UUID id = p.getUuid();
        if (meter(id) >= METER_MAX) {
            bar(p, "message.arcane.oblivion_meter_full");
            return;
        }
        p.setStackInHand(hand, new ItemStack(ModItems.SACRIFICE_DAGGER));
        METER.put(id, Math.min(METER_MAX, meter(id) + DAGGER_GAIN));
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(BLOOD_DUST, e.getX(), e.getY() + 0.5, e.getZ(), 24, 0.4, 0.4, 0.4, 0.04);
        w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_GENERIC_DRINK, SoundCategory.PLAYERS, 1.0f, 0.5f);
        bar(p, "message.arcane.oblivion_offered", (int) meter(id));
        say(p, "offer", true);
    }

    // ---------- умение 1: Запас (R) ----------

    public static void skill1(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        OblivionEntity e = requireEntity(p);
        if (e == null) return;
        int cd = storeLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return;
        }
        if (meter(id) >= METER_MAX) {
            bar(p, "message.arcane.oblivion_meter_full");
            return;
        }
        if (p.getHealth() <= STORE_HP + 1.0f) {
            bar(p, "message.arcane.oblivion_hp_low");
            say(p, "skill1_low", false);
            return;
        }
        STORE_CD.put(id, now + STORE_COOLDOWN);
        p.damage(p.getDamageSources().magic(), STORE_HP);
        METER.put(id, Math.min(METER_MAX, meter(id) + STORE_GAIN));
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(BLOOD_DUST, p.getX(), p.getY() + 1.2, p.getZ(), 16, 0.3, 0.4, 0.3, 0.03);
        w.spawnParticles(BLOOD_DUST, e.getX(), e.getY() + 0.5, e.getZ(), 12, 0.3, 0.3, 0.3, 0.03);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PHANTOM_BITE, SoundCategory.PLAYERS, 1.0f, 0.7f);
        bar(p, "message.arcane.oblivion_stored", (int) meter(id));
        say(p, "skill1", true);
    }

    // ---------- умение 2: Стража (G) ----------

    public static void skill2(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        OblivionEntity e = requireEntity(p);
        if (e == null) return;
        int cd = guardLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return;
        }
        int afford = (int) (meter(id) / GUARD_COST);
        if (afford <= 0) {
            bar(p, "message.arcane.oblivion_no_blood");
            say(p, "guards_none", false);
            return;
        }
        int n = Math.min(GUARD_COUNT, afford);
        METER.put(id, meter(id) - n * GUARD_COST);
        GUARD_CD.put(id, now + GUARD_COOLDOWN);

        ServerWorld w = p.getServerWorld();
        List<BloodGuardEntity> list = GUARDS.computeIfAbsent(id, k -> new ArrayList<>());
        for (int i = 0; i < n; i++) {
            BloodGuardEntity g = ModEntities.BLOOD_GUARD.create(w);
            if (g == null) continue;
            double a = i * (Math.PI * 2.0 / n) + p.getRandom().nextDouble();
            g.owner = id;
            g.refreshPositionAndAngles(p.getX() + Math.cos(a) * 2.0, p.getY(), p.getZ() + Math.sin(a) * 2.0, p.getYaw(), 0.0f);
            if (!w.isSpaceEmpty(g)) g.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw(), 0.0f);
            w.spawnEntity(g);
            list.add(g);
            w.spawnParticles(BLOOD_DUST, g.getX(), g.getY() + 1.0, g.getZ(), 18, 0.3, 0.6, 0.3, 0.03);
        }
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_EVOKER_PREPARE_SUMMON, SoundCategory.PLAYERS, 1.0f, 0.6f);
        bar(p, "message.arcane.oblivion_guards", n, (int) meter(id));
        say(p, n < GUARD_COUNT ? "guards_few" : "guards", true);
    }

    // ---------- умение 3: Кровавая ночь (V) ----------

    public static void skill3(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        OblivionEntity e = requireEntity(p);
        if (e == null) return;
        int cd = nightLeft(id, now);
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return;
        }
        if (nightActive()) {
            if (!id.equals(nightOwner)) {
                bar(p, "message.arcane.oblivion_night_busy");
                return;
            }
            NIGHT_CD.put(id, now + NIGHT_COOLDOWN);
            if (nightDamage) {
                bar(p, "message.arcane.oblivion_rain_already");
                return;
            }
            nightDamage = true;
            broadcastNightState(p.getServer());
            bar(p, "message.arcane.oblivion_rain_on");
            say(p, "night_damage", true);
            return;
        }
        if (meter(id) < METER_MAX) {
            bar(p, "message.arcane.oblivion_night_low", (int) meter(id));
            return;
        }
        if (p.getServerWorld().getRegistryKey() != World.OVERWORLD) {
            bar(p, "message.arcane.oblivion_night_world");
            return;
        }
        NIGHT_CD.put(id, now + NIGHT_COOLDOWN);
        startNight(p, now);
    }

    private static void startNight(ServerPlayerEntity p, int now) {
        ServerWorld w = p.getServerWorld();
        UUID id = p.getUuid();
        METER.put(id, 0.0f);
        long time = w.getTimeOfDay();
        long tod = time % 24000L;
        if (tod < NIGHT_START || tod >= NIGHT_END) {
            w.setTimeOfDay(time - tod + NIGHT_START);
        }
        int len = (int) (NIGHT_END - (w.getTimeOfDay() % 24000L));
        w.setWeather(0, len, true, false);
        nightOwner = id;
        nightWorld = w.getRegistryKey();
        nightStartTick = now;
        nightDamage = false;

        MinecraftServer server = p.getServer();
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
            sp.sendMessage(Text.translatable("message.arcane.oblivion_night_start", p.getDisplayName()), false);
            sp.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 70, 20));
            sp.networkHandler.sendPacket(new SubtitleS2CPacket(Text.translatable("title.arcane.blood_night_sub")));
            sp.networkHandler.sendPacket(new TitleS2CPacket(Text.translatable("title.arcane.blood_night")));
            sp.playSound(SoundEvents.ENTITY_WITHER_SPAWN, 0.5f, 0.6f);
        }
        broadcastNightState(server);
        say(p, "night", true);
    }

    private static void endNight(MinecraftServer server) {
        UUID owner = nightOwner;
        ServerWorld w = nightWorld != null ? server.getWorld(nightWorld) : null;
        nightOwner = null;
        nightWorld = null;
        nightDamage = false;
        if (w != null) w.setWeather(0, 0, false, false);
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
            sp.sendMessage(Text.translatable("message.arcane.oblivion_night_end"), false);
        }
        broadcastNightState(server);
        if (owner != null) {
            ServerPlayerEntity o = server.getPlayerManager().getPlayer(owner);
            if (o != null && has(o)) say(o, "night_end", true);
        }
    }

    private static int nightState() {
        if (nightOwner == null) return 0;
        return nightDamage ? 2 : 1;
    }

    private static void broadcastNightState(MinecraftServer server) {
        int state = nightState();
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) sendNight(sp, state);
    }

    private static void sendNight(ServerPlayerEntity p, int state) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(state);
        ServerPlayNetworking.send(p, Packets.NIGHT, buf);
    }

    private static Set<MobEntity> monstersNearPlayers(ServerWorld w) {
        Set<MobEntity> out = new HashSet<>();
        for (ServerPlayerEntity pl : w.getPlayers()) {
            out.addAll(w.getEntitiesByClass(MobEntity.class, pl.getBoundingBox().expand(48.0),
                    m -> m instanceof Monster && m.isAlive()));
        }
        return out;
    }

    private static void tickNight(MinecraftServer server, int t) {
        if (nightOwner == null) return;
        ServerWorld w = server.getWorld(nightWorld);
        if (w == null) {
            endNight(server);
            return;
        }
        long tod = w.getTimeOfDay() % 24000L;
        if (t - nightStartTick > NIGHT_MAX_TICKS || tod < NIGHT_START || tod >= NIGHT_END) {
            endNight(server);
            return;
        }
        if (t % 100 == 0 && !w.isRaining()) w.setWeather(0, (int) (NIGHT_END - tod), true, false);

        if (t % 4 == 0) {
            for (ServerPlayerEntity pl : w.getPlayers()) {
                w.spawnParticles(BLOOD_DUST, pl.getX(), pl.getY() + 3.0, pl.getZ(), 6, 6.0, 2.5, 6.0, 0.0);
            }
        }

        // враги целиком перестают трогать владельца, сферу и стражу (основное - в MobEntityMixin)
        if (t % 10 == 0) {
            for (MobEntity m : monstersNearPlayers(w)) {
                LivingEntity tgt = m.getTarget();
                if (tgt != null && shields(m, tgt)) m.setTarget(null);
            }
        }

        // мобы сильнее и заражены
        if (t % 40 == 0) {
            for (MobEntity m : monstersNearPlayers(w)) {
                m.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 100, 1, false, false));
                m.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 0, false, false));
                m.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 0, false, false));
                w.spawnParticles(DARK_BLOOD, m.getX(), m.getY() + m.getHeight() * 0.6, m.getZ(), 5, 0.3, 0.4, 0.3, 0.01);
            }
        }

        // кровавый дождь жалит врагов и игроков (кроме владельца), если над ними открыто небо
        if (nightDamage && t % 40 == 20) {
            Set<LivingEntity> victims = new HashSet<>();
            for (ServerPlayerEntity pl : w.getPlayers()) {
                victims.addAll(w.getEntitiesByClass(LivingEntity.class, pl.getBoundingBox().expand(48.0),
                        e -> e.isAlive() && !e.isSpectator() && (e instanceof Monster || e instanceof PlayerEntity)
                                && !(e instanceof OblivionEntity) && !(e instanceof BloodGuardEntity)
                                && !e.getUuid().equals(nightOwner)));
            }
            for (LivingEntity v : victims) {
                if (w.isSkyVisible(v.getBlockPos())) v.damage(w.getDamageSources().magic(), RAIN_DAMAGE);
            }
        }
    }

    // ---------- речь ----------

    public static void say(ServerPlayerEntity owner, String category, boolean force) {
        Integer n = SAY_COUNT.get(category);
        if (n == null || owner.getServer() == null) return;
        UUID id = owner.getUuid();
        int now = owner.getServer().getTicks();
        if (!force && now < SAY_CD.getOrDefault(id, 0)) return;
        SAY_CD.put(id, now + 60);

        int idx = 1 + owner.getRandom().nextInt(n);
        String lastKey = id + category;
        if (n > 1 && LAST_SAY.getOrDefault(lastKey, 0) == idx) idx = idx % n + 1;
        LAST_SAY.put(lastKey, idx);

        Text msg = Text.translatable("message.arcane.oblivion_say", Text.translatable("entity.arcane.oblivion"),
                Text.translatable("oblivion.say." + category + "." + idx));
        for (ServerPlayerEntity sp : owner.getServerWorld().getPlayers()) {
            if (sp.squaredDistanceTo(owner) <= SAY_RADIUS * SAY_RADIUS) sp.sendMessage(msg, false);
        }
    }

    /** Сфера получила урон. */
    public static void onEntityHurt(OblivionEntity e) {
        ServerPlayerEntity o = e.ownerPlayer();
        if (o == null || e.getServer() == null) return;
        UUID id = o.getUuid();
        int now = e.getServer().getTicks();
        if (now < HURT_CD.getOrDefault(id, 0)) return;
        HURT_CD.put(id, now + 400);
        say(o, e.getHealth() < e.getMaxHealth() * 0.3f ? "low_hp" : "hurt", false);
    }

    private static void tickSpeech(ServerPlayerEntity p, int t) {
        UUID id = p.getUuid();
        OblivionEntity e = entityOf(id);
        if (meter(id) >= METER_MAX) {
            if (FULL_SAID.add(id) && e != null) say(p, "meter_full", false);
        } else {
            FULL_SAID.remove(id);
        }
        if (e == null) return;
        if (p.getHealth() < 6.0f && t >= OWNER_LOW_CD.getOrDefault(id, 0)) {
            OWNER_LOW_CD.put(id, t + 600);
            say(p, "owner_low", false);
        }
        if (t >= NEXT_IDLE.getOrDefault(id, Integer.MAX_VALUE)) {
            NEXT_IDLE.put(id, t + 1200 + p.getRandom().nextInt(1200));
            say(p, "idle", false);
        }
    }

    // ---------- сеть и тик ----------

    private static void sendState(ServerPlayerEntity p, int meter, boolean summoned) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(meter);
        buf.writeBoolean(summoned);
        ServerPlayNetworking.send(p, Packets.OBLIVION, buf);
    }

    public static void tick(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            if (!has(p)) {
                if (SENT.remove(id)) sendState(p, -1, false);
                continue;
            }
            if (!p.isAlive()) continue;

            OblivionEntity e = entityOf(id);
            if (e != null && e.getWorld() != p.getWorld()) {
                dismiss(id);
                summon(p, null);
                e = entityOf(id);
            }
            tickSpeech(p, t);

            if (t % 10 == 0) {
                sendState(p, (int) meter(id), e != null);
                SENT.add(id);
            }
        }
        if (t % 40 == 0) {
            for (List<BloodGuardEntity> list : GUARDS.values()) list.removeIf(g -> g.isRemoved() || !g.isAlive());
        }
        tickNight(server, t);
    }
}

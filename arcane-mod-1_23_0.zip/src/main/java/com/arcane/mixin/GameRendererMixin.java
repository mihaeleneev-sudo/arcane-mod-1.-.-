package com.arcane.mixin;

import com.arcane.client.WinchesterAim;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Зум при прицеливании винчестера. Если сигнатура метода не совпадёт, внедрение просто пропускается (require = 0). */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D", at = @At("RETURN"), cancellable = true, require = 0)
    private void arcane$aimZoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        double factor = WinchesterAim.fovFactor(tickDelta);
        if (factor < 1.0) cir.setReturnValue(cir.getReturnValue() * factor);
    }
}

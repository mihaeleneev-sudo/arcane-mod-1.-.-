package com.arcane.mixin;

import com.arcane.Oblivion;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Кровавая ночь: зараженные враги не могут выбрать целью владельца Забвения, сферу и стражу. */
@Mixin(MobEntity.class)
public abstract class MobEntityMixin {
    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true, require = 0)
    private void arcane$infected(LivingEntity target, CallbackInfo ci) {
        if (target == null) return;
        MobEntity self = (MobEntity) (Object) this;
        if (self instanceof Monster && Oblivion.shields(self, target)) ci.cancel();
    }
}

package com.arcane;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * WA Corporation и GAMMA: всё, что должно переживать перезапуск мира.
 * Данные хранятся отдельно для каждого игрока, плюс общий список жителей, уже делавших предложение.
 */
public class WaState extends PersistentState {
    public static final class Data {
        public boolean pending;      // предложение работы получено, ответа ещё нет
        public boolean accepted;     // согласился на работу
        public boolean chip;         // чип WA установлен
        public boolean balker;       // Балкер выбран (сохраняется при снятии чипа)
        public boolean pistol, cane, radio;
        public int pocket = 0;       // выбранное оружие: 0 пистолет, 1 трость, 2 рация
        public boolean radioPoint;
        public String radioDim = "";
        public double rx, ry, rz;
        public long radioCdEnd;      // время мира (овер), когда рация снова доступна
        public String retDim = "";
        public double retX, retY, retZ;
        public float retYaw;

        NbtCompound write() {
            NbtCompound n = new NbtCompound();
            n.putBoolean("pending", pending);
            n.putBoolean("accepted", accepted);
            n.putBoolean("chip", chip);
            n.putBoolean("balker", balker);
            n.putBoolean("pistol", pistol);
            n.putBoolean("cane", cane);
            n.putBoolean("radio", radio);
            n.putInt("pocket", pocket);
            n.putBoolean("radioPoint", radioPoint);
            n.putString("radioDim", radioDim);
            n.putDouble("rx", rx);
            n.putDouble("ry", ry);
            n.putDouble("rz", rz);
            n.putLong("radioCdEnd", radioCdEnd);
            n.putString("retDim", retDim);
            n.putDouble("retX", retX);
            n.putDouble("retY", retY);
            n.putDouble("retZ", retZ);
            n.putFloat("retYaw", retYaw);
            return n;
        }

        static Data read(NbtCompound n) {
            Data d = new Data();
            d.pending = n.getBoolean("pending");
            d.accepted = n.getBoolean("accepted");
            d.chip = n.getBoolean("chip");
            d.balker = n.getBoolean("balker");
            d.pistol = n.getBoolean("pistol");
            d.cane = n.getBoolean("cane");
            d.radio = n.getBoolean("radio");
            d.pocket = n.getInt("pocket");
            d.radioPoint = n.getBoolean("radioPoint");
            d.radioDim = n.getString("radioDim");
            d.rx = n.getDouble("rx");
            d.ry = n.getDouble("ry");
            d.rz = n.getDouble("rz");
            d.radioCdEnd = n.getLong("radioCdEnd");
            d.retDim = n.getString("retDim");
            d.retX = n.getDouble("retX");
            d.retY = n.getDouble("retY");
            d.retZ = n.getDouble("retZ");
            d.retYaw = n.getFloat("retYaw");
            return d;
        }

        public boolean owns(int weapon) {
            return switch (weapon) {
                case 0 -> pistol;
                case 1 -> cane;
                case 2 -> radio;
                default -> false;
            };
        }

        public int ownedMask() {
            return (pistol ? 1 : 0) | (cane ? 2 : 0) | (radio ? 4 : 0);
        }
    }

    private final Map<UUID, Data> players = new HashMap<>();
    /** Жители, которые уже предлагали работу (один раз за мир). */
    private final Set<UUID> offered = new HashSet<>();

    public static WaState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager()
                .getOrCreate(WaState::fromNbt, WaState::new, "arcane_wa");
    }

    public Data of(UUID id) {
        return players.computeIfAbsent(id, k -> new Data());
    }

    public boolean wasOffered(UUID villager) {
        return offered.contains(villager);
    }

    public void markOffered(UUID villager) {
        offered.add(villager);
        markDirty();
    }

    public static WaState fromNbt(NbtCompound nbt) {
        WaState s = new WaState();
        NbtCompound ps = nbt.getCompound("players");
        for (String key : ps.getKeys()) {
            try {
                s.players.put(UUID.fromString(key), Data.read(ps.getCompound(key)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        NbtList list = nbt.getList("offered", NbtElement.STRING_TYPE);
        for (int i = 0; i < list.size(); i++) {
            try {
                s.offered.add(UUID.fromString(list.getString(i)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtCompound ps = new NbtCompound();
        for (Map.Entry<UUID, Data> e : players.entrySet()) ps.put(e.getKey().toString(), e.getValue().write());
        nbt.put("players", ps);
        NbtList list = new NbtList();
        for (UUID u : offered) list.add(NbtString.of(u.toString()));
        nbt.put("offered", list);
        return nbt;
    }
}

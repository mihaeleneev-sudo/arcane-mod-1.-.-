package com.arcane;

import net.minecraft.block.Blocks;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Комната WA Corporation: строится один раз в измерении zet_world далеко от центра. */
public final class WaRoom {
    private static final int CX = 20000;
    private static final int CZ = 20000;
    private static final int FLOOR_Y = 99;
    public static final BlockPos CHAIR = new BlockPos(CX, FLOOR_Y + 1, CZ + 2);

    private WaRoom() {}

    public static ServerWorld world(MinecraftServer server) {
        return server.getWorld(ZetAbilities.ZET_WORLD);
    }

    public static boolean inRoom(ServerPlayerEntity p) {
        return p.getServerWorld().getRegistryKey().equals(ZetAbilities.ZET_WORLD)
                && Math.abs(p.getX() - CX) < 12 && Math.abs(p.getZ() - CZ) < 12;
    }

    private static void ensureBuilt(ServerWorld w) {
        if (w.getBlockState(CHAIR).isOf(ModBlocks.WA_CHAIR)) return;
        for (int x = CX - 5; x <= CX + 5; x++) {
            for (int z = CZ - 5; z <= CZ + 5; z++) {
                boolean wall = Math.abs(x - CX) == 5 || Math.abs(z - CZ) == 5;
                for (int y = FLOOR_Y; y <= FLOOR_Y + 5; y++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (y == FLOOR_Y) {
                        w.setBlockState(pos, ((x + z) & 1) == 0 ? Blocks.QUARTZ_BLOCK.getDefaultState()
                                : Blocks.SMOOTH_QUARTZ.getDefaultState());
                    } else if (y == FLOOR_Y + 5) {
                        w.setBlockState(pos, (x - CX) % 2 == 0 && (z - CZ) % 2 == 0 && !wall
                                ? Blocks.SEA_LANTERN.getDefaultState()
                                : Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState());
                    } else if (wall) {
                        w.setBlockState(pos, Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState());
                    } else {
                        w.setBlockState(pos, Blocks.AIR.getDefaultState());
                    }
                }
            }
        }
        // красный ковёр под креслом и сама точка установки улучшений
        w.setBlockState(CHAIR.down(), Blocks.RED_CONCRETE.getDefaultState());
        w.setBlockState(CHAIR, ModBlocks.WA_CHAIR.getDefaultState());
    }

    /** Переносит игрока в комнату, запомнив, откуда он пришёл. */
    public static void enter(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        ServerWorld w = world(server);
        if (w == null) {
            p.sendMessage(Text.translatable("message.arcane.portal_unavailable"), false);
            return;
        }
        ensureBuilt(w);
        WaState st = WaState.get(server);
        WaState.Data d = st.of(p.getUuid());
        if (!inRoom(p)) {
            d.retDim = p.getServerWorld().getRegistryKey().getValue().toString();
            d.retX = p.getX();
            d.retY = p.getY();
            d.retZ = p.getZ();
            d.retYaw = p.getYaw();
            st.markDirty();
        }
        p.teleport(w, CX + 0.5, FLOOR_Y + 1, CZ - 2.5, 0.0f, 0.0f);
    }

    /** Возвращает игрока туда, откуда он пришёл. */
    public static void leave(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        WaState.Data d = WaState.get(server).of(p.getUuid());
        ServerWorld target = null;
        if (!d.retDim.isEmpty()) {
            RegistryKey<World> key = RegistryKey.of(RegistryKeys.WORLD, new Identifier(d.retDim));
            target = server.getWorld(key);
        }
        if (target == null) {
            target = server.getOverworld();
            Vec3d s = Vec3d.ofBottomCenter(target.getSpawnPos());
            p.teleport(target, s.x, s.y, s.z, p.getYaw(), p.getPitch());
        } else {
            p.teleport(target, d.retX, d.retY, d.retZ, d.retYaw, p.getPitch());
        }
    }
}

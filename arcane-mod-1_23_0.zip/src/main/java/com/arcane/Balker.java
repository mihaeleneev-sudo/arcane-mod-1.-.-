package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Балкер (WA Corporation и GAMMA): полноценный персонаж игрока.
 * R - "Карман" (переключение оружия: пистолет, трость, рация), G - "Специалист" (способность выбранного оружия):
 * пистолет - Подкат, трость - Вращение (с контрударом), рация - Вызов связующего (две точки, 30 с отката).
 * Все данные (чип, выбор, покупки, точка рации и её откат) лежат в {@link WaState}.
 */
public final class Balker {
    public static final int EMERALD_PRICE = 20;
    public static final int DRAW_PISTOL = 24;
    public static final int DRAW_CANE = 30;
    public static final int DRAW_RADIO = 24;
    public static final int SLIDE_TICKS = 9;
    public static final int SLIDE_COOLDOWN = 8 * 20;
    public static final int SPIN_TICKS = 5 * 20;
    public static final int SPIN_COOLDOWN = 15 * 20;
    public static final int RADIO_COOLDOWN = 30 * 20;

    public static final int ACT_SYNC = 0;
    public static final int ACT_INSTALL = 1;
    public static final int ACT_REMOVE = 2;
    public static final int ACT_SELECT = 3;
    public static final int ACT_LEAVE = 4;
    public static final int ACT_BUY = 5;

    private static final Map<UUID, Integer> DRAW_END = new HashMap<>();
    private static final Map<UUID, Integer> SLIDE_END = new HashMap<>();
    private static final Map<UUID, Vec3d> SLIDE_DIR = new HashMap<>();
    private static final Map<UUID, Integer> SLIDE_CD_END = new HashMap<>();
    private static final Map<UUID, Integer> SPIN_END = new HashMap<>();
    private static final Map<UUID, Integer> SPIN_CD_END = new HashMap<>();
    private static final Map<UUID, ArmorStandEntity> SEATS = new HashMap<>();

    private Balker() {}

    public static boolean has(PlayerEntity p) {
        return Forms.character(p) == Form.BALKER;
    }

    private static void bar(ServerPlayerEntity p, String key, Object... args) {
        p.sendMessage(Text.translatable(key, args), true);
    }

    private static WaState.Data data(ServerPlayerEntity p) {
        return WaState.get(p.getServer()).of(p.getUuid());
    }

    private static void dirty(ServerPlayerEntity p) {
        WaState.get(p.getServer()).markDirty();
    }

    private static Item weaponItem(int idx) {
        return switch (idx) {
            case 0 -> ModItems.BALKER_PISTOL;
            case 1 -> ModItems.BALKER_CANE;
            default -> ModItems.BALKER_RADIO;
        };
    }

    private static boolean isWeapon(ItemStack s) {
        return s.isOf(ModItems.BALKER_PISTOL) || s.isOf(ModItems.BALKER_CANE) || s.isOf(ModItems.BALKER_RADIO);
    }

    // ---------- синхронизация ----------

    public static void sendState(ServerPlayerEntity p) {
        WaState.Data d = data(p);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(d.accepted);
        buf.writeBoolean(d.chip);
        buf.writeBoolean(d.balker);
        buf.writeInt(d.ownedMask());
        buf.writeInt(d.pocket);
        buf.writeBoolean(d.radioPoint);
        ServerPlayNetworking.send(p, Packets.WA_STATE, buf);
    }

    private static void sendPocket(ServerPlayerEntity p) {
        WaState.Data d = data(p);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(d.ownedMask());
        buf.writeInt(d.pocket);
        ServerPlayNetworking.send(p, Packets.WA_POCKET, buf);
    }

    public static void onJoin(ServerPlayerEntity p) {
        sendState(p);
    }

    // ---------- кресло и меню ----------

    public static void sitInChair(ServerPlayerEntity p, BlockPos pos) {
        WaState.Data d = data(p);
        if (!d.accepted) {
            bar(p, "message.arcane.wa_not_hired");
            return;
        }
        removeSeat(p.getUuid());
        ServerWorld w = p.getServerWorld();
        ArmorStandEntity seat = EntityType.ARMOR_STAND.create(w);
        if (seat == null) return;
        seat.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5, 180.0f, 0.0f);
        seat.setInvisible(true);
        seat.setNoGravity(true);
        seat.setInvulnerable(true);
        seat.addCommandTag("arcane_wa_seat");
        w.spawnEntity(seat);
        p.startRiding(seat, true);
        SEATS.put(p.getUuid(), seat);
        sendState(p);
        ServerPlayNetworking.send(p, Packets.WA_OPEN, PacketByteBufs.create());
    }

    private static void removeSeat(UUID id) {
        ArmorStandEntity seat = SEATS.remove(id);
        if (seat != null && !seat.isRemoved()) {
            seat.removeAllPassengers();
            seat.discard();
        }
    }

    public static void handleAction(ServerPlayerEntity p, int action, String arg) {
        WaState.Data d = data(p);
        if (action == ACT_SYNC) {
            sendState(p);
            return;
        }
        if (action == ACT_LEAVE) {
            removeSeat(p.getUuid());
            if (WaRoom.inRoom(p)) WaRoom.leave(p);
            return;
        }
        // всё остальное - только сидя в кресле комнаты
        if (!d.accepted || !WaRoom.inRoom(p)) return;
        switch (action) {
            case ACT_INSTALL -> {
                if (d.chip) break;
                d.chip = true;
                p.sendMessage(Text.translatable("message.arcane.wa_chip_installed"), false);
                if (d.balker) applyBalker(p);   // ранее выбранный персонаж возвращается
            }
            case ACT_REMOVE -> {
                if (!d.chip) break;
                d.chip = false;
                if (has(p)) Forms.setCharacter(p, Form.NONE);
                stripWeapons(p);
                p.sendMessage(Text.translatable("message.arcane.wa_chip_removed"), false);
            }
            case ACT_SELECT -> {
                if (!d.chip || !"balker".equals(arg)) break;
                if (Forms.character(p) != Form.NONE && !has(p)) {
                    bar(p, "message.arcane.wa_has_power");
                    break;
                }
                if (Discord.hasCurse(p) || Oblivion.has(p)) {
                    bar(p, "message.arcane.wa_has_power");
                    break;
                }
                d.balker = true;
                applyBalker(p);
            }
            case ACT_BUY -> {
                if (!d.chip || !d.balker) break;
                buy(p, d, arg);
            }
            default -> { }
        }
        dirty(p);
        sendState(p);
    }

    /** Для операторов: сразу чип, Балкер и все три улучшения. */
    public static void debugGrant(ServerPlayerEntity p) {
        WaState.Data d = data(p);
        d.accepted = true;
        d.chip = true;
        d.balker = true;
        d.pistol = true;
        d.cane = true;
        d.radio = true;
        dirty(p);
        if (Forms.character(p) != Form.NONE && !has(p)) Forms.setCharacter(p, Form.NONE);
        applyBalker(p);
        sendState(p);
    }

    private static void applyBalker(ServerPlayerEntity p) {
        if (has(p)) return;
        if (Forms.character(p) != Form.NONE || Discord.hasCurse(p) || Oblivion.has(p)) return;
        Forms.setCharacter(p, Form.BALKER);
    }

    private static int countEmeralds(ServerPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(Items.EMERALD)) n += s.getCount();
        }
        return n;
    }

    private static void takeEmeralds(ServerPlayerEntity p, int amount) {
        int left = amount;
        for (int i = 0; i < p.getInventory().size() && left > 0; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isOf(Items.EMERALD)) continue;
            int take = Math.min(left, s.getCount());
            s.decrement(take);
            left -= take;
        }
    }

    private static void buy(ServerPlayerEntity p, WaState.Data d, String arg) {
        int idx = switch (arg) {
            case "pistol" -> 0;
            case "cane" -> 1;
            case "radio" -> 2;
            default -> -1;
        };
        if (idx < 0 || d.owns(idx)) return;
        if (countEmeralds(p) < EMERALD_PRICE) {
            bar(p, "message.arcane.wa_no_emeralds", EMERALD_PRICE);
            return;
        }
        takeEmeralds(p, EMERALD_PRICE);
        switch (idx) {
            case 0 -> d.pistol = true;
            case 1 -> d.cane = true;
            default -> d.radio = true;
        }
        if (d.ownedMask() == (1 << idx)) d.pocket = idx;   // первая покупка становится выбранной
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_VILLAGER_YES, SoundCategory.PLAYERS, 1.0f, 1.0f);
        p.sendMessage(Text.translatable("message.arcane.wa_bought", Text.translatable("wa.upgrade." + arg)), false);
    }

    private static void stripWeapons(ServerPlayerEntity p) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (isWeapon(p.getInventory().getStack(i))) p.getInventory().setStack(i, ItemStack.EMPTY);
        }
    }

    // ---------- "Карман" (R) ----------

    public static void pocket(ServerPlayerEntity p) {
        WaState.Data d = data(p);
        if (d.ownedMask() == 0) {
            bar(p, "message.arcane.wa_no_weapons");
            return;
        }
        int next = d.pocket;
        for (int i = 1; i <= 3; i++) {
            int c = (d.pocket + i) % 3;
            if (d.owns(c)) {
                next = c;
                break;
            }
        }
        endSpin(p, false);
        d.pocket = next;
        dirty(p);
        equip(p, next);
        sendPocket(p);
    }

    private static int drawTicks(int idx) {
        return switch (idx) {
            case 0 -> DRAW_PISTOL;
            case 1 -> DRAW_CANE;
            default -> DRAW_RADIO;
        };
    }

    private static void equip(ServerPlayerEntity p, int idx) {
        stripWeapons(p);
        Item item = weaponItem(idx);
        ItemStack stack = new ItemStack(item);
        int dur = drawTicks(idx);
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putLong("DrawStart", p.getWorld().getTime());
        nbt.putInt("DrawDur", dur);

        int slot = p.getInventory().selectedSlot;
        if (!p.getInventory().getStack(slot).isEmpty()) {
            slot = -1;
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getStack(i).isEmpty()) {
                    slot = i;
                    break;
                }
            }
        }
        if (slot >= 0) {
            p.getInventory().setStack(slot, stack);
            if (slot != p.getInventory().selectedSlot) {
                p.getInventory().selectedSlot = slot;
                p.networkHandler.sendPacket(new UpdateSelectedSlotS2CPacket(slot));
            }
        } else {
            p.getInventory().offerOrDrop(stack);
        }
        int now = p.getServer().getTicks();
        DRAW_END.put(p.getUuid(), now + dur);
        p.getItemCooldownManager().set(item, dur);
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getX(), p.getY(), p.getZ(),
                idx == 1 ? SoundEvents.ITEM_ARMOR_EQUIP_IRON : SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE,
                SoundCategory.PLAYERS, 1.0f, idx == 2 ? 1.4f : 1.0f);
        bar(p, "message.arcane.wa_equip", Text.translatable("wa.upgrade." + (idx == 0 ? "pistol" : idx == 1 ? "cane" : "radio")));
    }

    public static boolean drawing(ServerPlayerEntity p) {
        return p.getServer().getTicks() < DRAW_END.getOrDefault(p.getUuid(), 0);
    }

    // ---------- "Специалист" (G) ----------

    public static void special(ServerPlayerEntity p) {
        WaState.Data d = data(p);
        if (d.ownedMask() == 0 || !d.owns(d.pocket)) {
            bar(p, "message.arcane.wa_no_weapons");
            return;
        }
        if (drawing(p)) {
            bar(p, "message.arcane.wa_drawing");
            return;
        }
        int now = p.getServer().getTicks();
        switch (d.pocket) {
            case 0 -> slide(p, now);
            case 1 -> spin(p, now);
            default -> radio(p, d);
        }
    }

    private static void slide(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        int cd = SLIDE_CD_END.getOrDefault(id, 0) - now;
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return;
        }
        if (now < SLIDE_END.getOrDefault(id, 0)) return;
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d dir = new Vec3d(look.x, 0.0, look.z);
        dir = dir.lengthSquared() < 1.0e-4 ? new Vec3d(0, 0, 1) : dir.normalize();
        SLIDE_DIR.put(id, dir);
        SLIDE_END.put(id, now + SLIDE_TICKS);
        SLIDE_CD_END.put(id, now + SLIDE_COOLDOWN);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 1.0f, 0.7f);
    }

    private static void tickSlide(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        if (now >= SLIDE_END.getOrDefault(id, 0)) return;
        Vec3d dir = SLIDE_DIR.get(id);
        if (dir == null) return;
        ServerWorld w = p.getServerWorld();
        Vec3d v = p.getVelocity();
        p.setVelocity(dir.x * 0.95, Math.min(v.y, 0.0), dir.z * 0.95);
        p.velocityModified = true;
        w.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.1, p.getZ(), 3, 0.2, 0.05, 0.2, 0.01);

        Box box = p.getBoundingBox().expand(0.5, 0.2, 0.5).offset(dir.multiply(0.7));
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                t -> t != p && t.isAlive() && !t.isSpectator() && !(t instanceof ArmorStandEntity))) {
            e.damage(p.getDamageSources().playerAttack(p), 3.0f);
            e.setVelocity(dir.x * 0.2, 0.95, dir.z * 0.2);
            e.velocityModified = true;
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
            w.spawnParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 0.5, e.getZ(), 14, 0.3, 0.3, 0.3, 0.2);
            w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK,
                    SoundCategory.PLAYERS, 1.0f, 1.0f);
            SLIDE_END.put(id, 0);    // попал: подкат завершён
            break;
        }
    }

    private static void spin(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        int cd = SPIN_CD_END.getOrDefault(id, 0) - now;
        if (cd > 0) {
            bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
            return;
        }
        if (now < SPIN_END.getOrDefault(id, 0)) return;
        SPIN_END.put(id, now + SPIN_TICKS);
        SPIN_CD_END.put(id, now + SPIN_TICKS + SPIN_COOLDOWN);
        setSpinNbt(p, p.getWorld().getTime() + SPIN_TICKS);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 1.0f, 1.2f);
        bar(p, "message.arcane.wa_spin");
    }

    private static void setSpinNbt(ServerPlayerEntity p, long until) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(ModItems.BALKER_CANE)) {
                if (until > 0) s.getOrCreateNbt().putLong("SpinUntil", until);
                else if (s.hasNbt()) s.getNbt().remove("SpinUntil");
            }
        }
    }

    public static boolean spinning(ServerPlayerEntity p) {
        return p.getServer().getTicks() < SPIN_END.getOrDefault(p.getUuid(), 0);
    }

    private static void endSpin(ServerPlayerEntity p, boolean startCooldown) {
        UUID id = p.getUuid();
        if (SPIN_END.getOrDefault(id, 0) == 0) return;
        SPIN_END.put(id, 0);
        setSpinNbt(p, 0);
        if (startCooldown) SPIN_CD_END.put(id, p.getServer().getTicks() + SPIN_COOLDOWN);
    }

    private static void tickSpin(ServerPlayerEntity p, int now) {
        UUID id = p.getUuid();
        int end = SPIN_END.getOrDefault(id, 0);
        if (end == 0) return;
        if (now >= end) {
            endSpin(p, false);
            return;
        }
        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d front = new Vec3d(look.x, 0.0, look.z);
        front = front.lengthSquared() < 1.0e-4 ? new Vec3d(0, 0, 1) : front.normalize();
        double a = now * 0.9;
        Vec3d c = p.getPos().add(front.multiply(1.1)).add(0, 1.1, 0);
        w.spawnParticles(ParticleTypes.CRIT, c.x + Math.cos(a) * 0.7 * front.z, c.y + Math.sin(a) * 0.6,
                c.z - Math.cos(a) * 0.7 * front.x, 2, 0.05, 0.05, 0.05, 0.0);
        if (now % 5 == 0) {
            p.swingHand(Hand.MAIN_HAND, true);
            w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                    SoundCategory.PLAYERS, 0.5f, 1.5f);
        }
    }

    /** Вращение отражает удары и снаряды спереди и сбоку. */
    public static boolean allowDamage(ServerPlayerEntity p, DamageSource source) {
        if (!spinning(p)) return true;
        Entity src = source.getSource() != null ? source.getSource() : source.getAttacker();
        if (src == null) return true;
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d fwd = new Vec3d(look.x, 0.0, look.z).normalize();
        Vec3d to = new Vec3d(src.getX() - p.getX(), 0.0, src.getZ() - p.getZ()).normalize();
        if (fwd.dotProduct(to) < -0.2) return true;     // сзади - не защищает
        if (src instanceof ProjectileEntity pr) pr.setVelocity(pr.getVelocity().multiply(-0.6));
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.CRIT, p.getX() + fwd.x, p.getY() + 1.2, p.getZ() + fwd.z, 10, 0.2, 0.3, 0.2, 0.2);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1.0f, 1.3f);
        return false;
    }

    /** Ударил во время вращения: особый контрудар, отбрасывает далеко и заменяет вращение. */
    public static ActionResult onAttack(PlayerEntity player, Entity target) {
        if (!(player instanceof ServerPlayerEntity sp) || !spinning(sp) || !(target instanceof LivingEntity victim)) {
            return ActionResult.PASS;
        }
        endSpin(sp, true);
        Vec3d dir = new Vec3d(victim.getX() - sp.getX(), 0.0, victim.getZ() - sp.getZ());
        dir = dir.lengthSquared() < 1.0e-4 ? sp.getRotationVec(1.0f) : dir.normalize();
        victim.damage(sp.getDamageSources().playerAttack(sp), 8.0f);
        victim.setVelocity(dir.x * 2.8, 0.5, dir.z * 2.8);
        victim.velocityModified = true;
        ServerWorld w = sp.getServerWorld();
        sp.swingHand(Hand.MAIN_HAND, true);
        w.spawnParticles(ParticleTypes.SWEEP_ATTACK, victim.getX(), victim.getY() + 1.0, victim.getZ(), 3, 0.3, 0.3, 0.3, 0.0);
        w.spawnParticles(ParticleTypes.EXPLOSION, victim.getX(), victim.getY() + 1.0, victim.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
        w.playSound(null, victim.getX(), victim.getY(), victim.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK,
                SoundCategory.PLAYERS, 1.5f, 0.6f);
        return ActionResult.SUCCESS;
    }

    /** Нельзя бить тростью, пока она достаётся. */
    public static boolean attackBlocked(PlayerEntity player) {
        return player instanceof ServerPlayerEntity sp && has(sp) && drawing(sp)
                && sp.getMainHandStack().isOf(ModItems.BALKER_CANE);
    }

    private static void radio(ServerPlayerEntity p, WaState.Data d) {
        MinecraftServer server = p.getServer();
        long now = server.getOverworld().getTime();
        ServerWorld w = p.getServerWorld();
        if (!d.radioPoint) {
            long cd = d.radioCdEnd - now;
            if (cd > 0) {
                bar(p, "message.arcane.oblivion_cooldown", (cd + 19) / 20);
                return;
            }
            d.radioPoint = true;
            d.radioDim = w.getRegistryKey().getValue().toString();
            d.rx = p.getX();
            d.ry = p.getY();
            d.rz = p.getZ();
            dirty(p);
            w.spawnParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.5, p.getZ(), 20, 0.3, 0.5, 0.3, 0.05);
            w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                    SoundCategory.PLAYERS, 1.0f, 1.6f);
            bar(p, "message.arcane.wa_radio_set");
            sendState(p);
            return;
        }
        RegistryKey<World> key = RegistryKey.of(RegistryKeys.WORLD, new Identifier(d.radioDim));
        ServerWorld target = server.getWorld(key);
        d.radioPoint = false;
        if (target == null) {
            dirty(p);
            sendState(p);
            bar(p, "message.arcane.wa_radio_lost");
            return;
        }
        w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.5);
        p.teleport(target, d.rx, d.ry, d.rz, p.getYaw(), p.getPitch());
        target.spawnParticles(ParticleTypes.PORTAL, d.rx, d.ry + 1, d.rz, 40, 0.4, 0.8, 0.4, 0.5);
        target.playSound(null, d.rx, d.ry, d.rz, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.2f);
        d.radioCdEnd = now + RADIO_COOLDOWN;
        dirty(p);
        sendState(p);
        bar(p, "message.arcane.wa_radio_tp");
    }

    // ---------- пистолет ----------

    public static boolean shoot(ServerPlayerEntity p) {
        if (!has(p)) {
            bar(p, "message.arcane.wa_not_balker");
            return false;
        }
        if (drawing(p)) return false;
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f);
        Vec3d end = eye.add(dir.multiply(40.0));
        BlockHitResult bh = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) end = bh.getPos();
        Box box = p.getBoundingBox().stretch(dir.multiply(40.0)).expand(1.0);
        EntityHitResult eh = ProjectileUtil.raycast(p, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != p, 40.0 * 40.0);
        if (eh != null) {
            end = eh.getPos();
            eh.getEntity().damage(p.getDamageSources().playerAttack(p), 7.0f);
        }
        Vec3d step = end.subtract(eye);
        int n = (int) step.length();
        for (int i = 1; i < n; i += 1) {
            Vec3d pt = eye.add(step.multiply(i / (double) n));
            w.spawnParticles(ParticleTypes.CRIT, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        w.spawnParticles(ParticleTypes.SMOKE, eye.x + dir.x, eye.y - 0.2 + dir.y, eye.z + dir.z, 4, 0.05, 0.05, 0.05, 0.01);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.0f, 1.5f);
        return true;
    }

    // ---------- откаты для HUD ----------

    public static int specialLeft(ServerPlayerEntity p, int now) {
        WaState.Data d = data(p);
        UUID id = p.getUuid();
        return switch (d.pocket) {
            case 0 -> Math.max(0, SLIDE_CD_END.getOrDefault(id, 0) - now);
            case 1 -> Math.max(0, SPIN_CD_END.getOrDefault(id, 0) - now);
            default -> d.radioPoint ? 0 : (int) Math.max(0, d.radioCdEnd - p.getServer().getOverworld().getTime());
        };
    }

    public static int specialTotal(ServerPlayerEntity p) {
        return switch (data(p).pocket) {
            case 0 -> SLIDE_COOLDOWN;
            case 1 -> SPIN_COOLDOWN + SPIN_TICKS;
            default -> RADIO_COOLDOWN;
        };
    }

    // ---------- жизненный цикл ----------

    /** Игрок перестал быть Балкером (другая сила, снятие чипа). Покупки остаются в WaState. */
    public static void clear(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        endSpin(p, false);
        SLIDE_END.remove(id);
        DRAW_END.remove(id);
        SLIDE_DIR.remove(id);
    }

    public static void onDisconnect(ServerPlayerEntity p) {
        removeSeat(p.getUuid());
        SPIN_END.remove(p.getUuid());
        SLIDE_END.remove(p.getUuid());
    }

    public static void tick(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            ArmorStandEntity seat = SEATS.get(id);
            if (seat != null && (seat.isRemoved() || p.getVehicle() != seat)) {
                if (!seat.isRemoved()) seat.discard();
                SEATS.remove(id);
                if (WaRoom.inRoom(p) && !p.isAlive()) continue;
            }
            if (!has(p) || !p.isAlive()) continue;
            tickSlide(p, t);
            tickSpin(p, t);
            if (t % 10 == 0) {
                WaState.Data d = data(p);
                if (d.radioPoint && p.getServerWorld().getRegistryKey().getValue().toString().equals(d.radioDim)) {
                    p.getServerWorld().spawnParticles(p, ParticleTypes.END_ROD, true, d.rx, d.ry + 0.2, d.rz, 2, 0.1, 0.4, 0.1, 0.01);
                }
            }
        }
    }
}

package com.arcane;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.util.Rarity;

/**
 * Кинжал для жертвоприношений. Убил им врага - стал окровавленным (отдельный предмет),
 * окровавленный отдают Забвению правой кнопкой по сфере.
 */
public class SacrificeDaggerItem extends SwordItem {
    private final boolean bloody;

    public SacrificeDaggerItem(boolean bloody) {
        super(ToolMaterials.IRON, 1, -1.6f,
                new FabricItemSettings().maxCount(1).rarity(bloody ? Rarity.EPIC : Rarity.RARE).fireproof());
        this.bloody = bloody;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return bloody;
    }
}

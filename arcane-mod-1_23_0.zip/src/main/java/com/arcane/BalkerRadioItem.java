package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Рация Балкера. Способность "Вызов связующего" - на G (установить точку, затем телепорт). */
public class BalkerRadioItem extends Item {
    public BalkerRadioItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            sp.sendMessage(Text.translatable("message.arcane.wa_radio_hint"), true);
        }
        return TypedActionResult.success(stack);
    }
}

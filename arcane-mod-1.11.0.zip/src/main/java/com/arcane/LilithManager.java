package com.arcane;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Появление Лилит после смерти носителя Эйро (шанс 40%) и её особый удар. */
public final class LilithManager {
    private static final int SWEEP_COOLDOWN = 8 * 20;

    private static final class Active {
        final ServerWorld world;
        final LilithEntity entity;
        int sweepCd = SWEEP_COOLDOWN;
        int seenHits = 0;

        Active(ServerWorld world, LilithEntity entity) {
            this.world = world;
            this.entity = entity;
        }
    }

    private static final Map<UUID, Active> ACTIVE = new HashMap<>();

    private LilithManager() {}

    /** Вызывается при возрождении игрока. */
    public static void onRespawn(ServerPlayerEntity p, boolean alive) {
        if (alive) return;
        if (Forms.character(p) != Form.EIRO) return;
        if (EiroClaws.hasClaws(p) || EiroClaws.isSlain(p)) return;   // уже убита или душа поглощена
        if (ACTIVE.containsKey(p.getUuid())) return;
        if (p.getRandom().nextFloat() >= ArcConfig.lilithChance) return;
        spawn(p);
    }

    public static void spawn(ServerPlayerEntity p) {
        if (ACTIVE.containsKey(p.getUuid())) return;
        ServerWorld w = p.getServerWorld();
        LilithEntity l = new LilithEntity(ModEntities.LILITH, w);
        l.owner = p.getUuid();

        // ищем свободное место рядом
        double x = p.getX() + 2.0;
        double z = p.getZ() + 2.0;
        for (int i = 0; i < 12; i++) {
            x = p.getX() + (p.getRandom().nextDouble() - 0.5) * 16.0;
            z = p.getZ() + (p.getRandom().nextDouble() - 0.5) * 16.0;
            l.refreshPositionAndAngles(x, p.getY(), z, p.getYaw() + 180.0f, 0.0f);
            if (w.isSpaceEmpty(l)) break;
        }
        l.setPersistent();
        l.setTarget(p);
        w.spawnEntity(l);

        ACTIVE.put(p.getUuid(), new Active(w, l));
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, l.getX(), l.getY() + 1.0, l.getZ(), 60, 0.5, 1.0, 0.5, 0.05);
        w.playSound(null, l.getBlockPos(), SoundEvents.ENTITY_WITHER_AMBIENT, SoundCategory.HOSTILE, 1.2f, 0.6f);
        p.sendMessage(Text.translatable("message.arcane.lilith_appears"), false);
    }

    /** Лилит погибла: она больше не появится, а её душа падает на землю (по таблице добычи). */
    public static void onLilithDeath(LilithEntity l) {
        MinecraftServer server = l.getServer();
        if (server == null || l.owner == null) return;
        ACTIVE.remove(l.owner);
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(l.owner);
        if (p != null) {
            EiroClaws.markSlain(p);
            p.sendMessage(Text.translatable("message.arcane.lilith_slain"), false);
        }
    }

    private static void sweep(Active a) {
        LilithEntity l = a.entity;
        boolean any = false;
        for (LivingEntity e : a.world.getEntitiesByClass(LivingEntity.class, l.getBoundingBox().expand(4.5),
                ent -> ent != l && ent.isAlive() && ent.squaredDistanceTo(l) <= 20.25)) {
            DamageSource src = a.world.getDamageSources().mobAttack(l);
            e.damage(src, 6.0f);
            EiroClaws.applyBleed(a.world, e, 120);
            any = true;
        }
        if (any) {
            Vec3d look = l.getRotationVec(1.0f);
            Vec3d flat = new Vec3d(look.x, 0.0, look.z);
            Vec3d fwd = flat.lengthSquared() < 1.0E-4 ? new Vec3d(0.0, 0.0, 1.0) : flat.normalize();
            EiroClaws.slashes(a.world, l.getPos().add(fwd.multiply(2.5)), fwd);
            a.world.playSound(null, l.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.HOSTILE, 1.5f, 0.5f);
        }
    }

    public static void tick(MinecraftServer server, int t) {
        Iterator<Map.Entry<UUID, Active>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Active> en = it.next();
            Active a = en.getValue();
            LilithEntity l = a.entity;
            if (!l.isAlive()) {
                it.remove();
                continue;
            }
            // её удары вызывают кровотечение
            if (l.hitCounter != a.seenHits) {
                a.seenHits = l.hitCounter;
                if (l.lastVictim != null) EiroClaws.applyBleed(a.world, l.lastVictim, 120);
            }
            if (l.getTarget() == null && t % 20 == 0) {
                ServerPlayerEntity owner = server.getPlayerManager().getPlayer(en.getKey());
                if (owner != null) l.setTarget(owner);
            }
            if (--a.sweepCd <= 0) {
                a.sweepCd = SWEEP_COOLDOWN;
                sweep(a);
            }
        }
    }
}

package com.arcane;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.EnumSet;
import java.util.UUID;

/** Защитник идёт за Королём, если отстал, и телепортируется, если очень далеко. */
public class FollowOwnerGoal extends Goal {
    private final PathAwareEntity mob;
    private final KingGuardian guardian;

    public <T extends PathAwareEntity & KingGuardian> FollowOwnerGoal(T mob) {
        this.mob = mob;
        this.guardian = mob;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    private ServerPlayerEntity owner() {
        MinecraftServer server = mob.getServer();
        UUID id = guardian.getOwnerId();
        if (server == null || id == null) return null;
        return server.getPlayerManager().getPlayer(id);
    }

    @Override
    public boolean canStart() {
        ServerPlayerEntity o = owner();
        return o != null && mob.getTarget() == null && mob.squaredDistanceTo(o) > 64.0;
    }

    @Override
    public boolean shouldContinue() {
        ServerPlayerEntity o = owner();
        return o != null && mob.getTarget() == null && !mob.getNavigation().isIdle() && mob.squaredDistanceTo(o) > 9.0;
    }

    @Override
    public void start() {
        ServerPlayerEntity o = owner();
        if (o != null) mob.getNavigation().startMovingTo(o, 1.25);
    }

    @Override
    public void tick() {
        ServerPlayerEntity o = owner();
        if (o == null) return;
        if (mob.squaredDistanceTo(o) > 900.0) {
            mob.requestTeleport(o.getX(), o.getY(), o.getZ());
        } else {
            mob.getNavigation().startMovingTo(o, 1.25);
        }
    }
}

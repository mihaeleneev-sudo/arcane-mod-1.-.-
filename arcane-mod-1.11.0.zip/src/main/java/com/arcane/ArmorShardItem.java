package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Осколок брони: улучшает Саира. Использовать может только носитель Саира. */
public class ArmorShardItem extends Item {
    public ArmorShardItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (Forms.character(sp) != Form.SAIR) {
                sp.sendMessage(Text.translatable("message.arcane.shard_only_sair"), true);
                return TypedActionResult.fail(stack);
            }
            if (SairUpgrade.isUpgraded(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.already_upgraded"), true);
                return TypedActionResult.fail(stack);
            }
            SairUpgrade.upgrade(sp);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack);
    }
}

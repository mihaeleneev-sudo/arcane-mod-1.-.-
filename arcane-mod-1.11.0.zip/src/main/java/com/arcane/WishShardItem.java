package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Осколок Желания: три осколка дают Королю "Желание Короля". */
public class WishShardItem extends Item {
    public WishShardItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (KingAbilities.useShard(sp)) {
                if (!sp.getAbilities().creativeMode) stack.decrement(1);
                return TypedActionResult.success(stack);
            }
            return TypedActionResult.fail(stack);
        }
        return TypedActionResult.pass(stack);
    }
}

package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Однозарядный дробовик Хантера: выстрел по ПКМ, затем перезарядка. */
public class ShotgunItem extends Item {
    public ShotgunItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp && Forms.isActive(sp, Form.HUNTER)) {
            HunterAbilities.fire(sp, this);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}

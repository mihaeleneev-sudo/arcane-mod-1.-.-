package com.arcane;

import java.util.UUID;

/** Защитник Короля: знает, кому служит. */
public interface KingGuardian {
    UUID getOwnerId();

    void setOwnerId(UUID id);
}

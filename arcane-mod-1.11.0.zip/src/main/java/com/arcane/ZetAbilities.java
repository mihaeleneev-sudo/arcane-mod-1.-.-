package com.arcane;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Зет: Крик (R, удерживать), Коса (G, нажать), Портал в измерение Зета (G, удерживать 1 секунду).
 * Плащ рисуется на клиенте. Превращение, перезарядка 30 секунд и хранение силы общие для всех персонажей.
 */
public final class ZetAbilities {
    public static final RegistryKey<World> ZET_WORLD =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(ArcaneMod.MOD_ID, "zet_world"));

    private static final double SCREAM_RADIUS = 15.0;
    private static final int SCREAM_COOLDOWN = 15 * 20;
    private static final int SCYTHE_COOLDOWN = 30 * 20;
    private static final int PORTAL_HOLD_TICKS = 20;
    private static final double SCYTHE_RANGE = 20.0;
    /** Измерение плоское: бедрок, бетон, песок (всего 5 слоёв). Игрок стоит на высоте 5. */
    private static final double ZET_SPAWN_Y = 5.0;

    private static final class GState {
        int ticks = 0;
        boolean portalFired = false;
    }

    private static final class ReturnPoint {
        final RegistryKey<World> world;
        final Vec3d pos;

        ReturnPoint(RegistryKey<World> world, Vec3d pos) {
            this.world = world;
            this.pos = pos;
        }
    }

    private static final Set<UUID> SCREAMING = new HashSet<>();
    private static final Map<UUID, Integer> SCREAM_CD = new HashMap<>();
    private static final Map<UUID, Integer> SCYTHE_CD = new HashMap<>();
    private static final Map<UUID, GState> G_HOLD = new HashMap<>();
    private static final Map<UUID, ReturnPoint> RETURNS = new HashMap<>();

    private ZetAbilities() {}

    public static int screamLeft(java.util.UUID id, int now) { return Math.max(0, SCREAM_CD.getOrDefault(id, 0) - now); }
    public static int scytheLeft(java.util.UUID id, int now) { return Math.max(0, SCYTHE_CD.getOrDefault(id, 0) - now); }


    // ---------- Крик (клавиша R, удерживать) ----------

    public static void screamKey(ServerPlayerEntity p, boolean pressed) {
        UUID id = p.getUuid();
        if (pressed) {
            if (SCREAMING.contains(id)) return;
            int now = p.getServer().getTicks();
            int until = SCREAM_CD.getOrDefault(id, 0);
            if (now < until) {
                p.sendMessage(Text.translatable("message.arcane.scream_cooldown", (until - now + 19) / 20), true);
                return;
            }
            SCREAMING.add(id);
        } else {
            stopScream(p, true);
        }
    }

    private static void stopScream(ServerPlayerEntity p, boolean notify) {
        if (SCREAMING.remove(p.getUuid())) {
            SCREAM_CD.put(p.getUuid(), p.getServer().getTicks() + SCREAM_COOLDOWN);
            if (notify) p.sendMessage(Text.translatable("message.arcane.scream_end"), true);
        }
    }

    private static void doScream(ServerPlayerEntity p, int t) {
        ServerWorld w = p.getServerWorld();
        double r2 = SCREAM_RADIUS * SCREAM_RADIUS;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(SCREAM_RADIUS),
                ent -> ent != p && ent.isAlive() && ent.squaredDistanceTo(p) <= r2)) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3, false, true));
        }
        for (int i = 0; i < 20; i++) {
            double angle = p.getRandom().nextDouble() * Math.PI * 2.0;
            double radius = p.getRandom().nextDouble() * SCREAM_RADIUS;
            w.spawnParticles(ParticleTypes.EFFECT,
                    p.getX() + Math.cos(angle) * radius,
                    p.getY() + p.getRandom().nextDouble() * 3.0,
                    p.getZ() + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
        if (t % 10 == 0) {
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 0.5f, 1.2f);
        }
    }

    // ---------- Коса и портал (клавиша G) ----------

    /** Нажатие запускает отсчёт. Отпустили раньше секунды - Коса, продержали секунду - Портал. */
    public static void gKey(ServerPlayerEntity p, boolean pressed) {
        UUID id = p.getUuid();
        if (pressed) {
            G_HOLD.put(id, new GState());
        } else {
            GState s = G_HOLD.remove(id);
            if (s != null && !s.portalFired) scythe(p);
        }
    }

    private static LivingEntity findTarget(ServerPlayerEntity p) {
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f);
        Vec3d end = start.add(dir.multiply(SCYTHE_RANGE));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : p.getServerWorld().getOtherEntities(p,
                p.getBoundingBox().stretch(dir.multiply(SCYTHE_RANGE)).expand(1.0))) {
            if (!(e instanceof LivingEntity living) || !living.isAlive()) continue;
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(start, end);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = living;
                }
            }
        }
        return best;
    }

    /** Коса всегда попадает и отнимает 25% максимального здоровья цели. */
    private static void scythe(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        int now = p.getServer().getTicks();
        int until = SCYTHE_CD.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.scythe_cooldown", (until - now + 19) / 20), true);
            return;
        }
        LivingEntity target = findTarget(p);
        if (target == null) {
            p.sendMessage(Text.translatable("message.arcane.no_target"), true);
            return;
        }

        ServerWorld w = p.getServerWorld();
        Vec3d above = target.getPos().add(0, target.getHeight() + 2.0, 0);
        for (int i = 0; i < 50; i++) {
            w.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                    above.x + (p.getRandom().nextDouble() - 0.5) * 2.0, above.y,
                    above.z + (p.getRandom().nextDouble() - 0.5) * 2.0, 1, 0, 0, 0, 0);
        }
        target.damage(p.getDamageSources().playerAttack(p), target.getMaxHealth() * 0.25f);
        SCYTHE_CD.put(id, now + SCYTHE_COOLDOWN);
        w.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.0f, 0.8f);
        p.sendMessage(Text.translatable("message.arcane.scythe_hit"), true);
    }

    // ---------- Измерение Зета ----------

    private static boolean inZetWorld(ServerPlayerEntity p) {
        return p.getServerWorld().getRegistryKey().equals(ZET_WORLD);
    }

    private static void portal(ServerPlayerEntity p, MinecraftServer server) {
        ServerWorld zet = server.getWorld(ZET_WORLD);
        if (zet == null) {
            p.sendMessage(Text.translatable("message.arcane.portal_unavailable"), false);
            return;
        }
        if (inZetWorld(p)) {
            returnHome(p, server);
            p.sendMessage(Text.translatable("message.arcane.portal_exit"), false);
        } else {
            RETURNS.put(p.getUuid(), new ReturnPoint(p.getServerWorld().getRegistryKey(), p.getPos()));
            p.teleport(zet, p.getX(), ZET_SPAWN_Y, p.getZ(), p.getYaw(), p.getPitch());
            p.sendMessage(Text.translatable("message.arcane.portal_enter"), false);
        }
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                SoundCategory.PLAYERS, 1.0f, 1.0f);
    }

    /** Возвращает игрока туда, откуда он ушёл в измерение (или на точку спавна мира). */
    private static void returnHome(ServerPlayerEntity p, MinecraftServer server) {
        ReturnPoint rp = RETURNS.remove(p.getUuid());
        ServerWorld target = rp != null ? server.getWorld(rp.world) : null;
        if (target == null) target = server.getOverworld();
        Vec3d pos = rp != null && target.getRegistryKey().equals(rp.world)
                ? rp.pos : Vec3d.ofBottomCenter(target.getSpawnPos());
        p.teleport(target, pos.x, pos.y, pos.z, p.getYaw(), p.getPitch());
    }

    // ---------- служебное ----------

    public static void onDeactivate(ServerPlayerEntity p, Form was) {
        if (was != Form.ZET) return;
        stopScream(p, false);
        G_HOLD.remove(p.getUuid());
        // форма кончилась в измерении Зета: возвращаем домой, чтобы не застрять
        if (p.isAlive() && inZetWorld(p)) returnHome(p, p.getServer());
    }

    public static void clear(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        SCREAMING.remove(id);
        G_HOLD.remove(id);
    }

    public static void tick(MinecraftServer server, int t) {
        for (UUID id : new ArrayList<>(SCREAMING)) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.ZET)) {
                SCREAMING.remove(id);
                SCREAM_CD.put(id, t + SCREAM_COOLDOWN);
                continue;
            }
            doScream(p, t);
        }
        for (Map.Entry<UUID, GState> en : new ArrayList<>(G_HOLD.entrySet())) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.ZET)) {
                G_HOLD.remove(en.getKey());
                continue;
            }
            GState s = en.getValue();
            s.ticks++;
            if (s.ticks >= PORTAL_HOLD_TICKS && !s.portalFired) {
                s.portalFired = true;
                portal(p, server);
            }
        }
    }
}

package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Поддельные документы наёмника: превращают Хантера в баунти хантера. */
public class ForgedDocumentsItem extends Item {
    public ForgedDocumentsItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (Forms.character(sp) != Form.HUNTER) {
                sp.sendMessage(Text.translatable("message.arcane.docs_only_hunter"), true);
                return TypedActionResult.fail(stack);
            }
            if (HunterAbilities.hasBounty(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.already_bounty"), true);
                return TypedActionResult.fail(stack);
            }
            HunterAbilities.becomeBounty(sp);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack);
    }
}

package com.arcane;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.entity.EquipmentSlot;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Доски объявлений и листовки. Награда выдаётся за голову другого игрока или бандита-"моба-игрока",
 * который появляется неподалёку. Выполненную листовку меняют на изумруды у зелёного жителя.
 * Состояние хранится в самой листовке, поэтому ничего не теряется при перезапуске.
 */
public final class HunterBounties {
    private static final String[] NAMES = {
            "Грязный Пит", "Одноглазый Джек", "Мэд Рэй", "Хромой Сэм", "Рыжий Бык", "Старина Клод"
    };

    private HunterBounties() {}

    private static boolean hasOpenPoster(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.BOUNTY_POSTER)) return true;
        }
        return false;
    }

    public static void takeBounty(ServerPlayerEntity p, BlockPos boardPos) {
        if (Forms.character(p) != Form.HUNTER) {
            p.sendMessage(Text.translatable("message.arcane.board_look"), true);
            return;
        }
        if (hasOpenPoster(p)) {
            p.sendMessage(Text.translatable("message.arcane.board_has_poster"), true);
            return;
        }
        ServerWorld w = p.getServerWorld();

        List<ServerPlayerEntity> others = new ArrayList<>();
        for (ServerPlayerEntity o : p.getServer().getPlayerManager().getPlayerList()) {
            if (o != p && o.isAlive() && !o.isSpectator()) others.add(o);
        }

        ItemStack poster = new ItemStack(ModItems.BOUNTY_POSTER);
        NbtCompound nbt = poster.getOrCreateNbt();

        if (!others.isEmpty() && p.getRandom().nextBoolean()) {
            // награда за голову живого игрока
            ServerPlayerEntity target = others.get(p.getRandom().nextInt(others.size()));
            nbt.putString("Kind", "player");
            nbt.putString("TargetUuid", target.getUuid().toString());
            nbt.putString("TargetName", target.getGameProfile().getName());
            nbt.putString("Hint", "");
            target.sendMessage(Text.translatable("message.arcane.bounty_on_you"), false);
            p.sendMessage(Text.translatable("message.arcane.bounty_taken_player", target.getGameProfile().getName()), false);
        } else {
            // бандит появляется неподалёку
            String name = NAMES[p.getRandom().nextInt(NAMES.length)];
            OutlawEntity outlaw = spawnOutlaw(w, boardPos, name);
            int hx = (int) (outlaw.getX() / 10) * 10;
            int hz = (int) (outlaw.getZ() / 10) * 10;
            nbt.putString("Kind", "outlaw");
            nbt.putString("TargetUuid", outlaw.getUuid().toString());
            nbt.putString("TargetName", name);
            nbt.putString("Hint", "X " + hx + ", Z " + hz);
            p.sendMessage(Text.translatable("message.arcane.bounty_taken_outlaw", name, hx, hz), false);
        }
        p.getInventory().offerOrDrop(poster);
        w.playSound(null, boardPos, SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.BLOCKS, 1.0f, 1.0f);
    }

    private static OutlawEntity spawnOutlaw(ServerWorld w, BlockPos around, String name) {
        OutlawEntity o = new OutlawEntity(ModEntities.OUTLAW, w);
        boolean placed = false;
        for (int i = 0; i < 10 && !placed; i++) {
            double angle = w.getRandom().nextDouble() * Math.PI * 2.0;
            double dist = 25.0 + w.getRandom().nextDouble() * 20.0;
            int x = around.getX() + (int) (Math.cos(angle) * dist);
            int z = around.getZ() + (int) (Math.sin(angle) * dist);
            BlockPos probe = new BlockPos(x, around.getY(), z);
            if (!w.isChunkLoaded(probe)) continue;
            int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
            o.refreshPositionAndAngles(x + 0.5, y, z + 0.5, w.getRandom().nextFloat() * 360.0f, 0.0f);
            placed = w.isSpaceEmpty(o);
        }
        if (!placed) o.refreshPositionAndAngles(around.getX() + 6.5, around.getY() + 1.0, around.getZ() + 6.5, 0.0f, 0.0f);

        o.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
        o.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
        o.setCustomName(Text.literal(name));
        o.setCustomNameVisible(true);
        o.setPersistent();
        w.spawnEntity(o);
        return o;
    }

    // ---------- выполнение заказа ----------

    public static void onOutlawDeath(OutlawEntity outlaw, DamageSource source) {
        if (source.getAttacker() instanceof ServerPlayerEntity killer) {
            completeFor(killer, outlaw.getUuid());
        }
    }

    public static void onPlayerKilled(ServerPlayerEntity victim, ServerPlayerEntity killer) {
        completeFor(killer, victim.getUuid());
    }

    /** Если у убийцы есть листовка на эту цель, она становится выполненной. */
    private static void completeFor(ServerPlayerEntity hunter, UUID targetUuid) {
        if (Forms.character(hunter) != Form.HUNTER) return;
        PlayerInventory inv = hunter.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(ModItems.BOUNTY_POSTER) || s.getNbt() == null) continue;
            if (!targetUuid.toString().equals(s.getNbt().getString("TargetUuid"))) continue;

            ItemStack done = new ItemStack(ModItems.BOUNTY_POSTER_DONE);
            done.setNbt(s.getNbt().copy());
            inv.setStack(i, done);
            ServerWorld w = hunter.getServerWorld();
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, hunter.getX(), hunter.getY() + 1.2, hunter.getZ(), 20, 0.5, 0.6, 0.5, 0.0);
            w.playSound(null, hunter.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.2f);
            hunter.sendMessage(Text.translatable("message.arcane.bounty_done"), false);
            return;
        }
    }
}

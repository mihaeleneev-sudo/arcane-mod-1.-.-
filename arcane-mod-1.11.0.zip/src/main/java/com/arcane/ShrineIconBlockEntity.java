package com.arcane;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;

import java.util.UUID;

/** Хранит, сколько дней и когда молился каждый игрок. */
public class ShrineIconBlockEntity extends BlockEntity {
    private NbtCompound players = new NbtCompound();

    public ShrineIconBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.SHRINE_ICON_BE, pos, state);
    }

    public int getCount(UUID id) {
        int[] a = players.getIntArray(id.toString());
        return a.length >= 2 ? a[0] : 0;
    }

    public int getLastDay(UUID id) {
        int[] a = players.getIntArray(id.toString());
        return a.length >= 2 ? a[1] : -1;
    }

    public void setProgress(UUID id, int count, int day) {
        players.putIntArray(id.toString(), new int[]{count, day});
        markDirty();
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        players = nbt.getCompound("players");
    }

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        nbt.put("players", players);
    }
}

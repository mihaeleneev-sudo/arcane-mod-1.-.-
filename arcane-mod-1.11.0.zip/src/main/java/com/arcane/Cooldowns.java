package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Собирает откаты умений текущего персонажа и отправляет их игроку для квадратиков
 * в правом нижнем углу экрана. Ключ (key) - это клавиша на клиенте, под которой стоит умение.
 */
public final class Cooldowns {
    private static final class Slot {
        final String key;
        final int left;
        final int total;

        Slot(String key, int left, int total) {
            this.key = key;
            this.left = left;
            this.total = Math.max(1, total);
        }
    }

    private static final Set<UUID> EMPTY_SENT = new HashSet<>();

    private Cooldowns() {}

    private static List<Slot> build(ServerPlayerEntity p, int now) {
        List<Slot> out = new ArrayList<>();
        Form ch = Forms.character(p);
        if (ch == Form.NONE) return out;
        UUID id = p.getUuid();

        out.add(new Slot("transform", Forms.transformLeft(id, now), Forms.COOLDOWN_TICKS));
        switch (ch) {
            case SAIR -> {
                if (SairUpgrade.isUpgraded(p)) {
                    out.add(new Slot("slash", SairUpgrade.slashLeft(id, now), 80));
                    out.add(new Slot("challenge", SairUpgrade.duelLeft(id, now), 400));
                }
            }
            case EIRO -> {
                if (EiroClaws.hasClaws(p)) {
                    out.add(new Slot("ability", EiroClaws.clawLeft(id, now), 120));
                    out.add(new Slot("laser", 0, 1));   // "Дым" ограничен яростью, а не откатом
                } else {
                    out.add(new Slot("ability", Forms.abilityLeft(id, now), 120));
                }
            }
            case MECHA -> {
                out.add(new Slot("ability", Forms.abilityLeft(id, now), 60));
                out.add(new Slot("laser", 0, 1));
            }
            case ZET -> {
                out.add(new Slot("ability", ZetAbilities.screamLeft(id, now), 300));
                out.add(new Slot("laser", ZetAbilities.scytheLeft(id, now), 600));
            }
            case HUNTER -> {
                out.add(new Slot("ability", HunterAbilities.skillLeft(id, now), 100));
                out.add(new Slot("laser", 0, 1));
            }
            case KING -> {
                out.add(new Slot("horn", KingAbilities.hornLeft(id, now), 1200));
                out.add(new Slot("king_attack", KingAbilities.attackLeft(id, now), 100));
                out.add(new Slot("king_return", KingAbilities.returnLeft(id, now), 60));
                if (KingAbilities.hasWish(p)) out.add(new Slot("king_invis", KingAbilities.invisLeft(id, now), 600));
            }
            case ZEUS -> {
                out.add(new Slot("ability", ZeusAbilities.cd1Left(id, now), 60));
                out.add(new Slot("laser", ZeusAbilities.cd2Left(id, now), 160));
            }
            default -> { }
        }
        return out;
    }

    private static void send(ServerPlayerEntity p, List<Slot> slots) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(slots.size());
        for (Slot s : slots) {
            buf.writeString(s.key);
            buf.writeInt(s.left);
            buf.writeInt(s.total);
        }
        ServerPlayNetworking.send(p, Packets.COOLDOWNS, buf);
    }

    public static void tick(MinecraftServer server, int t) {
        if (t % 4 != 0) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            List<Slot> slots = build(p, t);
            UUID id = p.getUuid();
            if (slots.isEmpty()) {
                if (EMPTY_SENT.add(id)) send(p, slots);   // один раз сообщаем, что откатов нет
            } else {
                EMPTY_SENT.remove(id);
                send(p, slots);
            }
        }
    }
}

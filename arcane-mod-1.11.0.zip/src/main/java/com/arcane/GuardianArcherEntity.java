package com.arcane;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

import java.util.UUID;

/** Лучник Желания. Стреляет по цели, на которую указал Король. Не горит на солнце. */
public class GuardianArcherEntity extends SkeletonEntity implements KingGuardian {
    private UUID owner;

    public GuardianArcherEntity(EntityType<? extends SkeletonEntity> type, World world) {
        super(type, world);
    }

    @Override
    public UUID getOwnerId() { return owner; }

    @Override
    public void setOwnerId(UUID id) { this.owner = id; }

    /** Оружие (лук) подбирает сам скелет при экипировке; здесь только небоевые цели. */
    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(5, new FollowOwnerGoal(this));
        this.goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(8, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
    }

    public boolean isAffectedByDaylight() { return false; }

    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 200 == 0) {
            MinecraftServer server = this.getServer();
            if (owner == null || server == null || server.getPlayerManager().getPlayer(owner) == null) this.discard();
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (owner != null) nbt.putUuid("KingOwner", owner);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("KingOwner")) owner = nbt.getUuid("KingOwner");
    }
}

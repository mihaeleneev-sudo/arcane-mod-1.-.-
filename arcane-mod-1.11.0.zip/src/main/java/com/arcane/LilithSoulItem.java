package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Душа Лилит: поглотить её может только носитель Эйро. */
public class LilithSoulItem extends Item {
    public LilithSoulItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        if (user instanceof ServerPlayerEntity sp) {
            if (Forms.character(sp) != Form.EIRO) {
                sp.sendMessage(Text.translatable("message.arcane.soul_only_eiro"), true);
                return TypedActionResult.fail(stack);
            }
            if (EiroClaws.hasClaws(sp)) {
                sp.sendMessage(Text.translatable("message.arcane.soul_already"), true);
                return TypedActionResult.fail(stack);
            }
            EiroClaws.absorbSoul(sp);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack);
    }
}

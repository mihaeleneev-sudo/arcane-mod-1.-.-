package com.arcane;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Меха Полдень: использовать нельзя. Как только предмет окажется в инвентаре, он сам прилипает к игроку. */
public class MechaNoonItem extends Item {
    public MechaNoonItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient) user.sendMessage(Text.translatable("message.arcane.noon_cannot_use"), true);
        return TypedActionResult.fail(user.getStackInHand(hand));
    }
}

package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Эйро с душой Лилит: когти (пассивное кровотечение, умение "Когти"), ярость и умение "Дым".
 * Блок-бросок заменён когтями.
 */
public final class EiroClaws {
    private static final String TAG_CLAWS = "arcane_eiro_claws";
    private static final String TAG_SLAIN = "arcane_lilith_slain";
    private static final String RAGE_PREFIX = "arcane_rage_";

    public static final int RAGE_MAX = 100;
    private static final int CLAW_COOLDOWN = 6 * 20;
    private static final double CLAW_RANGE = 5.0;
    private static final float CLAW_DAMAGE = 12.0f;
    private static final int FOLLOWUP_TICKS = 5 * 20;
    private static final int BLEED_TICKS = 8 * 20;
    private static final double SMOKE_RADIUS = 10.0;   // диаметр 20 блоков
    private static final int SMOKE_COST = 5;           // ярости каждые полсекунды

    private static final DustParticleEffect BLOOD = new DustParticleEffect(new Vector3f(0.85f, 0.02f, 0.02f), 1.4f);

    private static final class Bleed {
        final ServerWorld world;
        final LivingEntity entity;
        int ticks;

        Bleed(ServerWorld world, LivingEntity entity, int ticks) {
            this.world = world;
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    private static final class Followup {
        final ServerWorld world;
        final LivingEntity target;
        final UUID attacker;
        final float damage;
        int ticks;

        Followup(ServerWorld world, LivingEntity target, UUID attacker, float damage, int ticks) {
            this.world = world;
            this.target = target;
            this.attacker = attacker;
            this.damage = damage;
            this.ticks = ticks;
        }
    }

    private static final class Smoke {
        final ServerWorld world;
        Vec3d center;
        int ticks = 0;

        Smoke(ServerWorld world, Vec3d center) {
            this.world = world;
            this.center = center;
        }
    }

    private static final Map<UUID, Bleed> BLEEDS = new HashMap<>();
    private static final java.util.List<Followup> FOLLOWUPS = new ArrayList<>();
    private static final Map<UUID, Smoke> SMOKES = new HashMap<>();
    private static final Map<UUID, Integer> CLAW_CD = new HashMap<>();
    private static final Set<UUID> RAGE_DIRTY = new HashSet<>();
    private static boolean sharing = false;
    private static boolean bleedDamage = false;

    private EiroClaws() {}

    public static int clawLeft(java.util.UUID id, int now) { return Math.max(0, CLAW_CD.getOrDefault(id, 0) - now); }


    // ---------- состояние (теги игрока, поэтому сохраняется) ----------

    public static boolean hasClaws(PlayerEntity p) { return p.getCommandTags().contains(TAG_CLAWS); }

    public static boolean isSlain(PlayerEntity p) { return p.getCommandTags().contains(TAG_SLAIN); }

    public static void markSlain(ServerPlayerEntity p) { p.addCommandTag(TAG_SLAIN); }

    public static int getRage(PlayerEntity p) {
        for (String tag : p.getCommandTags()) {
            if (tag.startsWith(RAGE_PREFIX)) {
                try {
                    return Integer.parseInt(tag.substring(RAGE_PREFIX.length()));
                } catch (NumberFormatException ignored) {
                    // битый тег пропускаем
                }
            }
        }
        return 0;
    }

    private static void setRage(ServerPlayerEntity p, int value) {
        for (String tag : new ArrayList<>(p.getCommandTags())) {
            if (tag.startsWith(RAGE_PREFIX)) p.removeScoreboardTag(tag);
        }
        int v = Math.max(0, Math.min(RAGE_MAX, value));
        if (v > 0) p.addCommandTag(RAGE_PREFIX + v);
        RAGE_DIRTY.add(p.getUuid());
    }

    private static void addRage(ServerPlayerEntity p, int amount) { setRage(p, getRage(p) + amount); }

    private static boolean spendRage(ServerPlayerEntity p, int cost) {
        int r = getRage(p);
        if (r < cost) return false;
        setRage(p, r - cost);
        return true;
    }

    public static void clear(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_CLAWS);
        p.removeScoreboardTag(TAG_SLAIN);
        setRage(p, 0);
        SMOKES.remove(p.getUuid());
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (isSlain(oldP)) newP.addCommandTag(TAG_SLAIN);
        if (hasClaws(oldP)) {
            newP.addCommandTag(TAG_CLAWS);
            newP.addCommandTag(RAGE_PREFIX + getRage(oldP));
        }
    }

    public static void onDeactivate(ServerPlayerEntity p) {
        SMOKES.remove(p.getUuid());
    }

    public static void absorbSoul(ServerPlayerEntity p) {
        p.addCommandTag(TAG_CLAWS);
        p.addCommandTag(TAG_SLAIN);
        setRage(p, 30);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(BLOOD, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.6, 1.0, 0.6, 0.0);
        w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.5, 0.9, 0.5, 0.05);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 0.6f, 1.6f);
        p.sendMessage(Text.translatable("message.arcane.soul_absorbed"), false);
        sendRage(p);
    }

    public static void sendRage(ServerPlayerEntity p) {
        boolean on = Forms.character(p) == Form.EIRO && hasClaws(p);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(on ? getRage(p) : -1);
        ServerPlayNetworking.send(p, Packets.RAGE, buf);
    }

    // ---------- кровотечение ----------

    public static void applyBleed(ServerWorld world, LivingEntity e, int ticks) {
        Bleed b = BLEEDS.get(e.getUuid());
        if (b == null) BLEEDS.put(e.getUuid(), new Bleed(world, e, ticks));
        else b.ticks = Math.max(b.ticks, ticks);
    }

    // ---------- ярость и общий урон в дыму (вызывается из миксина) ----------

    public static void onDamage(LivingEntity victim, DamageSource source, float amount) {
        if (sharing || bleedDamage) return;
        if (victim instanceof ServerPlayerEntity v && Forms.isActive(v, Form.EIRO) && hasClaws(v)) {
            addRage(v, Math.max(1, (int) amount));            // получил урон: копится ярость
        }
        if (source.getAttacker() instanceof ServerPlayerEntity a && a != victim
                && Forms.isActive(a, Form.EIRO) && hasClaws(a)) {
            addRage(a, Math.max(1, (int) (amount * 0.5f)));   // нанёс урон: копится ярость
        }
    }

    /** Любой урон по одному существу в дыму получают все остальные в дыму (кроме самого Эйро). */
    public static void shareDamage(LivingEntity victim, DamageSource source, float amount) {
        if (sharing || bleedDamage || amount <= 0.0f || SMOKES.isEmpty()) return;
        if (victim.timeUntilRegen > 10) return;

        double r2 = SMOKE_RADIUS * SMOKE_RADIUS;
        for (Map.Entry<UUID, Smoke> en : SMOKES.entrySet()) {
            UUID owner = en.getKey();
            Smoke s = en.getValue();
            if (victim.getUuid().equals(owner)) continue;
            if (victim.squaredDistanceTo(s.center) > r2) continue;
            if (s.world.getEntity(victim.getUuid()) != victim) continue;   // то же измерение

            sharing = true;
            try {
                Box box = new Box(s.center.x - SMOKE_RADIUS, s.center.y - SMOKE_RADIUS, s.center.z - SMOKE_RADIUS,
                        s.center.x + SMOKE_RADIUS, s.center.y + SMOKE_RADIUS, s.center.z + SMOKE_RADIUS);
                for (LivingEntity e : s.world.getEntitiesByClass(LivingEntity.class, box,
                        ent -> ent != victim && ent.isAlive() && !ent.getUuid().equals(owner)
                                && ent.squaredDistanceTo(s.center) <= r2)) {
                    e.damage(source, amount);
                    s.world.spawnParticles(BLOOD, e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ(), 6, 0.2, 0.3, 0.2, 0.0);
                }
            } finally {
                sharing = false;
            }
            return;
        }
    }

    // ---------- умение 1: "Когти" (клавиша R) ----------

    /** Четыре красных разреза: плоскость перед игроком, перпендикулярная направлению удара. */
    public static void slashes(ServerWorld w, Vec3d center, Vec3d fwd) {
        Vec3d right = new Vec3d(-fwd.z, 0.0, fwd.x);
        for (int i = 0; i < 4; i++) {
            double lateral = (i - 1.5) * 0.9;
            for (int s = 0; s <= 14; s++) {
                double t = s / 14.0;
                Vec3d pt = center.add(right.multiply(lateral + (t - 0.5) * 1.4)).add(0.0, 2.4 - t * 2.2, 0.0);
                w.spawnParticles(BLOOD, pt.x, pt.y, pt.z, 1, 0.02, 0.02, 0.02, 0.0);
            }
        }
    }

    public static void clawStrike(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        int now = p.getServer().getTicks();
        int until = CLAW_CD.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }
        CLAW_CD.put(id, now + CLAW_COOLDOWN);

        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        if (flat.lengthSquared() < 1.0E-4) flat = new Vec3d(0.0, 0.0, 1.0);
        Vec3d fwd = flat.normalize();

        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(CLAW_RANGE, 2.5, CLAW_RANGE), ent -> ent != p && ent.isAlive())) {
            Vec3d rel = new Vec3d(e.getX() - p.getX(), 0.0, e.getZ() - p.getZ());
            double dist = rel.length();
            if (dist > CLAW_RANGE || dist < 1.0E-4) continue;
            if (rel.normalize().dotProduct(fwd) < 0.34) continue;          // широкий удар: около 140 градусов
            if (Math.abs(e.getY() - p.getY()) > 2.5) continue;

            e.damage(p.getDamageSources().playerAttack(p), CLAW_DAMAGE);
            applyBleed(w, e, BLEED_TICKS);
            if (p.getRandom().nextFloat() < 0.5f) {                         // 50%: такой же удар через 5 секунд
                FOLLOWUPS.add(new Followup(w, e, id, CLAW_DAMAGE, FOLLOWUP_TICKS));
            }
        }
        slashes(w, p.getPos().add(fwd.multiply(3.0)), fwd);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.5f, 0.6f);
    }

    private static void doFollowup(MinecraftServer server, Followup f) {
        LivingEntity target = f.target;
        if (!target.isAlive()) return;
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(f.attacker);
        if (p == null || !p.isAlive()) return;

        Vec3d dir = new Vec3d(target.getX() - p.getX(), 0.0, target.getZ() - p.getZ());
        Vec3d fwd = dir.lengthSquared() < 1.0E-4 ? new Vec3d(0.0, 0.0, 1.0) : dir.normalize();
        target.damage(p.getDamageSources().playerAttack(p), f.damage);
        applyBleed(f.world, target, BLEED_TICKS);
        slashes(f.world, target.getPos(), fwd);
        f.world.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.2f, 0.5f);
    }

    // ---------- умение 2: "Дым" (клавиша G, удерживать) ----------

    public static void smokeKey(ServerPlayerEntity p, boolean pressed) {
        UUID id = p.getUuid();
        if (!pressed) {
            SMOKES.remove(id);
            return;
        }
        if (!Forms.isActive(p, Form.EIRO) || !hasClaws(p)) return;
        if (getRage(p) <= 0) {
            p.sendMessage(Text.translatable("message.arcane.no_rage"), true);
            return;
        }
        SMOKES.put(id, new Smoke(p.getServerWorld(), p.getPos()));
    }

    // ---------- тик ----------

    public static void tick(MinecraftServer server, int t) {
        // кровотечение: 1.5 урона раз в секунду, игнорирует броню
        Iterator<Map.Entry<UUID, Bleed>> bit = BLEEDS.entrySet().iterator();
        while (bit.hasNext()) {
            Bleed b = bit.next().getValue();
            LivingEntity e = b.entity;
            if (!e.isAlive() || --b.ticks <= 0) {
                bit.remove();
                continue;
            }
            if (b.ticks % 5 == 0) {
                b.world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState()),
                        e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ(), 4, 0.2, 0.3, 0.2, 0.05);
            }
            if (b.ticks % 20 == 0) {
                bleedDamage = true;
                try {
                    e.damage(b.world.getDamageSources().magic(), 1.5f);
                } finally {
                    bleedDamage = false;
                }
            }
        }

        // повторные удары когтями
        Iterator<Followup> fit = FOLLOWUPS.iterator();
        while (fit.hasNext()) {
            Followup f = fit.next();
            if (--f.ticks <= 0) {
                fit.remove();
                doFollowup(server, f);
            }
        }

        // дым: следует за Эйро, тратит ярость, пока держат клавишу
        Iterator<Map.Entry<UUID, Smoke>> sit = SMOKES.entrySet().iterator();
        while (sit.hasNext()) {
            Map.Entry<UUID, Smoke> en = sit.next();
            Smoke s = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.EIRO) || !hasClaws(p)
                    || p.getServerWorld() != s.world) {
                sit.remove();
                continue;
            }
            s.center = p.getPos();
            s.ticks++;
            // негустой дым: мало частиц на большой площади
            for (int i = 0; i < 30; i++) {
                double angle = p.getRandom().nextDouble() * Math.PI * 2.0;
                double radius = SMOKE_RADIUS * Math.sqrt(p.getRandom().nextDouble());
                s.world.spawnParticles(ParticleTypes.SMOKE,
                        s.center.x + Math.cos(angle) * radius, s.center.y + p.getRandom().nextDouble() * 3.0,
                        s.center.z + Math.sin(angle) * radius, 1, 0.0, 0.0, 0.0, 0.0);
            }
            if (s.ticks % 10 == 0 && !spendRage(p, SMOKE_COST)) {
                sit.remove();
                p.sendMessage(Text.translatable("message.arcane.no_rage"), true);
            }
        }

        // синхронизация шкалы ярости
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (Forms.character(p) == Form.EIRO && hasClaws(p)) {
                if (RAGE_DIRTY.remove(p.getUuid()) || t % 20 == 0) sendRage(p);
            }
        }
    }
}

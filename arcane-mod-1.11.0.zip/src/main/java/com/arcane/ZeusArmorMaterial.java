package com.arcane;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

/** Материал жилета Зевса: синяя ткань с медью. Текстура брони называется "zeus". */
public enum ZeusArmorMaterial implements ArmorMaterial {
    INSTANCE;

    @Override
    public int getDurability(ArmorItem.Type type) {
        return 330;
    }

    @Override
    public int getProtection(ArmorItem.Type type) {
        return type == ArmorItem.Type.CHESTPLATE ? 6 : 0;
    }

    @Override
    public int getEnchantability() {
        return 16;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_CHAIN;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.COPPER_INGOT);
    }

    @Override
    public String getName() {
        return "zeus";
    }

    @Override
    public float getToughness() {
        return 1.0f;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0f;
    }
}

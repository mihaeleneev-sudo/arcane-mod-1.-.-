package com.arcane;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    /** Икона неразрушаема, как бедрок, и слегка светится. */
    public static final Block SHRINE_ICON = Registry.register(Registries.BLOCK,
            new Identifier(ArcaneMod.MOD_ID, "shrine_icon"),
            new ShrineIconBlock(AbstractBlock.Settings.copy(Blocks.BEDROCK).luminance(state -> 6)));

    public static final BlockEntityType<ShrineIconBlockEntity> SHRINE_ICON_BE = Registry.register(
            Registries.BLOCK_ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "shrine_icon"),
            FabricBlockEntityTypeBuilder.create(ShrineIconBlockEntity::new, SHRINE_ICON).build());

    public static final Item SHRINE_ICON_ITEM = Registry.register(Registries.ITEM,
            new Identifier(ArcaneMod.MOD_ID, "shrine_icon"),
            new BlockItem(SHRINE_ICON, new Item.Settings()));

    public static final Block BOUNTY_BOARD = Registry.register(Registries.BLOCK,
            new Identifier(ArcaneMod.MOD_ID, "bounty_board"),
            new BountyBoardBlock(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)));

    public static final Item BOUNTY_BOARD_ITEM = Registry.register(Registries.ITEM,
            new Identifier(ArcaneMod.MOD_ID, "bounty_board"),
            new BlockItem(BOUNTY_BOARD, new Item.Settings()));

    private ModBlocks() {}

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> {
            e.add(SHRINE_ICON_ITEM);
            e.add(BOUNTY_BOARD_ITEM);
        });
    }
}

package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Улучшенный Саир: молитвы в храме, осколок брони, шляпа Дэву, "Разрез", "Вызов" (дуэли)
 * и "гарантированное блокирование" на руках.
 */
public final class SairUpgrade {
    private static final String TAG_UP = "arcane_sair_up";
    private static final String WINS_PREFIX = "arcane_duelwins_";
    private static final String GUARD_PREFIX = "arcane_guard_";

    public static final int GUARD_MAX_HALVES = 20;   // 10 очков блока
    public static final int PRAYER_DAYS = 7;
    private static final int PRAYER_TICKS = 5 * 20;

    private static final int SLASH_COOLDOWN = 4 * 20;
    private static final double SLASH_RADIUS = 5.5;
    private static final int HOLD_TICKS = 10;

    /** Каждая выигранная дуэль даёт +1 к броне Саира (максимум +20). */
    private static final UUID ARMOR_UUID = UUID.fromString("5f1a3c52-8d3e-4c7a-9b61-2a7e0c4d9a11");
    private static final double ARMOR_PER_WIN = 1.0;
    private static final double ARMOR_CAP = 20.0;

    private static final int DUEL_COOLDOWN_TICKS = 20 * 20;
    private static final int DUEL_TIMEOUT = 3 * 60 * 20;

    private static final class Prayer {
        final BlockPos pos;
        final Vec3d start;
        int ticks = 0;

        Prayer(BlockPos pos, Vec3d start) {
            this.pos = pos;
            this.start = start;
        }
    }

    private static final class Duel {
        final ServerWorld world;
        final DuelistEntity entity;
        int age = 0;

        Duel(ServerWorld world, DuelistEntity entity) {
            this.world = world;
            this.entity = entity;
        }
    }

    private static final Map<UUID, Prayer> PRAYERS = new HashMap<>();
    private static final Map<UUID, Duel> DUELS = new HashMap<>();
    private static final Map<UUID, Integer> DUEL_CD = new HashMap<>();
    private static final Map<UUID, Integer> SLASH_CD = new HashMap<>();
    private static final Map<UUID, Integer> SLASH_HOLD = new HashMap<>();

    private SairUpgrade() {}

    public static int slashLeft(java.util.UUID id, int now) { return Math.max(0, SLASH_CD.getOrDefault(id, 0) - now); }
    public static int duelLeft(java.util.UUID id, int now) { return Math.max(0, DUEL_CD.getOrDefault(id, 0) - now); }


    // ---------- состояние ----------

    public static boolean isUpgraded(PlayerEntity p) {
        return p.getCommandTags().contains(TAG_UP);
    }

    /** Улучшенный Саир бьёт на 50% сильнее. */
    public static float damageMult(PlayerEntity p) {
        return isUpgraded(p) ? 1.5f : 1.0f;
    }

    private static int getInt(PlayerEntity p, String prefix) {
        for (String tag : p.getCommandTags()) {
            if (tag.startsWith(prefix)) {
                try {
                    return Integer.parseInt(tag.substring(prefix.length()));
                } catch (NumberFormatException ignored) {
                    // битый тег пропускаем
                }
            }
        }
        return 0;
    }

    private static void setInt(ServerPlayerEntity p, String prefix, int value) {
        for (String tag : new ArrayList<>(p.getCommandTags())) {
            if (tag.startsWith(prefix)) p.removeScoreboardTag(tag);
        }
        if (value > 0) p.addCommandTag(prefix + value);
    }

    public static int getWins(PlayerEntity p) { return getInt(p, WINS_PREFIX); }

    public static int armorBonus(PlayerEntity p) {
        return (int) Math.min(ARMOR_CAP, getWins(p) * ARMOR_PER_WIN);
    }

    /** Выдаёт или снимает бонус брони: он есть только в форме улучшенного Саира. */
    public static void applyArmor(ServerPlayerEntity p) {
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (inst == null) return;
        boolean on = Forms.isActive(p, Form.SAIR) && isUpgraded(p);
        double bonus = armorBonus(p);
        EntityAttributeModifier cur = inst.getModifier(ARMOR_UUID);
        if (!on || bonus <= 0.0) {
            if (cur != null) inst.removeModifier(ARMOR_UUID);
            return;
        }
        if (cur != null && cur.getValue() == bonus) return;
        if (cur != null) inst.removeModifier(ARMOR_UUID);
        inst.addTemporaryModifier(new EntityAttributeModifier(ARMOR_UUID, "Duel armor", bonus,
                EntityAttributeModifier.Operation.ADDITION));
    }

    /** Блок на руках в половинках очка (1 половинка = 0.5). */
    public static int getGuard(PlayerEntity p) { return getInt(p, GUARD_PREFIX); }

    public static void clear(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_UP);
        setInt(p, WINS_PREFIX, 0);
        setInt(p, GUARD_PREFIX, 0);
        applyArmor(p);
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (!isUpgraded(oldP)) return;
        newP.addCommandTag(TAG_UP);
        setInt(newP, WINS_PREFIX, getWins(oldP));
        setInt(newP, GUARD_PREFIX, getGuard(oldP));
    }

    public static void upgrade(ServerPlayerEntity p) {
        p.addCommandTag(TAG_UP);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.2, p.getZ(), 60, 0.5, 0.9, 0.5, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BELL_USE, SoundCategory.PLAYERS, 1.5f, 0.7f);
        p.sendMessage(Text.translatable("message.arcane.upgraded"), false);
        Forms.broadcast(p.getServer(), p);
        applyArmor(p);
        sendDuel(p);
    }

    public static void sendDuel(ServerPlayerEntity p) {
        boolean on = Forms.character(p) == Form.SAIR && isUpgraded(p);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(on ? getWins(p) : -1);
        buf.writeInt(on ? getGuard(p) : 0);
        buf.writeBoolean(on && DUELS.containsKey(p.getUuid()));
        ServerPlayNetworking.send(p, Packets.DUEL, buf);
    }

    public static void onDeactivate(ServerPlayerEntity p) {
        SLASH_HOLD.remove(p.getUuid());
        applyArmor(p);
    }

    public static void onDeath(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        PRAYERS.remove(id);
        SLASH_HOLD.remove(id);
        Duel duel = DUELS.remove(id);
        if (duel != null && duel.entity.isAlive()) duel.entity.discard();
    }

    // ---------- гарантированное блокирование на руках ----------

    /**
     * Каждая половинка очка блока гасит 2 единицы урона (одно сердце). Блок восстанавливается
     * только победами в дуэлях. Работает в форме улучшенного Саира против ударов существ.
     */
    public static float absorbWithGuard(ServerPlayerEntity victim, float amount) {
        if (victim.timeUntilRegen > 10) return amount;
        if (!Forms.isActive(victim, Form.SAIR) || !isUpgraded(victim)) return amount;
        int guard = getGuard(victim);
        if (guard <= 0) return amount;

        float absorbed = Math.min(amount, guard * 2.0f);
        int used = (int) Math.ceil(absorbed / 2.0f);
        setInt(victim, GUARD_PREFIX, guard - used);

        ServerWorld w = victim.getServerWorld();
        w.spawnParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + 1.2, victim.getZ(), 12, 0.4, 0.3, 0.4, 0.2);
        if (guard - used <= 0) {
            w.playSound(null, victim.getBlockPos(), SoundEvents.ITEM_SHIELD_BREAK, SoundCategory.PLAYERS, 1.0f, 0.8f);
            victim.sendMessage(Text.translatable("message.arcane.guard_broken"), true);
        } else {
            w.playSound(null, victim.getBlockPos(), SoundEvents.ITEM_SHIELD_BLOCK, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
        sendDuel(victim);
        return amount - absorbed;
    }

    // ---------- молитва иконе ----------

    public static void startPrayer(ServerPlayerEntity p, BlockPos pos) {
        ServerWorld w = p.getServerWorld();
        UUID id = p.getUuid();
        if (Forms.character(p) != Form.SAIR) {
            p.sendMessage(Text.translatable("message.arcane.prayer_not_sair"), true);
            return;
        }
        if (isUpgraded(p)) {
            p.sendMessage(Text.translatable("message.arcane.prayer_done"), true);
            return;
        }
        BlockEntity be = w.getBlockEntity(pos);
        if (!(be instanceof ShrineIconBlockEntity shrine)) return;

        if (shrine.getCount(id) >= PRAYER_DAYS) {
            p.sendMessage(Text.translatable("message.arcane.prayer_done"), true);
            return;
        }
        int day = (int) (w.getTimeOfDay() / 24000L);
        if (shrine.getLastDay(id) == day) {
            p.sendMessage(Text.translatable("message.arcane.prayer_today"), true);
            return;
        }
        if (PRAYERS.containsKey(id)) return;

        PRAYERS.put(id, new Prayer(pos, p.getPos()));
        p.sendMessage(Text.translatable("message.arcane.prayer_start"), true);
    }

    private static void completePrayer(ServerPlayerEntity p, BlockPos pos) {
        ServerWorld w = p.getServerWorld();
        BlockEntity be = w.getBlockEntity(pos);
        if (!(be instanceof ShrineIconBlockEntity shrine)) return;

        UUID id = p.getUuid();
        int day = (int) (w.getTimeOfDay() / 24000L);
        int count = shrine.getCount(id) + 1;
        shrine.setProgress(id, count, day);

        // под иконой появляется сакэ, а после 7-й молитвы ещё и осколок брони
        Vec3d drop = Vec3d.ofCenter(pos.down());
        ItemScatterer.spawn(w, drop.x, drop.y, drop.z, new ItemStack(ModItems.SAKE));
        w.spawnParticles(ParticleTypes.ENCHANT, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 40, 0.8, 0.8, 0.8, 0.6);
        w.playSound(null, pos, SoundEvents.BLOCK_BELL_USE, SoundCategory.BLOCKS, 1.5f, 1.0f);

        if (count >= PRAYER_DAYS) {
            ItemScatterer.spawn(w, drop.x, drop.y, drop.z, new ItemStack(ModItems.ARMOR_SHARD));
            w.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.BLOCKS, 1.5f, 1.0f);
            p.sendMessage(Text.translatable("message.arcane.shard_appeared"), false);
        } else {
            p.sendMessage(Text.translatable("message.arcane.prayer_accepted", count, PRAYER_DAYS), false);
        }
    }

    private static void tickPrayers(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Prayer>> it = PRAYERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Prayer> en = it.next();
            Prayer pr = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive()) {
                it.remove();
                continue;
            }
            boolean moved = p.getPos().squaredDistanceTo(pr.start) > 0.36;
            boolean far = p.squaredDistanceTo(pr.pos.getX() + 0.5, pr.pos.getY() + 0.5, pr.pos.getZ() + 0.5) > 36.0;
            if (moved || far || p.getServerWorld().getBlockEntity(pr.pos) == null) {
                p.sendMessage(Text.translatable("message.arcane.prayer_broken"), true);
                it.remove();
                continue;
            }

            pr.ticks++;
            if (pr.ticks % 5 == 0) {
                p.getServerWorld().spawnParticles(ParticleTypes.ENCHANT,
                        pr.pos.getX() + 0.5, pr.pos.getY() + 0.3, pr.pos.getZ() + 0.5, 3, 0.5, 0.5, 0.5, 0.4);
            }
            if (pr.ticks % 20 == 0 && pr.ticks < PRAYER_TICKS) {
                p.sendMessage(Text.translatable("message.arcane.prayer_progress", pr.ticks / 20, PRAYER_TICKS / 20), true);
            }
            if (pr.ticks >= PRAYER_TICKS) {
                completePrayer(p, pr.pos);
                it.remove();
            }
        }
    }

    // ---------- умение "Разрез" ----------

    /** Нажатие: мгновенная вспышка вокруг игрока. Удержание: ещё и вертикальный удар перед игроком. */
    public static void handleSlashKey(ServerPlayerEntity p, boolean pressed) {
        UUID id = p.getUuid();
        if (!pressed) {
            SLASH_HOLD.remove(id);
            return;
        }
        if (!Forms.isActive(p, Form.SAIR) || !isUpgraded(p)) return;
        int now = p.getServer().getTicks();
        int until = SLASH_CD.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }
        SLASH_CD.put(id, now + SLASH_COOLDOWN);
        circularSlash(p);
        SLASH_HOLD.put(id, 0);
    }

    private static double horizSq(LivingEntity e, PlayerEntity p) {
        double dx = e.getX() - p.getX();
        double dz = e.getZ() - p.getZ();
        return dx * dx + dz * dz;
    }

    private static void circularSlash(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        float dmg = 10.0f * damageMult(p);
        double r2 = SLASH_RADIUS * SLASH_RADIUS;
        Box box = p.getBoundingBox().expand(SLASH_RADIUS, 2.5, SLASH_RADIUS);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                ent -> ent != p && ent.isAlive() && horizSq(ent, p) <= r2)) {
            e.damage(p.getDamageSources().playerAttack(p), dmg);
            e.takeKnockback(0.6, p.getX() - e.getX(), p.getZ() - e.getZ());
        }
        for (double r = 1.5; r <= SLASH_RADIUS; r += 1.75) {
            for (int deg = 0; deg < 360; deg += 12) {
                double a = Math.toRadians(deg);
                w.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                        p.getX() + Math.cos(a) * r, p.getY() + 1.0, p.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0);
            }
        }
        w.spawnParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 40, 2.5, 0.3, 2.5, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.5f, 0.9f);
    }

    private static void verticalSlash(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        if (flat.lengthSquared() < 1.0E-4) flat = new Vec3d(0.0, 0.0, 1.0);
        Vec3d fwd = flat.normalize();
        double len = 7.0;
        float dmg = 14.0f * damageMult(p);

        Box box = p.getBoundingBox().expand(len, 4.0, len);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, ent -> ent != p && ent.isAlive())) {
            Vec3d rel = new Vec3d(e.getX() - p.getX(), 0.0, e.getZ() - p.getZ());
            double along = rel.dotProduct(fwd);
            if (along < 0.3 || along > len) continue;
            Vec3d lateral = rel.subtract(fwd.multiply(along));
            if (lateral.length() > 1.6) continue;
            double dy = e.getY() - p.getY();
            if (dy < -1.5 || dy > 4.0) continue;
            e.damage(p.getDamageSources().playerAttack(p), dmg);
            e.setVelocity(e.getVelocity().add(0.0, 0.4, 0.0));
            e.velocityModified = true;
        }
        for (double d = 1.0; d <= len; d += 1.0) {
            for (double y = -0.5; y <= 3.5; y += 0.5) {
                w.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                        p.getX() + fwd.x * d, p.getY() + 0.5 + y, p.getZ() + fwd.z * d, 1, 0, 0, 0, 0);
            }
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.5f, 0.7f);
    }

    private static void tickSlashHold(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Integer>> it = SLASH_HOLD.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> en = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.SAIR)) {
                it.remove();
                continue;
            }
            int v = en.getValue() + 1;
            en.setValue(v);
            if (v == HOLD_TICKS) verticalSlash(p);
        }
    }

    // ---------- умение "Вызов": дуэль с мобом-игроком ----------

    public static void handleChallenge(ServerPlayerEntity p) {
        if (!Forms.isActive(p, Form.SAIR) || !isUpgraded(p)) return;
        UUID id = p.getUuid();
        if (DUELS.containsKey(id)) {
            p.sendMessage(Text.translatable("message.arcane.duel_active"), true);
            return;
        }
        int now = p.getServer().getTicks();
        int until = DUEL_CD.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }

        ServerWorld w = p.getServerWorld();
        DuelistEntity d = new DuelistEntity(ModEntities.DUELIST, w);
        Vec3d look = p.getRotationVec(1.0f);
        d.refreshPositionAndAngles(p.getX() + look.x * 4.0, p.getY(), p.getZ() + look.z * 4.0, p.getYaw() + 180.0f, 0.0f);

        // чем больше побед, тем сильнее противник
        int wins = getWins(p);
        double hp = Math.min(120.0, 30.0 + 6.0 * wins);
        EntityAttributeInstance hpAttr = d.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (hpAttr != null) hpAttr.setBaseValue(hp);
        d.setHealth((float) hp);
        EntityAttributeInstance dmgAttr = d.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (dmgAttr != null) dmgAttr.setBaseValue(Math.min(14.0, 4.0 + 0.6 * wins));

        d.equipStack(EquipmentSlot.MAINHAND, new ItemStack(wins >= 5 ? Items.DIAMOND_SWORD : Items.IRON_SWORD));
        d.setEquipmentDropChance(EquipmentSlot.MAINHAND, 0.0f);
        d.setCustomName(Text.translatable("entity.arcane.duelist"));
        d.setCustomNameVisible(true);
        d.setPersistent();
        d.setTarget(p);
        w.spawnEntity(d);

        DUELS.put(id, new Duel(w, d));
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, d.getX(), d.getY() + 1.0, d.getZ(), 30, 0.4, 0.8, 0.4, 0.05);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.2f, 0.8f);
        p.sendMessage(Text.translatable("message.arcane.duel_start"), false);
        sendDuel(p);
    }

    private static void winDuel(ServerPlayerEntity p) {
        setInt(p, WINS_PREFIX, getWins(p) + 1);
        setInt(p, GUARD_PREFIX, Math.min(GUARD_MAX_HALVES, getGuard(p) + 1));   // +0.5 блока за победу
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.2, p.getZ(), 40, 0.5, 0.9, 0.5, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.2f, 1.0f);
        applyArmor(p);
        p.sendMessage(Text.translatable("message.arcane.duel_win", getWins(p), armorBonus(p)), false);
        sendDuel(p);
    }

    private static void tickDuels(MinecraftServer server, int t) {
        Iterator<Map.Entry<UUID, Duel>> it = DUELS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Duel> en = it.next();
            UUID id = en.getKey();
            Duel duel = en.getValue();
            DuelistEntity d = duel.entity;
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);

            if (p == null || !p.isAlive()) {   // вызвавший пал или вышел: дуэль проиграна
                if (d.isAlive()) d.discard();
                it.remove();
                DUEL_CD.put(id, t + DUEL_COOLDOWN_TICKS);
                continue;
            }
            if (!d.isAlive()) {
                LivingEntity killer = d.getAttacker();
                it.remove();
                DUEL_CD.put(id, t + DUEL_COOLDOWN_TICKS);
                if (killer == p) {
                    winDuel(p);
                } else {
                    p.sendMessage(Text.translatable("message.arcane.duel_void"), true);
                    sendDuel(p);
                }
                continue;
            }
            if (++duel.age > DUEL_TIMEOUT || d.squaredDistanceTo(p) > 4096.0) {
                d.discard();
                it.remove();
                DUEL_CD.put(id, t + DUEL_COOLDOWN_TICKS);
                p.sendMessage(Text.translatable("message.arcane.duel_timeout"), true);
                sendDuel(p);
                continue;
            }
            if (t % 20 == 0) d.setTarget(p);
        }
    }

    public static void tick(MinecraftServer server, int t) {
        if (t % 20 == 0) {
            for (ServerPlayerEntity pl : server.getPlayerManager().getPlayerList()) applyArmor(pl);
        }
        tickPrayers(server);
        tickSlashHold(server);
        tickDuels(server, t);
    }
}

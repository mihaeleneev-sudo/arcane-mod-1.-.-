package com.arcane;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Листовка с наградой. Невыполненная и выполненная - один класс, разные предметы. */
public class BountyPosterItem extends Item {
    private final boolean done;

    public BountyPosterItem(Settings settings, boolean done) {
        super(settings);
        this.done = done;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        NbtCompound nbt = stack.getNbt();
        if (nbt == null) return;
        String kind = nbt.getString("Kind");
        tooltip.add(Text.translatable("outlaw".equals(kind) ? "tooltip.arcane.poster_outlaw" : "tooltip.arcane.poster_player")
                .formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.arcane.poster_target", nbt.getString("TargetName")).formatted(Formatting.GOLD));
        String hint = nbt.getString("Hint");
        if (!hint.isEmpty() && !done) {
            tooltip.add(Text.translatable("tooltip.arcane.poster_hint", hint).formatted(Formatting.GRAY));
        }
        tooltip.add(Text.translatable(done ? "tooltip.arcane.poster_done" : "tooltip.arcane.poster_reward")
                .formatted(done ? Formatting.GREEN : Formatting.DARK_GREEN));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        return TypedActionResult.pass(user.getStackInHand(hand));
    }
}

package com.arcane.client;

import com.arcane.DuelistEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Дуэлянт рисуется как игрок со своим скином. */
public class DuelistRenderer extends BipedEntityRenderer<DuelistEntity, PlayerEntityModel<DuelistEntity>> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/duelist.png");

    public DuelistRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(DuelistEntity entity) {
        return TEXTURE;
    }
}

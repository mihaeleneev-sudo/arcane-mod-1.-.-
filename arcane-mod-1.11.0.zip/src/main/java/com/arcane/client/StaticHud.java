package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Шкала статического электричества Зевса (слева внизу). При заряде показывает таймер усиления. */
public final class StaticHud {
    private static final int BAR_W = 100;
    private static int gauge = -1;       // -1: Зевса нет
    private static int overTicks = -1;   // -1: усиления нет

    private StaticHud() {}

    public static void set(int g, int over) {
        gauge = g;
        overTicks = over;
    }

    public static void clear() {
        gauge = -1;
        overTicks = -1;
    }

    public static void tick() {
        if (overTicks > 0) overTicks--;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (gauge < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 10;
        int y = mc.getWindow().getScaledHeight() - 58;

        boolean over = overTicks >= 0;
        if (over) {
            int seconds = (overTicks + 19) / 20;
            ctx.drawTextWithShadow(mc.textRenderer,
                    Text.translatable("hud.arcane.overcharge").append(Text.literal(" " + seconds + "с")), x, y - 11, 0xFFB8F0FF);
            ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
            int w = BAR_W * Math.min(overTicks, 600) / 600;
            // мерцающая полоса: чередуем голубой и белый
            int color = (mc.world != null && (mc.world.getTime() / 3) % 2 == 0) ? 0xFF7FD8FF : 0xFFFFFFFF;
            ctx.fill(x, y, x + w, y + 8, color);
            return;
        }

        ctx.drawTextWithShadow(mc.textRenderer,
                Text.translatable("hud.arcane.static").append(Text.literal(" " + gauge + "/100")), x, y - 11, 0xFF9FD0FF);
        ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
        int fill = BAR_W * Math.max(0, Math.min(100, gauge)) / 100;
        // цвет плавно идёт от синего к жёлтому по мере заряда
        int r = 60 + (195 * gauge) / 100;
        int g = 120 + (135 * gauge) / 100;
        int b = 255 - (135 * gauge) / 100;
        ctx.fill(x, y, x + fill, y + 8, 0xFF000000 | (r << 16) | (g << 8) | b);
        ctx.fill(x, y, x + fill, y + 2, 0xFFE8F6FF);
    }
}

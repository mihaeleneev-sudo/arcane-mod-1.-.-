package com.arcane.client;

import com.arcane.OutlawEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Разыскиваемый рисуется как игрок со своим скином. */
public class OutlawRenderer extends BipedEntityRenderer<OutlawEntity, PlayerEntityModel<OutlawEntity>> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/outlaw.png");

    public OutlawRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(OutlawEntity entity) {
        return TEXTURE;
    }
}

package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Откаты умений: квадратики в правом нижнем углу. В квадрате написана клавиша, на которую
 * поставлено умение (берётся из настроек управления, поэтому при смене клавиши буква меняется).
 */
public final class CooldownHud {
    private static final int SIZE = 24;
    private static final int GAP = 4;

    private static final class Slot {
        final String key;
        int left;
        final int total;

        Slot(String key, int left, int total) {
            this.key = key;
            this.left = left;
            this.total = Math.max(1, total);
        }
    }

    private static final List<Slot> SLOTS = new ArrayList<>();

    private CooldownHud() {}

    public static void set(List<String> keys, int[] lefts, int[] totals) {
        SLOTS.clear();
        for (int i = 0; i < keys.size(); i++) SLOTS.add(new Slot(keys.get(i), lefts[i], totals[i]));
    }

    public static void clear() { SLOTS.clear(); }

    /** Между пакетами откат тикает на клиенте сам, чтобы заливка шла плавно. */
    public static void tick() {
        for (Slot s : SLOTS) if (s.left > 0) s.left--;
    }

    private static String label(KeyBinding key) {
        if (key == null) return "?";
        String s = key.getBoundKeyLocalizedText().getString();
        if (s == null || s.isEmpty()) return "?";
        int sp = s.lastIndexOf(' ');
        if (sp >= 0 && sp < s.length() - 1) s = s.substring(sp + 1);   // "Left Alt" -> "Alt"
        if (s.length() > 3) s = s.substring(0, 3);
        return s.length() == 1 ? s.toUpperCase() : s;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (SLOTS.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        int n = SLOTS.size();
        int total = n * SIZE + (n - 1) * GAP;
        int x0 = mc.getWindow().getScaledWidth() - 10 - total;
        int y = mc.getWindow().getScaledHeight() - 10 - SIZE;

        for (int i = 0; i < n; i++) {
            Slot s = SLOTS.get(i);
            int x = x0 + i * (SIZE + GAP);
            boolean ready = s.left <= 0;

            ctx.fill(x, y, x + SIZE, y + SIZE, 0xB0101018);
            if (!ready) {
                // тёмная заливка сверху вниз: чем меньше осталось, тем она ниже и меньше
                float fraction = Math.max(0.0f, Math.min(1.0f, s.left / (float) s.total));
                ctx.fill(x, y, x + SIZE, y + Math.round(SIZE * fraction), 0xD0202028);
            }
            int border = ready ? 0xFF7BE08A : 0xFF555560;
            ctx.fill(x, y, x + SIZE, y + 1, border);
            ctx.fill(x, y + SIZE - 1, x + SIZE, y + SIZE, border);
            ctx.fill(x, y, x + 1, y + SIZE, border);
            ctx.fill(x + SIZE - 1, y, x + SIZE, y + SIZE, border);

            // буква клавиши
            String letter = label(ArcaneClient.keyFor(s.key));
            float scale = 1.25f;
            ctx.getMatrices().push();
            ctx.getMatrices().scale(scale, scale, 1.0f);
            int tx = (int) ((x + SIZE / 2) / scale);
            int ty = (int) ((y + (ready ? 8 : 4)) / scale);
            ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(letter), tx, ty, ready ? 0xFFFFFFFF : 0xFFA0A0A8);
            ctx.getMatrices().pop();

            // секунды до готовности
            if (!ready) {
                ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(String.valueOf((s.left + 19) / 20)),
                        x + SIZE / 2, y + SIZE - 10, 0xFFFFD060);
            }
        }
    }
}

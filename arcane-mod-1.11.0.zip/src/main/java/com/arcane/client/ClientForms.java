package com.arcane.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Какая форма сейчас включена у каких игроков (0 - нет, 1 - Саир, 2 - Эйро, 3 - Шут, 4 - Меха). */
public final class ClientForms {
    private static final int MECHA_FORM_TICKS = 40 * 20;

    private static final Map<UUID, Integer> FORMS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> STARTED = new ConcurrentHashMap<>();
    private static int ticks = 0;

    private ClientForms() {}

    public static void tick() { ticks++; }

    public static int get(UUID id) { return FORMS.getOrDefault(id, 0); }

    public static void set(UUID id, int form) {
        int old = FORMS.getOrDefault(id, 0);
        if (form == 0) {
            FORMS.remove(id);
            STARTED.remove(id);
        } else {
            if (old != form) STARTED.put(id, ticks);
            FORMS.put(id, form);
        }
    }

    /** 0..1: насколько давно включена форма Меха (от этого растут золотые трещины). */
    public static float mechaProgress(UUID id, float tickDelta) {
        Integer s = STARTED.get(id);
        if (s == null) return 0.0f;
        float p = (ticks + tickDelta - s) / (float) MECHA_FORM_TICKS;
        return Math.max(0.0f, Math.min(1.0f, p));
    }

    public static void clear() {
        FORMS.clear();
        STARTED.clear();
    }
}

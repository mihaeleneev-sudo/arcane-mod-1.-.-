package com.arcane.client;

import com.arcane.LilithEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Лилит рисуется как высокая женская фигура со своим скином. */
public class LilithRenderer extends BipedEntityRenderer<LilithEntity, PlayerEntityModel<LilithEntity>> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/lilith.png");

    public LilithRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.6f);
    }

    @Override
    public Identifier getTexture(LilithEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(LilithEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.15f, 1.15f, 1.15f);
    }
}

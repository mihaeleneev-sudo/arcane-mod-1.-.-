package com.arcane.client;

import com.arcane.Card;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Карты Шута в правом верхнем углу экрана. */
public final class CardHud {
    private static final Identifier ATLAS = new Identifier("arcane", "textures/gui/cards.png");
    private static final int CW = 28;
    private static final int CH = 42;
    private static final int GAP = 4;

    private static final class Shown {
        final int card;
        int ticksLeft;
        int age;

        Shown(int card, int ticksLeft) {
            this.card = card;
            this.ticksLeft = ticksLeft;
        }
    }

    private static final List<Shown> HAND = new ArrayList<>();

    private CardHud() {}

    public static void setHand(boolean fresh, int[] ids, int[] ticks) {
        HAND.clear();
        for (int i = 0; i < ids.length; i++) {
            Shown s = new Shown(ids[i], ticks[i]);
            s.age = (fresh && i == ids.length - 1) ? 0 : 99; // новая карта «падает» сверху
            HAND.add(s);
        }
    }

    public static void clear() { HAND.clear(); }

    public static void tick() {
        Iterator<Shown> it = HAND.iterator();
        while (it.hasNext()) {
            Shown s = it.next();
            s.age++;
            if (--s.ticksLeft <= 0) it.remove();
        }
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (HAND.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        int n = HAND.size();

        for (int i = 0; i < n; i++) {
            Shown s = HAND.get(i);
            Card c = Card.byId(s.card);
            int x = w - 8 - (n - i) * (CW + GAP) + GAP;
            int y = 8;
            if (s.age < 12) y -= (12 - s.age) * 2;
            float alpha = s.ticksLeft < 20 ? s.ticksLeft / 20.0f : 1.0f;

            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
            ctx.drawTexture(ATLAS, x, y, s.card * CW, 0, CW, CH, CW * 8, CH);
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
            RenderSystem.disableBlend();

            int a = (int) (alpha * 255);
            if (a >= 10) {
                int rgb = c.luck ? 0xFFF2A0 : 0xD7B8FF;
                ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(c.label()),
                        x + CW / 2, y + 25, (a << 24) | rgb);
            }
        }
    }
}

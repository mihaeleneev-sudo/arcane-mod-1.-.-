package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Шкала железа и таймер формы Меха (слева внизу экрана). */
public final class MechaHud {
    private static final int BAR_W = 100;

    private static int metal = -1;      // -1: у игрока нет силы Меха
    private static int formTicks = -1;  // -1: форма не включена

    private MechaHud() {}

    public static void set(int m, int f) {
        metal = m;
        formTicks = f;
    }

    public static void clear() {
        metal = -1;
        formTicks = -1;
    }

    public static void tick() {
        if (formTicks > 0) formTicks--;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (metal < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 10;
        int y = mc.getWindow().getScaledHeight() - 58;

        // шкала железа
        ctx.drawTextWithShadow(mc.textRenderer,
                Text.translatable("hud.arcane.iron").append(Text.literal(" " + metal + "/100")), x, y - 11, 0xFFE0E6F0);
        ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
        int fill = BAR_W * Math.max(0, Math.min(100, metal)) / 100;
        ctx.fill(x, y, x + fill, y + 8, 0xFF9AA4B4);
        ctx.fill(x, y, x + fill, y + 2, 0xFFE8EEF8);

        // таймер формы
        if (formTicks >= 0) {
            int ty = y + 20;
            int seconds = (formTicks + 19) / 20;
            ctx.drawTextWithShadow(mc.textRenderer,
                    Text.translatable("hud.arcane.time").append(Text.literal(" " + seconds + "с")), x, ty - 11,
                    seconds <= 10 ? 0xFFFF8060 : 0xFFFFD060);
            ctx.fill(x - 1, ty - 1, x + BAR_W + 1, ty + 5, 0xCC000000);
            int tf = BAR_W * Math.min(formTicks, 800) / 800;
            ctx.fill(x, ty, x + tf, ty + 4, seconds <= 10 ? 0xFFE0502C : 0xFFFFC840);
        }
    }
}

package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Шкала ярости Эйро с душой Лилит (слева внизу экрана). */
public final class RageHud {
    private static final int BAR_W = 100;
    private static int rage = -1;   // -1: когтей нет

    private RageHud() {}

    public static void set(int r) { rage = r; }

    public static void clear() { rage = -1; }

    public static void render(DrawContext ctx, float tickDelta) {
        if (rage < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 10;
        int y = mc.getWindow().getScaledHeight() - 58;

        ctx.drawTextWithShadow(mc.textRenderer,
                Text.translatable("hud.arcane.rage").append(Text.literal(" " + rage + "/100")), x, y - 11, 0xFFFF8080);
        ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
        int fill = BAR_W * Math.max(0, Math.min(100, rage)) / 100;
        ctx.fill(x, y, x + fill, y + 8, 0xFFC02020);
        ctx.fill(x, y, x + fill, y + 2, 0xFFFF6A5A);
    }
}

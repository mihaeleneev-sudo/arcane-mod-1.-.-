package com.arcane;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public final class ModItems {
    public static final Item ARCANE_SHARD = register("arcane_shard",
            new CharacterItem(new FabricItemSettings().maxCount(16).rarity(Rarity.RARE), Form.SAIR, true));
    public static final Item ARCANE_CRYSTAL = register("arcane_crystal",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof(), Form.SAIR, false));
    public static final Item EIRO_HEART = register("eiro_heart",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof(), Form.EIRO, true));
    public static final Item FOOL_CARD = register("fool_card",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof(), Form.JESTER, true));
    public static final Item MECHA_NOON = register("mecha_noon",
            new MechaNoonItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof()));
    public static final Item ARMOR_SHARD = register("armor_shard",
            new ArmorShardItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof()));
    public static final Item SAKE = register("sake",
            new SakeItem(new FabricItemSettings().maxCount(16).food(new FoodComponent.Builder()
                    .hunger(2).saturationModifier(0.3f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 0), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200, 0), 1.0f)
                    .build())));
    public static final Item ZET_ESSENCE = register("zet_essence",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof(), Form.ZET, true));
    public static final Item LILITH_SOUL = register("lilith_soul",
            new LilithSoulItem(new FabricItemSettings().maxCount(1).rarity(Rarity.EPIC).fireproof()));
    public static final Item HUNTER_LICENSE = register("hunter_license",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE), Form.HUNTER, true));
    public static final Item FORGED_DOCUMENTS = register("forged_documents",
            new ForgedDocumentsItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE)));
    public static final Item HUNTER_SHOTGUN = register("hunter_shotgun",
            new ShotgunItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE).fireproof()));
    public static final Item BOUNTY_POSTER = register("bounty_poster",
            new BountyPosterItem(new FabricItemSettings().maxCount(1), false));
    public static final Item BOUNTY_POSTER_DONE = register("bounty_poster_done",
            new BountyPosterItem(new FabricItemSettings().maxCount(16), true));
    public static final Item KING_CROWN = register("king_crown",
            new CharacterItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE), Form.KING, true));
    public static final Item WISH_SHARD = register("wish_shard",
            new WishShardItem(new FabricItemSettings().maxCount(16).rarity(Rarity.EPIC)));
    public static final Item ZEUS_VEST = register("zeus_vest",
            new ArmorItem(ZeusArmorMaterial.INSTANCE, ArmorItem.Type.CHESTPLATE,
                    new FabricItemSettings().rarity(Rarity.RARE)));
    public static final Item SAIR_KATANA = register("sair_katana", new KatanaItem());

    private ModItems() {}

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(ArcaneMod.MOD_ID, name), item);
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(e -> {
            e.add(ARCANE_SHARD);
            e.add(ARCANE_CRYSTAL);
            e.add(EIRO_HEART);
            e.add(FOOL_CARD);
            e.add(MECHA_NOON);
            e.add(ARMOR_SHARD);
            e.add(SAKE);
            e.add(ZET_ESSENCE);
            e.add(LILITH_SOUL);
            e.add(HUNTER_LICENSE);
            e.add(KING_CROWN);
            e.add(WISH_SHARD);
            e.add(FORGED_DOCUMENTS);
            e.add(BOUNTY_POSTER);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            e.add(SAIR_KATANA);
            e.add(HUNTER_SHOTGUN);
            e.add(ZEUS_VEST);
        });
    }
}

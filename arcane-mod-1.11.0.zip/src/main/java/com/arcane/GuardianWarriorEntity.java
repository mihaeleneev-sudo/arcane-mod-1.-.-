package com.arcane;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.ZombieAttackGoal;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

import java.util.UUID;

/** Защитник Короля: воин с мечом. Не нападает на хозяина и игроков, бьёт только по приказу. */
public class GuardianWarriorEntity extends ZombieEntity implements KingGuardian {
    private UUID owner;

    public GuardianWarriorEntity(EntityType<? extends ZombieEntity> type, World world) {
        super(type, world);
    }

    @Override
    public UUID getOwnerId() { return owner; }

    @Override
    public void setOwnerId(UUID id) { this.owner = id; }

    /** Свои цели: только месть тому, кто ударил, и приказы Короля. */
    protected void initCustomGoals() {
        this.goalSelector.add(2, new ZombieAttackGoal(this, 1.0, false));
        this.goalSelector.add(5, new FollowOwnerGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
    }

    /** Не горит на солнце и не превращается в утопленника. */
    public boolean burnsInDaylight() { return false; }

    public boolean canConvertInWater() { return false; }

    /** Если хозяин не в сети, защитник исчезает. */
    @Override
    protected void mobTick() {
        super.mobTick();
        if (this.age % 200 == 0) {
            MinecraftServer server = this.getServer();
            if (owner == null || server == null || server.getPlayerManager().getPlayer(owner) == null) this.discard();
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (owner != null) nbt.putUuid("KingOwner", owner);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("KingOwner")) owner = nbt.getUuid("KingOwner");
    }
}

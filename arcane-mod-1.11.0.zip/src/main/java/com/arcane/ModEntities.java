package com.arcane;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final EntityType<DuelistEntity> DUELIST = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "duelist"),
            EntityType.Builder.create(DuelistEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.8f)
                    .build("duelist"));

    public static final EntityType<LilithEntity> LILITH = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "lilith"),
            EntityType.Builder.create(LilithEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.7f, 2.1f)
                    .build("lilith"));

    public static final EntityType<OutlawEntity> OUTLAW = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "outlaw"),
            EntityType.Builder.create(OutlawEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.8f)
                    .build("outlaw"));

    public static final EntityType<GuardianWarriorEntity> GUARDIAN_WARRIOR = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "guardian_warrior"),
            EntityType.Builder.create(GuardianWarriorEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.95f)
                    .build("guardian_warrior"));

    public static final EntityType<GuardianArcherEntity> GUARDIAN_ARCHER = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "guardian_archer"),
            EntityType.Builder.create(GuardianArcherEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.99f)
                    .build("guardian_archer"));

    private ModEntities() {}

    public static void init() {
        FabricDefaultAttributeRegistry.register(DUELIST, DuelistEntity.createDuelistAttributes());
        FabricDefaultAttributeRegistry.register(LILITH, LilithEntity.createLilithAttributes());
        FabricDefaultAttributeRegistry.register(OUTLAW, OutlawEntity.createOutlawAttributes());
        FabricDefaultAttributeRegistry.register(GUARDIAN_WARRIOR, ZombieEntity.createZombieAttributes());
        FabricDefaultAttributeRegistry.register(GUARDIAN_ARCHER, AbstractSkeletonEntity.createAbstractSkeletonAttributes());
    }
}

package com.arcane;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Кастомизация персонажей: аксессуары (маска и т.п.), которые надеваются на конкретного персонажа.
 * Что получено и что надето хранится в командных тегах игрока (как и остальное в моде),
 * поэтому сохраняется вместе с миром и после смерти.
 */
public final class Cosmetics {
    private static final String OWN_PREFIX = "arcane_cos_own_";
    private static final String ON_PREFIX = "arcane_cos_on_";

    /** Слоты аксессуаров. Новые слоты (голова, спина...) добавляются сюда. */
    public enum Slot {
        FACE("face");

        public final String key;

        Slot(String key) { this.key = key; }

        public String langKey() { return "cosmetic.arcane.slot." + key; }

        public static Slot fromKey(String key) {
            for (Slot s : values()) if (s.key.equals(key)) return s;
            return null;
        }
    }

    /** Описание одного аксессуара. */
    public static final class Def {
        public final String id;
        public final Slot slot;
        public final Form form;
        /** Ключ перевода короткой подсказки, как получить аксессуар (показывается в меню, пока он закрыт). Может быть null. */
        public final String hintKey;
        private final Supplier<Item> item;

        Def(String id, Slot slot, Form form, Supplier<Item> item, String hintKey) {
            this.id = id;
            this.slot = slot;
            this.form = form;
            this.item = item;
            this.hintKey = hintKey;
        }

        public Item item() { return item.get(); }
    }

    /** Все аксессуары мода. Чтобы добавить новый - допиши сюда строку, предмет и модель. */
    public static final List<Def> ALL = List.of(
            new Def("oni_mask", Slot.FACE, Form.EIRO, () -> ModItems.ONI_MASK, "cosmetic.arcane.quest.oni_mask")
    );

    private static final Map<UUID, String> LAST_FACE = new HashMap<>();

    private Cosmetics() {}

    public static Def byId(String id) {
        for (Def d : ALL) if (d.id.equals(id)) return d;
        return null;
    }

    private static String ownTag(Def d) { return OWN_PREFIX + d.id; }

    private static String onTag(Def d) { return ON_PREFIX + d.slot.key + "_" + d.id; }

    // ---------- состояние ----------

    public static boolean owns(PlayerEntity p, Def d) { return p.getCommandTags().contains(ownTag(d)); }

    public static boolean worn(PlayerEntity p, Def d) { return p.getCommandTags().contains(onTag(d)); }

    /** Что реально видно на игроке в слоте "Лицо": надето и подходит текущему персонажу. Пустая строка - ничего. */
    public static String face(PlayerEntity p) {
        Form character = Forms.character(p);
        for (Def d : ALL) {
            if (d.slot == Slot.FACE && d.form == character && worn(p, d)) return d.id;
        }
        return "";
    }

    public static void unlock(ServerPlayerEntity p, Def d) {
        p.addCommandTag(ownTag(d));
        p.sendMessage(Text.translatable("message.arcane.cosmetic_unlocked", new net.minecraft.item.ItemStack(d.item()).getName()), true);
        sendState(p);
    }

    public static void equip(ServerPlayerEntity p, Def d) {
        if (!owns(p, d)) {
            p.sendMessage(Text.translatable("message.arcane.cosmetic_not_owned"), true);
            sendState(p);
            return;
        }
        clearSlot(p, d.slot, d.form);
        p.addCommandTag(onTag(d));
        refresh(p);
    }

    /** Снять аксессуар в слоте у конкретного персонажа (у других персонажей надетое остаётся). */
    public static void unequip(ServerPlayerEntity p, Slot slot, Form form) {
        clearSlot(p, slot, form);
        refresh(p);
    }

    private static void clearSlot(ServerPlayerEntity p, Slot slot, Form form) {
        for (Def d : ALL) if (d.slot == slot && d.form == form) p.removeScoreboardTag(onTag(d));
    }

    /** Для проверки: /arcane cosmetic unlock_all и /arcane cosmetic reset. */
    private static void unlockAll(ServerPlayerEntity p) {
        for (Def d : ALL) p.addCommandTag(ownTag(d));
        sendState(p);
    }

    private static void reset(ServerPlayerEntity p) {
        for (Def d : ALL) {
            p.removeScoreboardTag(ownTag(d));
            p.removeScoreboardTag(onTag(d));
        }
        refresh(p);
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        for (String tag : new ArrayList<>(oldP.getCommandTags())) {
            if (tag.startsWith(OWN_PREFIX) || tag.startsWith(ON_PREFIX)) newP.addCommandTag(tag);
        }
    }

    // ---------- сеть ----------

    public static void sendState(ServerPlayerEntity p) {
        List<String> owned = new ArrayList<>();
        List<String> worn = new ArrayList<>();
        for (Def d : ALL) {
            if (owns(p, d)) owned.add(d.id);
            if (worn(p, d)) worn.add(d.id);
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(Forms.character(p).key);
        buf.writeInt(owned.size());
        for (String s : owned) buf.writeString(s);
        buf.writeInt(worn.size());
        for (String s : worn) buf.writeString(s);
        ServerPlayNetworking.send(p, Packets.COSMETIC_STATE, buf);
    }

    private static void sendFace(ServerPlayerEntity to, UUID who, String face) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(who);
        buf.writeString(face);
        ServerPlayNetworking.send(to, Packets.COSMETIC_SYNC, buf);
    }

    public static void broadcastFace(MinecraftServer server, ServerPlayerEntity p) {
        String face = face(p);
        LAST_FACE.put(p.getUuid(), face);
        for (ServerPlayerEntity to : server.getPlayerManager().getPlayerList()) {
            sendFace(to, p.getUuid(), face);
        }
    }

    public static void syncAllTo(MinecraftServer server, ServerPlayerEntity joiner) {
        for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
            sendFace(joiner, o.getUuid(), face(o));
        }
    }

    private static void refresh(ServerPlayerEntity p) {
        sendState(p);
        broadcastFace(p.getServer(), p);
    }

    private static void handle(ServerPlayerEntity p, int action, String arg) {
        switch (action) {
            case 0 -> sendState(p);
            case 1 -> {
                Def d = byId(arg);
                if (d != null) equip(p, d);
            }
            case 2 -> {
                Def d = byId(arg);   // снять: передаётся id надетого аксессуара
                if (d != null) unequip(p, d.slot, d.form);
            }
            case 3 -> CraftCatalog.craft(p, arg);
            default -> { }
        }
    }

    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(Packets.COSMETIC_ACTION, (server, player, handler, buf, sender) -> {
            int action = buf.readInt();
            String arg = buf.readString(128);
            server.execute(() -> handle(player, action, arg));
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            syncAllTo(server, handler.player);
            broadcastFace(server, handler.player);
            sendState(handler.player);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LAST_FACE.remove(handler.player.getUuid()));

        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> copy(oldPlayer, newPlayer));
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            broadcastFace(newPlayer.getServer(), newPlayer);
            sendState(newPlayer);
        });

        // Сменился персонаж (или тег) - раз в полсекунды сверяем, что видят остальные
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 10 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                String now = face(p);
                if (!now.equals(LAST_FACE.getOrDefault(p.getUuid(), ""))) {
                    broadcastFace(server, p);
                    sendState(p);
                }
            }
        });

        // /arcane cosmetic unlock_all - открыть все аксессуары (проверка), /arcane cosmetic reset - забрать все
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("arcane")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("cosmetic")
                                .then(CommandManager.literal("unlock_all").executes(ctx -> {
                                    unlockAll(ctx.getSource().getPlayerOrThrow());
                                    return 1;
                                }))
                                .then(CommandManager.literal("reset").executes(ctx -> {
                                    reset(ctx.getSource().getPlayerOrThrow());
                                    return 1;
                                })))));
    }
}

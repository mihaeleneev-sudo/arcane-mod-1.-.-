package com.arcane;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.CampfireBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/**
 * Квест "Сожги икону": снять икону со стены древнего храма (Shift + ПКМ пустой рукой по иконе),
 * вынести её и сжечь (бросить в огонь, лаву или на зажжённый костёр). Награда - Маска Они в меню кастомизации.
 * Отдельных данных не хранится: выполнен ли квест, видно по тому, есть ли маска в гардеробе (Cosmetics).
 */
public final class IconQuest {
    public static final String MASK_ID = "oni_mask";

    private IconQuest() {}

    private static boolean questDone(PlayerEntity p) {
        Cosmetics.Def mask = Cosmetics.byId(MASK_ID);
        return mask != null && Cosmetics.owns(p, mask);
    }

    private static boolean hasIcon(PlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.OLD_ICON)) return true;
        }
        return false;
    }

    /** Игрок присел и нажал ПКМ по иконе в храме пустой рукой. Сама икона на стене остаётся (она нужна для молитв). */
    public static void take(ServerPlayerEntity p) {
        if (questDone(p)) {
            p.sendMessage(Text.translatable("message.arcane.icon_quest_done"), true);
            return;
        }
        if (hasIcon(p)) {
            p.sendMessage(Text.translatable("message.arcane.icon_have"), true);
            return;
        }
        p.getInventory().offerOrDrop(new ItemStack(ModItems.OLD_ICON));
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ITEM_BOOK_PAGE_TURN, SoundCategory.PLAYERS, 1.0f, 0.6f);
        p.sendMessage(Text.translatable("message.arcane.icon_taken"), false);
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(IconQuest::tick);
    }

    private static boolean isBurning(ServerWorld w, ItemEntity e) {
        if (e.isInLava()) return true;
        BlockPos pos = e.getBlockPos();
        for (BlockPos q : new BlockPos[]{pos, pos.down()}) {
            BlockState s = w.getBlockState(q);
            if (s.isIn(BlockTags.FIRE)) return true;
            if (s.getBlock() instanceof CampfireBlock && s.get(CampfireBlock.LIT)) return true;
        }
        return false;
    }

    private static void tick(MinecraftServer server) {
        if (server.getTicks() % 4 != 0) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerWorld w = p.getServerWorld();
            List<ItemEntity> items = w.getEntitiesByClass(ItemEntity.class, p.getBoundingBox().expand(24.0),
                    e -> !e.isRemoved() && e.getStack().isOf(ModItems.OLD_ICON) && isBurning(w, e));
            for (ItemEntity e : items) burn(w, e);
        }
    }

    /** Икона сгорает; ближайший игрок (в радиусе 24 блоков) получает маску. */
    private static void burn(ServerWorld w, ItemEntity e) {
        double x = e.getX();
        double y = e.getY();
        double z = e.getZ();
        e.discard();
        w.spawnParticles(ParticleTypes.FLAME, x, y + 0.3, z, 40, 0.3, 0.4, 0.3, 0.05);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.5, z, 15, 0.3, 0.4, 0.3, 0.03);
        w.playSound(null, x, y, z, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 1.0f, 0.7f);
        w.playSound(null, x, y, z, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 0.8f, 0.6f);

        PlayerEntity near = w.getClosestPlayer(x, y, z, 24.0, false);
        if (!(near instanceof ServerPlayerEntity sp)) return;
        Cosmetics.Def mask = Cosmetics.byId(MASK_ID);
        if (mask == null || Cosmetics.owns(sp, mask)) {
            sp.sendMessage(Text.translatable("message.arcane.icon_burned_nothing"), false);
            return;
        }
        Cosmetics.unlock(sp, mask);
        sp.sendMessage(Text.translatable("message.arcane.icon_burned"), false);
        w.playSound(null, sp.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }
}

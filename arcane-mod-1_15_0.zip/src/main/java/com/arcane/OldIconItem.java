package com.arcane;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Икона, снятая со стены храма. Огнеупорная: сгорает только когда её сжигают сами (см. IconQuest). */
public class OldIconItem extends Item {
    public OldIconItem(Settings settings) {
        super(settings);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("tooltip.arcane.old_icon").formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.arcane.old_icon.reward").formatted(Formatting.GOLD));
    }
}

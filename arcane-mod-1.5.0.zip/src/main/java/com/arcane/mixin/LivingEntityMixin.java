package com.arcane.mixin;

import com.arcane.Form;
import com.arcane.Forms;
import com.arcane.SairUpgrade;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Любой урон, который наносит Шут в форме, меняется картой удачи или неудачи. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true, require = 0)
    private float arcane$jesterDamage(float amount, DamageSource source) {
        LivingEntity self = (LivingEntity) (Object) this;
        float result = amount;
        if (source.getAttacker() instanceof ServerPlayerEntity attacker
                && attacker != self && Forms.isActive(attacker, Form.JESTER)) {
            result = Forms.rollDamage(attacker, self, result);
        }
        if (self instanceof ServerPlayerEntity victim && source.getAttacker() != null) {
            result = SairUpgrade.absorbWithGuard(victim, result);
        }
        return result;
    }
}

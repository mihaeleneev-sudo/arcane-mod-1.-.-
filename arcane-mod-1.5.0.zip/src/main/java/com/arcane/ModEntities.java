package com.arcane;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final EntityType<DuelistEntity> DUELIST = Registry.register(Registries.ENTITY_TYPE,
            new Identifier(ArcaneMod.MOD_ID, "duelist"),
            EntityType.Builder.create(DuelistEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.8f)
                    .build("duelist"));

    private ModEntities() {}

    public static void init() {
        FabricDefaultAttributeRegistry.register(DUELIST, DuelistEntity.createDuelistAttributes());
    }
}

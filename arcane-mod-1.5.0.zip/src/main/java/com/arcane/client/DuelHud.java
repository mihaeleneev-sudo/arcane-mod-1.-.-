package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Слева вверху: число выигранных дуэлей и "блок на руках" (10 ячеек по 2 половинки). */
public final class DuelHud {
    private static int wins = -1;     // -1: улучшенного Саира нет
    private static int guard = 0;     // в половинках очка
    private static boolean inDuel = false;

    private DuelHud() {}

    public static void set(int w, int g, boolean duel) {
        wins = w;
        guard = g;
        inDuel = duel;
    }

    public static void clear() {
        wins = -1;
        guard = 0;
        inDuel = false;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (wins < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 10;
        int y = 10;

        ctx.drawTextWithShadow(mc.textRenderer,
                Text.translatable("hud.arcane.duels").append(Text.literal(": " + wins)), x, y, 0xFFFFE9A0);
        if (inDuel) {
            ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("hud.arcane.in_duel"), x + 70, y, 0xFFFF7060);
        }

        String shown = (guard / 2) + (guard % 2 == 1 ? ".5" : "");
        ctx.drawTextWithShadow(mc.textRenderer,
                Text.translatable("hud.arcane.guard").append(Text.literal(" " + shown)), x, y + 12,
                guard > 0 ? 0xFFD0E0F0 : 0xFFFF6060);

        // 10 ячеек: каждая вмещает 2 половинки
        int by = y + 24;
        for (int i = 0; i < 10; i++) {
            int halves = Math.max(0, Math.min(2, guard - 2 * i));
            int cx = x + i * 9;
            ctx.fill(cx - 1, by - 1, cx + 8, by + 7, 0xCC000000);
            ctx.fill(cx, by, cx + 7, by + 6, 0xFF3A2020);
            if (halves >= 1) ctx.fill(cx, by, cx + 3, by + 6, 0xFFB8C4D8);
            if (halves >= 2) ctx.fill(cx + 3, by, cx + 7, by + 6, 0xFFB8C4D8);
        }
        if (guard <= 0) {
            ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("hud.arcane.broken"), x, by + 10, 0xFFFF6060);
        }
    }
}

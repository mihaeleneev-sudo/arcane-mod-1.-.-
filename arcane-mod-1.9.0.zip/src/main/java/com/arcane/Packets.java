package com.arcane;

import net.minecraft.util.Identifier;

public final class Packets {
    /** клиент -> сервер: нажата клавиша превращения */
    public static final Identifier TOGGLE = new Identifier(ArcaneMod.MOD_ID, "toggle");
    /** сервер -> клиенты: UUID игрока + номер его активной формы */
    public static final Identifier SYNC = new Identifier(ArcaneMod.MOD_ID, "sync");
    /** сервер -> носитель Эйро: номер фразы-голоса */
    public static final Identifier VOICE = new Identifier(ArcaneMod.MOD_ID, "voice");

    /** клиент -> сервер: нажата клавиша способности (бросок блока Эйро) */
    public static final Identifier ABILITY = new Identifier(ArcaneMod.MOD_ID, "ability");

    /** сервер -> шут: карты в руке (показываются в углу экрана) */
    public static final Identifier CARDS = new Identifier(ArcaneMod.MOD_ID, "cards");

    /** клиент -> сервер: клавиша лучей Меха нажата (true) или отпущена (false) */
    public static final Identifier LASER = new Identifier(ArcaneMod.MOD_ID, "laser");
    /** сервер -> Меха: запас железа и оставшееся время формы */
    public static final Identifier MECHA = new Identifier(ArcaneMod.MOD_ID, "mecha");

    /** клиент -> сервер: клавиша "Разрез" нажата (true) или отпущена (false) */
    public static final Identifier SLASH = new Identifier(ArcaneMod.MOD_ID, "slash");
    /** клиент -> сервер: клавиша "Вызов" (дуэль) */
    public static final Identifier CHALLENGE = new Identifier(ArcaneMod.MOD_ID, "challenge");
    /** сервер -> Саир: число побед в дуэлях и блок на руках */
    public static final Identifier DUEL = new Identifier(ArcaneMod.MOD_ID, "duel");

    /** сервер -> Эйро с душой Лилит: шкала ярости (-1: нет) */
    public static final Identifier RAGE = new Identifier(ArcaneMod.MOD_ID, "rage");

    /** клиент -> сервер: умение Короля (0 рог, 1 атака, 2 возврат, 3 невидимость) */
    public static final Identifier KING = new Identifier(ArcaneMod.MOD_ID, "king");

    private Packets() {}
}

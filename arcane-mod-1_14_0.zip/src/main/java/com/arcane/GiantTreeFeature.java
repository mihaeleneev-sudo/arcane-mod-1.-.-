package com.arcane;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

/**
 * Огромное тёмное дерево в равнинах. Внутри ствола небольшая полость с сундуком, в сундуке "Забытая душа".
 * Ствол из коры тёмного дуба, крона из нескольких комков листвы (форма неровная и необычная).
 * Вход - проём с южной стороны у корней.
 */
public class GiantTreeFeature extends Feature<DefaultFeatureConfig> {
    public static final Identifier LOOT = new Identifier(ArcaneMod.MOD_ID, "chests/giant_tree");
    private static final int HEIGHT = 24;

    public GiantTreeFeature() {
        super(DefaultFeatureConfig.CODEC);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> context) {
        return place(context.getWorld(), context.getOrigin(), context.getRandom(), false);
    }

    /**
     * @param force true - команда оператора: не проверяем рельеф и ставим дерево на поверхность в этой точке
     */
    public static boolean place(StructureWorldAccess world, BlockPos origin, Random random, boolean force) {
        int x0 = origin.getX();
        int z0 = origin.getZ();
        int y0;
        if (force) {
            y0 = world.getTopY(Heightmap.Type.WORLD_SURFACE, x0, z0);
        } else {
            y0 = origin.getY();
            BlockState below = world.getBlockState(new BlockPos(x0, y0 - 1, z0));
            if (!below.isOf(Blocks.GRASS_BLOCK) && !below.isOf(Blocks.DIRT)) return false;
            int[][] probes = {{5, 0}, {-5, 0}, {0, 5}, {0, -5}, {4, 4}, {-4, 4}, {4, -4}, {-4, -4}};
            for (int[] d : probes) {
                int ty = world.getTopY(Heightmap.Type.WORLD_SURFACE_WG, x0 + d[0], z0 + d[1]);
                if (Math.abs(ty - y0) > 2) return false;
                BlockState b = world.getBlockState(new BlockPos(x0 + d[0], ty - 1, z0 + d[1]));
                if (!b.getFluidState().isEmpty()) return false;
            }
        }
        if (y0 + HEIGHT + 10 >= world.getTopY()) return false;

        BlockState wood = Blocks.DARK_OAK_WOOD.getDefaultState();
        BlockState leaves = Blocks.DARK_OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true);
        BlockState dirt = Blocks.DIRT.getDefaultState();
        BlockState air = Blocks.AIR.getDefaultState();

        // 1) ствол: у земли расширяется корнями, выше сужается
        for (int dy = -4; dy <= HEIGHT; dy++) {
            double r = dy < 3 ? 4.3 : (dy < 8 ? 3.6 : (dy > HEIGHT - 5 ? 2.6 : 3.2));
            for (int dx = -5; dx <= 5; dx++) {
                for (int dz = -5; dz <= 5; dz++) {
                    if (dx * dx + dz * dz > r * r) continue;
                    BlockPos pos = new BlockPos(x0 + dx, y0 + dy, z0 + dz);
                    if (dy < 0) {
                        if (canReplace(world, pos)) world.setBlockState(pos, dirt, Block.NOTIFY_ALL);
                    } else {
                        world.setBlockState(pos, wood, Block.NOTIFY_ALL);
                    }
                }
            }
        }

        // 2) ветви к комкам листвы
        int cy = y0 + HEIGHT;
        int[][] blobs = {{6, -1, 2}, {-5, 0, 4}, {2, 1, -6}, {-4, -2, -5}, {7, 2, -4}, {0, 5, 0}};
        for (int i = 0; i < 4; i++) {
            int[] s = blobs[i];
            int sx = Integer.signum(s[0]);
            int sz = Integer.signum(s[2]);
            placeLine(world, new BlockPos(x0 + sx * 2, cy - 7 + i, z0 + sz * 2),
                    new BlockPos(x0 + s[0], cy + s[1], z0 + s[2]), wood);
        }

        // 3) крона: большой плоский комок и несколько маленьких вокруг
        blob(world, random, x0, cy + 1, z0, 8.5, 5.0, leaves);
        for (int[] s : blobs) blob(world, random, x0 + s[0], cy + s[1], z0 + s[2], 4.5, 3.5, leaves);

        // 4) полость внутри ствола (3x3, высота 3) и вход с юга
        for (int dy = 0; dy < 3; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    world.setBlockState(new BlockPos(x0 + dx, y0 + dy, z0 + dz), air, Block.NOTIFY_ALL);
                }
            }
        }
        for (int dy = 0; dy < 2; dy++) {
            for (int dz = 2; dz <= 5; dz++) {
                world.setBlockState(new BlockPos(x0, y0 + dy, z0 + dz), air, Block.NOTIFY_ALL);
            }
        }

        // 5) сундук с душой и фонарь, чтобы внутри не спавнились мобы
        BlockPos chest = new BlockPos(x0, y0, z0 - 1);
        world.setBlockState(chest, Blocks.CHEST.getDefaultState().with(ChestBlock.FACING, Direction.SOUTH), Block.NOTIFY_ALL);
        LootableContainerBlockEntity.setLootTable(world, random, chest, LOOT);
        world.setBlockState(new BlockPos(x0 - 1, y0, z0 + 1), Blocks.SOUL_LANTERN.getDefaultState(), Block.NOTIFY_ALL);
        return true;
    }

    private static boolean canReplace(StructureWorldAccess world, BlockPos pos) {
        BlockState s = world.getBlockState(pos);
        return s.isAir() || (s.getFluidState().isEmpty() && s.getCollisionShape(world, pos).isEmpty());
    }

    private static boolean canReplaceOrLeaves(StructureWorldAccess world, BlockPos pos) {
        return canReplace(world, pos) || world.getBlockState(pos).isIn(BlockTags.LEAVES);
    }

    private static void placeLine(StructureWorldAccess world, BlockPos a, BlockPos b, BlockState state) {
        int steps = Math.max(Math.abs(b.getX() - a.getX()), Math.max(Math.abs(b.getY() - a.getY()), Math.abs(b.getZ() - a.getZ())));
        for (int i = 0; i <= steps; i++) {
            double t = steps == 0 ? 0.0 : i / (double) steps;
            BlockPos pos = new BlockPos(
                    (int) Math.round(a.getX() + (b.getX() - a.getX()) * t),
                    (int) Math.round(a.getY() + (b.getY() - a.getY()) * t),
                    (int) Math.round(a.getZ() + (b.getZ() - a.getZ()) * t));
            if (canReplaceOrLeaves(world, pos)) world.setBlockState(pos, state, Block.NOTIFY_ALL);
        }
    }

    private static void blob(StructureWorldAccess world, Random random, int cx, int cy, int cz,
                             double radius, double heightRadius, BlockState leaves) {
        int rx = (int) Math.ceil(radius);
        int ry = (int) Math.ceil(heightRadius);
        for (int dx = -rx; dx <= rx; dx++) {
            for (int dy = -ry; dy <= ry; dy++) {
                for (int dz = -rx; dz <= rx; dz++) {
                    double d = (dx * dx) / (radius * radius) + (dy * dy) / (heightRadius * heightRadius)
                            + (dz * dz) / (radius * radius);
                    if (d > 1.0) continue;
                    if (d > 0.75 && random.nextInt(4) == 0) continue;   // рваный край
                    BlockPos pos = new BlockPos(cx + dx, cy + dy, cz + dz);
                    if (canReplace(world, pos)) world.setBlockState(pos, leaves, Block.NOTIFY_ALL);
                }
            }
        }
    }
}

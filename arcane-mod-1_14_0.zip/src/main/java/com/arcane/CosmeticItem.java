package com.arcane;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/**
 * Предмет-аксессуар (например, маска). ПКМ - предмет исчезает и навсегда добавляется в гардероб персонажа.
 * Надеть его можно в меню кастомизации (клавиша B, вкладка "Кастомизация").
 */
public class CosmeticItem extends Item {
    private final String cosmeticId;

    public CosmeticItem(Settings settings, String cosmeticId) {
        super(settings);
        this.cosmeticId = cosmeticId;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) return TypedActionResult.success(stack);

        Cosmetics.Def def = Cosmetics.byId(cosmeticId);
        if (def != null && user instanceof ServerPlayerEntity sp) {
            if (Cosmetics.owns(sp, def)) {
                sp.sendMessage(Text.translatable("message.arcane.cosmetic_already_owned"), true);
                return TypedActionResult.fail(stack);
            }
            Cosmetics.unlock(sp, def);
            if (!sp.getAbilities().creativeMode) stack.decrement(1);
        }
        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        Cosmetics.Def def = Cosmetics.byId(cosmeticId);
        if (def == null) return;
        tooltip.add(Text.translatable("tooltip.arcane.cosmetic.slot", Text.translatable(def.slot.langKey()))
                .formatted(Formatting.GOLD));
        tooltip.add(Text.translatable("tooltip.arcane.cosmetic.character",
                Text.translatable("character.arcane." + def.form.key)).formatted(Formatting.GRAY));
        tooltip.add(Text.translatable("tooltip.arcane.cosmetic.use").formatted(Formatting.DARK_GRAY));
    }
}

package com.arcane;

import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

import java.util.List;

/** Забытая душа: лежит в сундуке внутри огромного дерева. Сама по себе ничего не делает. */
public class ForgottenSoulItem extends Item {
    public ForgottenSoulItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        tooltip.add(Text.translatable("tooltip.arcane.forgotten_soul").formatted(Formatting.GRAY, Formatting.ITALIC));
    }
}

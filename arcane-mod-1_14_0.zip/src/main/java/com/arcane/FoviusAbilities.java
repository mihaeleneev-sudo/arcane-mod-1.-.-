package com.arcane;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Фовиус (Аластор). Оружие: гроб за спиной и прямой меч с тупым концом.
 * Умение 1 (R) "Ужасы ценности": удар гробом сверху вниз, самого Фовиуса подбрасывает.
 * Умение 2 (G) "Проклятье": метка-глаз на цели, притягивает её и запрещает ломать и ставить блоки.
 * Умение 3 (V) "Удар младшего брата": бросок меча; повторное нажатие возвращает меч сквозь цель.
 */
public final class FoviusAbilities {
    private static final int SLAM_COOLDOWN = 7 * 20;
    private static final int CURSE_COOLDOWN = 14 * 20;
    private static final int SWORD_BUSY = 12 * 20;       // пока меч в полёте, умение недоступно
    private static final int SWORD_AFTER_RETURN = 5 * 20;
    private static final int CURSE_TICKS = 8 * 20;
    private static final double THROW_SPEED = 1.7;
    private static final double RETURN_SPEED = 2.0;
    private static final int MAX_FLY_TICKS = 28;
    private static final int STUCK_TICKS = 8 * 20;       // столько меч лежит на месте, потом вернётся сам

    /** Для квадратиков отката на клиенте. */
    public static final int SLAM_TOTAL = SLAM_COOLDOWN;
    public static final int CURSE_TOTAL = CURSE_COOLDOWN;
    public static final int SWORD_TOTAL = SWORD_BUSY;

    private static final DustParticleEffect GOLD = new DustParticleEffect(new Vector3f(1.0f, 0.85f, 0.35f), 1.0f);
    private static final DustParticleEffect WHITE = new DustParticleEffect(new Vector3f(1.0f, 1.0f, 1.0f), 0.9f);
    private static final DustParticleEffect RED = new DustParticleEffect(new Vector3f(0.9f, 0.1f, 0.15f), 1.0f);

    private static final class Curse {
        final UUID caster;
        final ServerWorld world;
        final int end;

        Curse(UUID caster, ServerWorld world, int end) {
            this.caster = caster;
            this.world = world;
            this.end = end;
        }
    }

    private static final class Flight {
        final ItemEntity entity;
        final ServerWorld world;
        final ItemStack stack;
        final Vec3d dir;
        final Set<UUID> hit = new HashSet<>();
        int age = 0;
        int stuck = -1;          // -1: летит вперёд, >= 0: лежит на месте (сколько тиков)
        boolean returning = false;
        double lastDist = Double.MAX_VALUE;
        int noProgress = 0;

        Flight(ItemEntity entity, ServerWorld world, ItemStack stack, Vec3d dir) {
            this.entity = entity;
            this.world = world;
            this.stack = stack;
            this.dir = dir;
        }
    }

    private static final Map<UUID, Integer> CD1 = new HashMap<>();
    private static final Map<UUID, Integer> CD2 = new HashMap<>();
    private static final Map<UUID, Integer> CD3 = new HashMap<>();
    private static final Map<UUID, Curse> CURSES = new HashMap<>();      // ключ - проклятая цель
    private static final Map<UUID, Flight> FLIGHTS = new HashMap<>();    // ключ - бросивший

    private FoviusAbilities() {}

    public static int cd1Left(UUID id, int now) { return Math.max(0, CD1.getOrDefault(id, 0) - now); }
    public static int cd2Left(UUID id, int now) { return Math.max(0, CD2.getOrDefault(id, 0) - now); }
    public static int cd3Left(UUID id, int now) { return Math.max(0, CD3.getOrDefault(id, 0) - now); }

    // ---------- запреты проклятья ----------

    public static boolean isCursed(Entity e) {
        Curse c = CURSES.get(e.getUuid());
        if (c == null) return false;
        MinecraftServer server = e.getServer();
        return server != null && c.end > server.getTicks();
    }

    public static void init() {
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (isCursed(player)) {
                warnCursed(world, player);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (isCursed(player) && player.getStackInHand(hand).getItem() instanceof BlockItem) {
                warnCursed(world, player);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (isCursed(player) && stack.getItem() instanceof BucketItem) {
                warnCursed(world, player);
                return TypedActionResult.fail(stack);
            }
            return TypedActionResult.pass(stack);
        });
    }

    private static void warnCursed(net.minecraft.world.World world, PlayerEntity player) {
        if (!world.isClient) player.sendMessage(Text.translatable("message.arcane.cursed"), true);
    }

    // ---------- состояние ----------

    public static void clear(ServerPlayerEntity p) {
        release(p);
        CD1.remove(p.getUuid());
        CD2.remove(p.getUuid());
        CD3.remove(p.getUuid());
    }

    public static void onDeactivate(ServerPlayerEntity p, Form was) {
        if (was == Form.FOVIUS) release(p);
    }

    /** Снимает проклятья, наложенные этим игроком, и убирает летящий меч. */
    private static void release(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        CURSES.values().removeIf(c -> c.caster.equals(id));
        Flight f = FLIGHTS.remove(id);
        if (f != null) f.entity.discard();
    }

    // ---------- вспомогательное ----------

    private static boolean cooldown(ServerPlayerEntity p, Map<UUID, Integer> map, int now) {
        int until = map.getOrDefault(p.getUuid(), 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return true;
        }
        return false;
    }

    private static void syncVelocity(Entity e) {
        e.velocityModified = true;
        if (e instanceof ServerPlayerEntity sp) {
            sp.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(sp));
        }
    }

    public static boolean hasSwordPublic(ServerPlayerEntity p) { return hasSword(p); }

    private static boolean hasSword(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.FOVIUS_SWORD)) return true;
        }
        return false;
    }

    /** Забирает один меч из инвентаря и возвращает его копию (пустой стек, если меча нет). */
    private static ItemStack takeSword(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ModItems.FOVIUS_SWORD)) {
                ItemStack copy = s.copy();
                copy.setCount(1);
                s.decrement(1);
                return copy;
            }
        }
        return ItemStack.EMPTY;
    }

    /** Ищет цель по взгляду; out[0] получает точку попадания (цель, блок или конец луча). */
    private static LivingEntity pick(ServerPlayerEntity p, double range, Vec3d[] out) {
        ServerWorld w = p.getServerWorld();
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f).normalize();
        Vec3d end = start.add(dir.multiply(range));
        BlockHitResult bh = w.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        double len = bh.getType() == HitResult.Type.MISS ? range : start.distanceTo(bh.getPos());
        Vec3d lineEnd = start.add(dir.multiply(len));

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(start, lineEnd).expand(1.0),
                ent -> ent != p && ent.isAlive() && !(ent instanceof ArmorStandEntity))) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(start, lineEnd);
            if (hit.isPresent()) {
                double d = start.distanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        out[0] = best != null ? best.getBoundingBox().getCenter() : lineEnd;
        return best;
    }

    private static void bonk(ServerWorld w, Vec3d at) {
        w.playSound(null, at.x, at.y, at.z, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 0.7f, 1.8f);
        w.playSound(null, at.x, at.y, at.z, SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1.2f, 0.6f);
    }

    // ---------- умение 1 (клавиша R): "Ужасы ценности" ----------

    public static void skill1(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        if (cooldown(p, CD1, now)) return;
        CD1.put(p.getUuid(), now + SLAM_COOLDOWN);

        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        flat = flat.lengthSquared() < 1.0E-4 ? new Vec3d(0.0, 0.0, 1.0) : flat.normalize();
        Vec3d center = p.getPos().add(flat.multiply(2.4));
        double r = 3.2;

        p.swingHand(Hand.MAIN_HAND, true);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class,
                new Box(center.x - r, center.y - 1.5, center.z - r, center.x + r, center.y + 3.0, center.z + r),
                ent -> ent != p && ent.isAlive() && !(ent instanceof ArmorStandEntity)
                        && Math.hypot(ent.getX() - center.x, ent.getZ() - center.z) <= 3.2)) {
            e.damage(p.getDamageSources().playerAttack(p), 16.0f);
            e.takeKnockback(0.7, -flat.x, -flat.z);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
            syncVelocity(e);
        }

        BlockPos floorPos = BlockPos.ofFloored(center.x, p.getY() - 0.5, center.z);
        w.spawnParticles(ParticleTypes.EXPLOSION, center.x, p.getY() + 0.3, center.z, 2, 0.6, 0.1, 0.6, 0.0);
        if (!w.getBlockState(floorPos).isAir()) {
            w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, w.getBlockState(floorPos)),
                    center.x, p.getY() + 0.3, center.z, 90, 1.6, 0.2, 1.6, 0.3);
        }
        w.spawnParticles(ParticleTypes.CLOUD, center.x, p.getY() + 0.2, center.z, 40, 1.8, 0.1, 1.8, 0.2);
        w.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0f, 0.6f);
        w.playSound(null, center.x, center.y, center.z, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 1.2f, 0.5f);
        w.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_IRON_GOLEM_DAMAGE, SoundCategory.PLAYERS, 1.4f, 0.5f);

        // отдача: самого Фовиуса подбрасывает вверх
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.62, v.z);
        syncVelocity(p);
    }

    // ---------- умение 2 (клавиша G): "Проклятье" ----------

    public static void skill2(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        if (cooldown(p, CD2, now)) return;

        Vec3d[] end = new Vec3d[1];
        LivingEntity target = pick(p, 28.0, end);
        if (target == null) {
            p.sendMessage(Text.translatable("message.arcane.no_target"), true);
            return;
        }
        CD2.put(id, now + CURSE_COOLDOWN);

        CURSES.values().removeIf(c -> c.caster.equals(id));   // одно проклятье на носителя
        CURSES.put(target.getUuid(), new Curse(id, p.getServerWorld(), now + CURSE_TICKS));

        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 0.4f, 1.8f);
        w.playSound(null, target.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0f, 0.6f);
        w.spawnParticles(ParticleTypes.END_ROD, target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ(),
                30, 0.4, 0.6, 0.4, 0.05);
        // из гроба вырывается свет сестры
        Vec3d back = p.getPos().add(0.0, 1.2, 0.0);
        w.spawnParticles(ParticleTypes.END_ROD, back.x, back.y, back.z, 20, 0.3, 0.5, 0.3, 0.08);
        if (target instanceof ServerPlayerEntity tp) {
            tp.sendMessage(Text.translatable("message.arcane.cursed"), true);
        }
    }

    /** Светящийся глаз над целью, повёрнутый к Фовиусу. */
    private static void drawEye(ServerWorld w, LivingEntity target, Vec3d from) {
        Vec3d c = target.getPos().add(0.0, target.getHeight() + 0.9, 0.0);
        Vec3d toCaster = from.subtract(c);
        Vec3d flat = new Vec3d(toCaster.x, 0.0, toCaster.z);
        Vec3d right = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1.0, 0.0, 0.0)
                : new Vec3d(-flat.z, 0.0, flat.x).normalize();
        for (int i = 0; i < 28; i++) {   // контур глаза
            double t = i * Math.PI * 2.0 / 28.0;
            double x = 0.8 * Math.cos(t);
            double y = 0.36 * Math.sin(t);
            Vec3d pt = c.add(right.multiply(x)).add(0.0, y, 0.0);
            w.spawnParticles(GOLD, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        for (int i = 0; i < 10; i++) {   // зрачок
            double t = i * Math.PI * 2.0 / 10.0;
            Vec3d pt = c.add(right.multiply(0.16 * Math.cos(t))).add(0.0, 0.16 * Math.sin(t), 0.0);
            w.spawnParticles(i % 2 == 0 ? RED : WHITE, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        w.spawnParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 1, 0.02, 0.02, 0.02, 0.0);
    }

    private static void tickCurses(MinecraftServer server, int t) {
        for (Map.Entry<UUID, Curse> en : new ArrayList<>(CURSES.entrySet())) {
            Curse c = en.getValue();
            Entity ent = c.world.getEntity(en.getKey());
            ServerPlayerEntity caster = server.getPlayerManager().getPlayer(c.caster);
            if (!(ent instanceof LivingEntity target) || !target.isAlive() || caster == null || !caster.isAlive()
                    || t >= c.end || caster.getServerWorld() != c.world) {
                CURSES.remove(en.getKey());
                if (ent instanceof LivingEntity le) le.removeStatusEffect(StatusEffects.GLOWING);
                continue;
            }
            if (t % 4 == 0) drawEye(c.world, target, caster.getPos());
            if (t % 10 == 0) {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 30, 0, false, false, false));
            }

            // притягивание к Фовиусу
            Vec3d to = caster.getPos().subtract(target.getPos());
            double flatLen = Math.hypot(to.x, to.z);
            if (flatLen > 2.5 && flatLen < 40.0) {
                Vec3d vel = target.getVelocity();
                target.setVelocity(to.x / flatLen * 0.3, vel.y, to.z / flatLen * 0.3);
                syncVelocity(target);
            }
        }
    }

    // ---------- умение 3 (клавиша V): "Удар младшего брата" ----------

    public static void skill3(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        int now = p.getServer().getTicks();
        Flight f = FLIGHTS.get(id);
        if (f != null) {
            if (!f.returning) startReturn(p, f);
            return;
        }
        if (cooldown(p, CD3, now)) return;

        ItemStack sword = takeSword(p);
        if (sword.isEmpty()) {
            p.sendMessage(Text.translatable("message.arcane.fovius_no_sword"), true);
            return;
        }

        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f).normalize();
        Vec3d start = p.getEyePos().add(look.multiply(1.2)).add(0.0, -0.3, 0.0);
        ItemEntity e = new ItemEntity(w, start.x, start.y, start.z, sword.copy());
        e.setNoGravity(true);
        e.setPickupDelay(32767);   // подобрать нельзя
        e.setInvulnerable(true);
        e.setNeverDespawn();
        e.setVelocity(look.multiply(THROW_SPEED));
        e.velocityModified = true;
        w.spawnEntity(e);

        FLIGHTS.put(id, new Flight(e, w, sword, look));
        CD3.put(id, now + SWORD_BUSY);
        p.swingHand(Hand.MAIN_HAND, true);
        w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_TRIDENT_THROW, SoundCategory.PLAYERS, 1.0f, 0.6f);
    }

    private static void startReturn(ServerPlayerEntity p, Flight f) {
        f.returning = true;
        f.hit.clear();
        f.lastDist = Double.MAX_VALUE;
        f.noProgress = 0;
        f.world.playSound(null, p.getBlockPos(), SoundEvents.ITEM_TRIDENT_RETURN, SoundCategory.PLAYERS, 1.0f, 0.7f);
    }

    private static void finishFlight(ServerPlayerEntity p, Flight f, int now) {
        f.entity.discard();
        FLIGHTS.remove(p.getUuid());
        p.getInventory().offerOrDrop(f.stack.copy());
        CD3.put(p.getUuid(), now + SWORD_AFTER_RETURN);
        f.world.playSound(null, p.getBlockPos(), SoundEvents.ITEM_ARMOR_EQUIP_IRON, SoundCategory.PLAYERS, 1.0f, 0.8f);
    }

    private static void swordHit(ServerPlayerEntity p, Flight f, LivingEntity victim, Vec3d dir, boolean outbound) {
        DamageSource src = p.getDamageSources().playerAttack(p);
        victim.damage(src, outbound ? 10.0f : 6.0f);
        // тупой конец не пронзает, а сильно отбрасывает
        victim.takeKnockback(outbound ? 2.2 : 1.8, -dir.x, -dir.z);
        victim.setVelocity(victim.getVelocity().add(0.0, 0.3, 0.0));
        syncVelocity(victim);
        ServerWorld w = f.world;
        Vec3d at = victim.getBoundingBox().getCenter();
        w.spawnParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 24, 0.4, 0.4, 0.4, 0.3);
        w.spawnParticles(ParticleTypes.CLOUD, at.x, at.y, at.z, 8, 0.3, 0.3, 0.3, 0.1);
        bonk(w, at);
    }

    private static LivingEntity firstEnemy(ServerWorld w, ServerPlayerEntity p, Box box, Set<UUID> skip) {
        List<LivingEntity> list = w.getEntitiesByClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && !(e instanceof ArmorStandEntity) && !skip.contains(e.getUuid()));
        return list.isEmpty() ? null : list.get(0);
    }

    private static void tickFlights(MinecraftServer server, int t) {
        for (Map.Entry<UUID, Flight> en : new ArrayList<>(FLIGHTS.entrySet())) {
            Flight f = en.getValue();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.FOVIUS)
                    || p.getServerWorld() != f.world || f.entity.isRemoved()) {
                f.entity.discard();
                FLIGHTS.remove(en.getKey());   // потерянный меч выдастся заново (см. tick)
                continue;
            }
            f.age++;
            ItemEntity e = f.entity;
            ServerWorld w = f.world;

            if (!f.returning) {
                if (f.stuck >= 0) {   // меч лежит на месте
                    f.stuck++;
                    e.setVelocity(Vec3d.ZERO);
                    if (f.stuck > STUCK_TICKS) startReturn(p, f);
                    continue;
                }
                e.setVelocity(f.dir.multiply(THROW_SPEED));
                e.velocityModified = true;
                w.spawnParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 0.2, e.getZ(), 2, 0.1, 0.1, 0.1, 0.0);

                LivingEntity victim = firstEnemy(w, p, e.getBoundingBox().expand(0.5), f.hit);
                boolean blocked = e.horizontalCollision || e.verticalCollision
                        || e.getVelocity().lengthSquared() < 0.25 * THROW_SPEED * THROW_SPEED * 0.5;
                if (victim != null) {
                    swordHit(p, f, victim, f.dir, true);
                    f.stuck = 0;
                    e.setVelocity(Vec3d.ZERO);
                    e.velocityModified = true;
                } else if (blocked || f.age > MAX_FLY_TICKS) {
                    f.stuck = 0;
                    e.setVelocity(Vec3d.ZERO);
                    e.velocityModified = true;
                    w.playSound(null, e.getBlockPos(), SoundEvents.BLOCK_CHAIN_HIT, SoundCategory.PLAYERS, 1.0f, 0.6f);
                }
                continue;
            }

            // возвращение к Фовиусу: проходит сквозь цели и отбрасывает их
            Vec3d target = p.getPos().add(0.0, p.getHeight() * 0.6, 0.0);
            Vec3d to = target.subtract(e.getPos());
            double dist = to.length();
            if (dist < 1.6 || f.age > 20 * 40) {
                finishFlight(p, f, t);
                continue;
            }
            if (dist > f.lastDist - 0.2) f.noProgress++; else f.noProgress = 0;
            f.lastDist = dist;
            if (f.noProgress > 12) {   // застрял за стеной: меч просто возвращается в руки
                finishFlight(p, f, t);
                continue;
            }
            Vec3d dir = to.normalize();
            e.setVelocity(dir.multiply(Math.min(RETURN_SPEED, dist)));
            e.velocityModified = true;
            w.spawnParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 0.2, e.getZ(), 2, 0.1, 0.1, 0.1, 0.0);

            for (LivingEntity victim : w.getEntitiesByClass(LivingEntity.class, e.getBoundingBox().expand(0.9),
                    x -> x != p && x.isAlive() && !(x instanceof ArmorStandEntity) && !f.hit.contains(x.getUuid()))) {
                f.hit.add(victim.getUuid());
                swordHit(p, f, victim, dir, false);
            }
        }
    }

    // ---------- тик ----------

    public static void tick(MinecraftServer server, int t) {
        tickCurses(server, t);
        tickFlights(server, t);

        // если меч потерялся (вышли из игры в полёте и т.п.) - выдаём заново
        if (t % 40 == 0) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (!Forms.isActive(p, Form.FOVIUS) || FLIGHTS.containsKey(p.getUuid())) continue;
                if (!hasSword(p)) p.getInventory().offerOrDrop(new ItemStack(ModItems.FOVIUS_SWORD));
            }
        }
    }
}

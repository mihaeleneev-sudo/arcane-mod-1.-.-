package com.arcane;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

/** Генерация мира: огромное дерево с Забытой душой в равнинах. Параметры - в data/arcane/worldgen/placed_feature. */
public final class ModFeatures {
    public static final GiantTreeFeature GIANT_TREE = new GiantTreeFeature();
    public static final RegistryKey<PlacedFeature> GIANT_TREE_PLACED =
            RegistryKey.of(RegistryKeys.PLACED_FEATURE, new Identifier(ArcaneMod.MOD_ID, "giant_hollow_tree"));

    private ModFeatures() {}

    public static void init() {
        Registry.register(Registries.FEATURE, new Identifier(ArcaneMod.MOD_ID, "giant_hollow_tree"), GIANT_TREE);
        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SUNFLOWER_PLAINS),
                GenerationStep.Feature.VEGETAL_DECORATION,
                GIANT_TREE_PLACED);
    }
}

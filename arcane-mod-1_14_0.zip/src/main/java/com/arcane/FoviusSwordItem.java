package com.arcane;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.util.Rarity;

/** Прямой прямоугольный меч Фовиуса с тупым концом. Выдаётся в форме, пропадает при выходе из неё. */
public class FoviusSwordItem extends SwordItem {
    public FoviusSwordItem() {
        super(ToolMaterials.IRON, 4, -2.8f,
                new FabricItemSettings().maxCount(1).rarity(Rarity.RARE).fireproof());
    }
}

package com.arcane.client;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/**
 * Рисует поверх модели игрока: костюм Саира, красную кожу Эйро, золотое свечение Шута,
 * стальную броню Меха с золотыми трещинами. Это не предмет брони, снять нельзя.
 */
public class FormFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier SAIR_TEX = new Identifier("arcane", "textures/entity/sair_costume.png");
    private static final Identifier EIRO_TEX = new Identifier("arcane", "textures/entity/eiro_demon.png");
    private static final Identifier JESTER_TEX = new Identifier("arcane", "textures/entity/jester_glow.png");
    private static final Identifier ZET_CAPE_TEX = new Identifier("arcane", "textures/entity/zet_cape.png");
    private static final Identifier KING_TEX = new Identifier("arcane", "textures/entity/king_overlay.png");
    private static final Identifier KING_CAPE_TEX = new Identifier("arcane", "textures/entity/king_cape.png");
    private static final Identifier KING_CAPE_DARK_TEX = new Identifier("arcane", "textures/entity/king_cape_dark.png");
    private static final Identifier ZEUS_CAPE_TEX = new Identifier("arcane", "textures/entity/zeus_cape.png");
    private static final Identifier ZEUS_CAPE_CHARGED_TEX = new Identifier("arcane", "textures/entity/zeus_cape_charged.png");
    private static final Identifier COFFIN_TEX = new Identifier("arcane", "textures/entity/fovius_coffin.png");
    private static final Identifier MECHA_TEX = new Identifier("arcane", "textures/entity/mecha_plating.png");
    private static final Identifier MECHA_CRACKS_TEX = new Identifier("arcane", "textures/entity/mecha_cracks.png");

    private final PlayerEntityModel<AbstractClientPlayerEntity> sair;
    private final PlayerEntityModel<AbstractClientPlayerEntity> sairSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> sairUp;
    private final PlayerEntityModel<AbstractClientPlayerEntity> sairUpSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> eiro;
    private final PlayerEntityModel<AbstractClientPlayerEntity> eiroSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> jester;
    private final PlayerEntityModel<AbstractClientPlayerEntity> jesterSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> mecha;
    private final PlayerEntityModel<AbstractClientPlayerEntity> mechaSlim;
    private final PlayerEntityModel<AbstractClientPlayerEntity> king;
    private final PlayerEntityModel<AbstractClientPlayerEntity> kingSlim;
    private final ModelPart coffin;

    public FormFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context,
                               EntityModelLoader loader) {
        super(context);
        this.sair = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_LAYER), false);
        this.sairSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_SLIM_LAYER), true);
        this.sairUp = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_UP_LAYER), false);
        this.sairUpSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.SAIR_UP_SLIM_LAYER), true);
        this.eiro = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.EIRO_LAYER), false);
        this.eiroSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.EIRO_SLIM_LAYER), true);
        this.jester = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.JESTER_LAYER), false);
        this.jesterSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.JESTER_SLIM_LAYER), true);
        this.mecha = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.MECHA_LAYER), false);
        this.mechaSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.MECHA_SLIM_LAYER), true);
        this.king = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.KING_LAYER), false);
        this.kingSlim = new PlayerEntityModel<>(loader.getModelPart(ArcaneClient.KING_SLIM_LAYER), true);
        this.coffin = loader.getModelPart(ArcaneClient.COFFIN_LAYER);
    }

    /** Фовиус: огромный металлический гроб за спиной. При приседании наклоняется вместе с телом. */
    private void renderCoffin(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                              AbstractClientPlayerEntity player) {
        matrices.push();
        if (player.isInSneakingPose()) {
            matrices.translate(0.0f, 0.2f, 0.0f);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(28.0f));
        }
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(COFFIN_TEX));
        this.coffin.render(matrices, vc, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }

    /** Синяя накидка Зевса: рисуется на модели отдельно от брони. При заряде светится даже в темноте. */
    private void renderZeusCape(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                float limbDistance, AbstractClientPlayerEntity player, boolean charged) {
        matrices.push();
        matrices.translate(0.0f, 0.0f, 0.125f);
        float sway = 6.0f + Math.min(1.0f, limbDistance) * 40.0f;
        if (player.isInSneakingPose()) sway += 25.0f;
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sway));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        VertexConsumer vc = vertexConsumers.getBuffer(
                RenderLayer.getEntitySolid(charged ? ZEUS_CAPE_CHARGED_TEX : ZEUS_CAPE_TEX));
        this.getContextModel().renderCape(matrices, vc,
                charged ? LightmapTextureManager.MAX_LIGHT_COORDINATE : light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }

    /** Король: золотая корона и королевский плащ; с Желанием поверх тела рисуется скелет и чёрный плащ. */
    private void renderKing(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                            AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                            float animationProgress, float headYaw, float headPitch, boolean wish) {
        boolean slim = "slim".equals(player.getModel());
        PlayerEntityModel<AbstractClientPlayerEntity> m = slim ? kingSlim : king;
        PlayerEntityModel<AbstractClientPlayerEntity> base = this.getContextModel();

        base.copyStateTo(m);
        m.sneaking = base.sneaking;
        m.leftArmPose = base.leftArmPose;
        m.rightArmPose = base.rightArmPose;
        m.animateModel(player, limbAngle, limbDistance, tickDelta);
        m.setAngles(player, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        m.setVisible(false);
        m.hat.visible = true;   // корона
        if (wish) {
            m.head.visible = true;
            m.body.visible = true;
            m.leftArm.visible = true;
            m.rightArm.visible = true;
            m.leftLeg.visible = true;
            m.rightLeg.visible = true;
        }
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(KING_TEX));
        m.render(matrices, vc, light, LivingEntityRenderer.getOverlay(player, 0.0f), 1.0f, 1.0f, 1.0f, 1.0f);

        matrices.push();
        matrices.translate(0.0f, 0.0f, 0.125f);
        float sway = 6.0f + Math.min(1.0f, limbDistance) * 40.0f;
        if (player.isInSneakingPose()) sway += 25.0f;
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sway));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        VertexConsumer cape = vertexConsumers.getBuffer(
                RenderLayer.getEntitySolid(wish ? KING_CAPE_DARK_TEX : KING_CAPE_TEX));
        base.renderCape(matrices, cape, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }

    /** Зелёный плащ Зета: ванильная модель плаща, чуть отлетает при ходьбе. */
    private void renderZetCape(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                               float limbDistance, AbstractClientPlayerEntity player) {
        matrices.push();
        matrices.translate(0.0f, 0.0f, 0.125f);
        float sway = 6.0f + Math.min(1.0f, limbDistance) * 40.0f;
        if (player.isInSneakingPose()) sway += 25.0f;
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sway));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f));
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntitySolid(ZET_CAPE_TEX));
        this.getContextModel().renderCape(matrices, vc, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        int form = ClientForms.get(player.getUuid());
        if (form == 0 || player.isInvisible()) return;

        if (form == 6) {   // Зет: зелёный плащ
            renderZetCape(matrices, vertexConsumers, light, limbDistance, player);
            return;
        }
        if (form == 10 || form == 11) {   // Зевс: синяя накидка (не броня); при заряде светится
            renderZeusCape(matrices, vertexConsumers, light, limbDistance, player, form == 11);
            return;
        }
        if (form == 12) {   // Фовиус: гроб за спиной
            renderCoffin(matrices, vertexConsumers, light, player);
            return;
        }
        if (form == 8 || form == 9) {   // Король: корона и плащ; с Желанием ещё и скелет
            renderKing(matrices, vertexConsumers, light, player, limbAngle, limbDistance, tickDelta,
                    animationProgress, headYaw, headPitch, form == 9);
            return;
        }

        boolean slim = "slim".equals(player.getModel());
        PlayerEntityModel<AbstractClientPlayerEntity> m;
        RenderLayer layer;
        int usedLight = light;

        if (form == 1 || form == 5) {
            m = form == 5 ? (slim ? sairUpSlim : sairUp) : (slim ? sairSlim : sair);
            layer = RenderLayer.getEntityCutoutNoCull(SAIR_TEX);
        } else if (form == 2) {
            m = eiro;   // скин демона рассчитан на обычные руки, поэтому одна модель для всех
            layer = RenderLayer.getEntityCutoutNoCull(EIRO_TEX);
        } else if (form == 3) {
            m = slim ? jesterSlim : jester;
            layer = RenderLayer.getEntityTranslucent(JESTER_TEX);
            usedLight = LightmapTextureManager.MAX_LIGHT_COORDINATE; // светится даже в темноте
        } else if (form == 4) {
            m = slim ? mechaSlim : mecha;
            layer = RenderLayer.getEntityCutoutNoCull(MECHA_TEX);
        } else {
            return;
        }

        PlayerEntityModel<AbstractClientPlayerEntity> base = this.getContextModel();

        // повторяем позу основной модели игрока
        base.copyStateTo(m);
        m.sneaking = base.sneaking;
        m.leftArmPose = base.leftArmPose;
        m.rightArmPose = base.rightArmPose;
        m.animateModel(player, limbAngle, limbDistance, tickDelta);
        m.setAngles(player, limbAngle, limbDistance, animationProgress, headYaw, headPitch);

        m.setVisible(false);
        m.body.visible = true;
        m.leftArm.visible = true;
        m.rightArm.visible = true;
        m.leftLeg.visible = true;
        m.rightLeg.visible = true;
        if (form == 1 || form == 5) m.hat.visible = true;   // у Саира голову закрывает плетёная шляпа
        else m.head.visible = true;
        if (form == 2) m.setVisible(true);   // демон: полный скин вместе с внешним слоем (рога, лохмотья)

        int overlay = LivingEntityRenderer.getOverlay(player, 0.0f);
        VertexConsumer vc = vertexConsumers.getBuffer(layer);
        m.render(matrices, vc, usedLight, overlay, 1.0f, 1.0f, 1.0f, 1.0f);

        // Меха: золотые трещины проступают всё сильнее и светятся
        if (form == 4) {
            float progress = ClientForms.mechaProgress(player.getUuid(), tickDelta);
            float alpha = 0.12f + 0.88f * progress;
            VertexConsumer cracks = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(MECHA_CRACKS_TEX));
            m.render(matrices, cracks, LightmapTextureManager.MAX_LIGHT_COORDINATE, overlay, 1.0f, 1.0f, 1.0f, alpha);
        }
    }
}

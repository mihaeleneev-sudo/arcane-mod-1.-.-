package com.arcane.client;

import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * Маска Они (красный демон): настоящая 3D-модель из блоков - лицевая пластина, нахмуренные брови,
 * жёлтые глаза, нос, щёки, пасть с зубами и клыками, золотисто-чёрные рога и острые уши.
 * Текстура 128x128 нарисована вручную (assets/arcane/textures/entity/oni_mask.png).
 * Размеры - в единицах модели (1/16 блока) относительно головы: лицо смотрит в -Z, верх головы y = -8.
 * Этот файл создан генератором: описание частей лежит в одном месте вместе с рисованием текстуры.
 */
public final class OniMaskModel {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier("arcane", "oni_mask"), "main");
    private static final Identifier TEX = new Identifier("arcane", "textures/entity/oni_mask.png");

    private OniMaskModel() {}

    public static TexturedModelData createLayer() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData p_strap = root.addChild("strap",
                ModelPartBuilder.create().uv(0, 0).cuboid(-4.5f, -7.0f, -4.5f, 9.0f, 1.0f, 9.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_plate_upper = root.addChild("plate_upper",
                ModelPartBuilder.create().uv(36, 0).cuboid(-4.5f, -8.5f, -5.5f, 9.0f, 6.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_plate_lower = root.addChild("plate_lower",
                ModelPartBuilder.create().uv(74, 0).cuboid(-3.5f, -2.5f, -5.5f, 7.0f, 3.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_crest = root.addChild("crest",
                ModelPartBuilder.create().uv(8, 10).cuboid(-3.0f, -10.0f, -6.0f, 6.0f, 2.0f, 2.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_nose = root.addChild("nose",
                ModelPartBuilder.create().uv(92, 0).cuboid(-1.0f, -2.0f, -1.0f, 2.0f, 3.0f, 2.0f).uv(68, 10).cuboid(-1.5f, 0.5f, -1.0f, 3.0f, 1.0f, 2.0f),
                ModelTransform.of(0.0f, -3.5f, -6.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_mouth = root.addChild("mouth",
                ModelPartBuilder.create().uv(78, 10).cuboid(-3.0f, -1.0f, -0.5f, 6.0f, 2.0f, 1.0f).uv(28, 15).cuboid(-2.0f, -1.0f, -1.0f, 4.0f, 1.0f, 1.0f).uv(38, 15).cuboid(-2.0f, 0.0f, -1.0f, 4.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, -1.5f, -6.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_chin = root.addChild("chin",
                ModelPartBuilder.create().uv(48, 15).cuboid(-2.0f, 0.3f, -6.3f, 4.0f, 1.0f, 1.0f),
                ModelTransform.of(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_socket_1 = root.addChild("socket_1",
                ModelPartBuilder.create().uv(24, 10).cuboid(-2.0f, -1.5f, -0.5f, 4.0f, 3.0f, 1.0f),
                ModelTransform.of(2.3f, -4.6f, -5.5f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_eye_1 = root.addChild("eye_1",
                ModelPartBuilder.create().uv(92, 10).cuboid(-1.5f, -1.0f, -0.5f, 3.0f, 2.0f, 1.0f),
                ModelTransform.of(2.3f, -4.6f, -5.9f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_socket_m1 = root.addChild("socket_-1",
                ModelPartBuilder.create().uv(34, 10).cuboid(-2.0f, -1.5f, -0.5f, 4.0f, 3.0f, 1.0f),
                ModelTransform.of(-2.3f, -4.6f, -5.5f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_eye_m1 = root.addChild("eye_-1",
                ModelPartBuilder.create().uv(100, 10).cuboid(-1.5f, -1.0f, -0.5f, 3.0f, 2.0f, 1.0f),
                ModelTransform.of(-2.3f, -4.6f, -5.9f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_brow_1 = root.addChild("brow_1",
                ModelPartBuilder.create().uv(108, 10).cuboid(-2.5f, -1.0f, -0.5f, 5.0f, 2.0f, 1.0f),
                ModelTransform.of(2.5f, -6.8f, -6.0f, 0.0f, 0.0f, -0.35f));
        ModelPartData p_brow_m1 = root.addChild("brow_-1",
                ModelPartBuilder.create().uv(0, 15).cuboid(-2.5f, -1.0f, -0.5f, 5.0f, 2.0f, 1.0f),
                ModelTransform.of(-2.5f, -6.8f, -6.0f, 0.0f, 0.0f, 0.35f));
        ModelPartData p_cheek_1 = root.addChild("cheek_1",
                ModelPartBuilder.create().uv(12, 15).cuboid(-1.5f, -1.0f, -0.5f, 3.0f, 2.0f, 1.0f),
                ModelTransform.of(3.2f, -2.8f, -5.8f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_cheek_m1 = root.addChild("cheek_-1",
                ModelPartBuilder.create().uv(20, 15).cuboid(-1.5f, -1.0f, -0.5f, 3.0f, 2.0f, 1.0f),
                ModelTransform.of(-3.2f, -2.8f, -5.8f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_fang_1 = root.addChild("fang_1",
                ModelPartBuilder.create().uv(44, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(3.0f, -0.5f, -6.3f, 0.0f, 0.0f, 0.2f));
        ModelPartData p_fang_m1 = root.addChild("fang_-1",
                ModelPartBuilder.create().uv(48, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(-3.0f, -0.5f, -6.3f, 0.0f, 0.0f, -0.2f));
        ModelPartData p_horn_1 = root.addChild("horn_1",
                ModelPartBuilder.create().uv(100, 0).cuboid(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f),
                ModelTransform.of(3.3f, -8.0f, -2.5f, 0.0f, 0.0f, 0.45f));
        ModelPartData p_horn_mid_1 = p_horn_1.addChild("horn_mid_1",
                ModelPartBuilder.create().uv(108, 0).cuboid(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f),
                ModelTransform.of(0.0f, -3.0f, 0.0f, 0.0f, 0.0f, 0.3f));
        ModelPartData p_horn_tip_1 = p_horn_mid_1.addChild("horn_tip_1",
                ModelPartBuilder.create().uv(52, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(0.0f, -3.0f, 0.0f, 0.0f, 0.0f, 0.35f));
        ModelPartData p_horn_m1 = root.addChild("horn_-1",
                ModelPartBuilder.create().uv(116, 0).cuboid(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f),
                ModelTransform.of(-3.3f, -8.0f, -2.5f, 0.0f, 0.0f, -0.45f));
        ModelPartData p_horn_mid_m1 = p_horn_m1.addChild("horn_mid_-1",
                ModelPartBuilder.create().uv(0, 10).cuboid(-1.0f, -3.0f, -1.0f, 2.0f, 3.0f, 2.0f),
                ModelTransform.of(0.0f, -3.0f, 0.0f, 0.0f, 0.0f, -0.3f));
        ModelPartData p_horn_tip_m1 = p_horn_mid_m1.addChild("horn_tip_-1",
                ModelPartBuilder.create().uv(56, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(0.0f, -3.0f, 0.0f, 0.0f, 0.0f, -0.35f));
        ModelPartData p_ear_1 = root.addChild("ear_1",
                ModelPartBuilder.create().uv(58, 0).cuboid(0.0f, -2.0f, -1.5f, 1.0f, 4.0f, 3.0f),
                ModelTransform.of(4.0f, -4.5f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_ear_tip_1 = p_ear_1.addChild("ear_tip_1",
                ModelPartBuilder.create().uv(60, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(0.5f, -2.0f, 0.0f, 0.0f, 0.0f, 0.5f));
        ModelPartData p_ear_m1 = root.addChild("ear_-1",
                ModelPartBuilder.create().uv(66, 0).cuboid(0.0f, -2.0f, -1.5f, 1.0f, 4.0f, 3.0f),
                ModelTransform.of(-5.0f, -4.5f, 0.0f, 0.0f, 0.0f, 0.0f));
        ModelPartData p_ear_tip_m1 = p_ear_m1.addChild("ear_tip_-1",
                ModelPartBuilder.create().uv(64, 10).cuboid(-0.5f, -3.0f, -0.5f, 1.0f, 3.0f, 1.0f),
                ModelTransform.of(0.5f, -2.0f, 0.0f, 0.0f, 0.0f, -0.5f));
        return TexturedModelData.of(data, 128, 32);
    }

    /** Рисует маску в системе координат головы (после ModelPart.rotate головы). */
    public static void render(ModelPart model, MatrixStack matrices, VertexConsumerProvider vcp, int light) {
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));
        model.render(matrices, vc, light, OverlayTexture.DEFAULT_UV);
    }
}

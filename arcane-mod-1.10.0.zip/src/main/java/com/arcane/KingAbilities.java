package com.arcane;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Король: Рог (H) призывает защитников, Атака (J) - приказ бить цель, Возврат (K) - вернуть к себе.
 * С "Желанием Короля" защитники сильнее, а ещё есть Невидимость (L).
 */
public final class KingAbilities {
    private static final String TAG_WISH = "arcane_king_wish";
    private static final String SHARDS_PREFIX = "arcane_king_shards_";
    public static final int SHARDS_NEEDED = 3;

    private static final int HORN_COOLDOWN = 60 * 20;
    private static final int ATTACK_COOLDOWN = 5 * 20;
    private static final int RETURN_COOLDOWN = 3 * 20;
    private static final int INVIS_COOLDOWN = 30 * 20;
    private static final int INVIS_TICKS = 10 * 20;
    private static final double TARGET_RANGE = 20.0;

    private static final Map<UUID, Integer> HORN_CD = new HashMap<>();
    private static final Map<UUID, Integer> ATTACK_CD = new HashMap<>();
    private static final Map<UUID, Integer> RETURN_CD = new HashMap<>();
    private static final Map<UUID, Integer> INVIS_CD = new HashMap<>();
    private static final Map<UUID, List<MobEntity>> GUARDS = new HashMap<>();
    private static final Map<UUID, LivingEntity> FOCUS = new HashMap<>();

    private KingAbilities() {}

    // ---------- состояние (теги игрока, поэтому сохраняется) ----------

    public static boolean hasWish(net.minecraft.entity.player.PlayerEntity p) {
        return p.getCommandTags().contains(TAG_WISH);
    }

    public static int shards(net.minecraft.entity.player.PlayerEntity p) {
        for (String tag : p.getCommandTags()) {
            if (tag.startsWith(SHARDS_PREFIX)) {
                try {
                    return Integer.parseInt(tag.substring(SHARDS_PREFIX.length()));
                } catch (NumberFormatException ignored) {
                    // битый тег пропускаем
                }
            }
        }
        return 0;
    }

    private static void setShards(ServerPlayerEntity p, int n) {
        for (String tag : new ArrayList<>(p.getCommandTags())) {
            if (tag.startsWith(SHARDS_PREFIX)) p.removeScoreboardTag(tag);
        }
        if (n > 0) p.addCommandTag(SHARDS_PREFIX + n);
    }

    public static void clear(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_WISH);
        setShards(p, 0);
        discardGuards(p);
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (hasWish(oldP)) newP.addCommandTag(TAG_WISH);
        int n = shards(oldP);
        if (n > 0) newP.addCommandTag(SHARDS_PREFIX + n);
    }

    /** Осколок Желания. @return true, если предмет израсходован. */
    public static boolean useShard(ServerPlayerEntity p) {
        if (Forms.character(p) != Form.KING) {
            p.sendMessage(Text.translatable("message.arcane.shard_only_king"), true);
            return false;
        }
        if (hasWish(p)) {
            p.sendMessage(Text.translatable("message.arcane.wish_already"), true);
            return false;
        }
        int n = shards(p) + 1;
        setShards(p, n);
        ServerWorld w = p.getServerWorld();
        if (n >= SHARDS_NEEDED) {
            grantWish(p);
        } else {
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
            p.sendMessage(Text.translatable("message.arcane.shard_count", n, SHARDS_NEEDED), false);
        }
        return true;
    }

    public static void grantWish(ServerPlayerEntity p) {
        p.addCommandTag(TAG_WISH);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1.0, p.getZ(), 60, 0.5, 0.9, 0.5, 0.05);
        w.playSound(null, p.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1.0f, 0.8f);
        p.sendMessage(Text.translatable("message.arcane.wish_granted"), false);
        Forms.broadcast(p.getServer(), p);   // внешность меняется сразу
    }

    // ---------- форма ----------

    public static void onDeactivate(ServerPlayerEntity p, Form was) {
        if (was == Form.KING) discardGuards(p);
    }

    private static void discardGuards(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        rescan(p);
        List<MobEntity> list = GUARDS.remove(id);
        FOCUS.remove(id);
        if (list == null) return;
        ServerWorld w = p.getServerWorld();
        for (MobEntity g : list) {
            if (g.isAlive()) {
                w.spawnParticles(ParticleTypes.POOF, g.getX(), g.getY() + 1.0, g.getZ(), 10, 0.3, 0.5, 0.3, 0.05);
                g.discard();
            }
        }
    }

    /** Находит защитников этого Короля рядом (нужно и после перезапуска сервера). */
    private static void rescan(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        List<MobEntity> list = GUARDS.computeIfAbsent(id, k -> new ArrayList<>());
        for (MobEntity m : p.getServerWorld().getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(80.0),
                e -> e instanceof KingGuardian kg && id.equals(kg.getOwnerId()) && e.isAlive())) {
            if (!list.contains(m)) list.add(m);
        }
    }

    // ---------- клавиши H, J, K, L ----------

    /** 0 - Рог, 1 - Атака, 2 - Возврат, 3 - Невидимость. */
    public static void action(ServerPlayerEntity p, int action) {
        if (!Forms.isActive(p, Form.KING)) return;
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        switch (action) {
            case 0 -> horn(p, id, now);
            case 1 -> attack(p, id, now);
            case 2 -> back(p, id, now);
            case 3 -> invisibility(p, id, now);
            default -> { }
        }
    }

    private static boolean cooldown(ServerPlayerEntity p, Map<UUID, Integer> map, UUID id, int now) {
        int until = map.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return true;
        }
        return false;
    }

    private static GuardianWarriorEntity spawnWarrior(ServerPlayerEntity p, double angle, double radius, boolean armored) {
        ServerWorld w = p.getServerWorld();
        GuardianWarriorEntity z = new GuardianWarriorEntity(ModEntities.GUARDIAN_WARRIOR, w);
        z.setOwnerId(p.getUuid());
        z.refreshPositionAndAngles(p.getX() + Math.cos(angle) * radius, p.getY(), p.getZ() + Math.sin(angle) * radius, 0.0f, 0.0f);
        z.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        if (armored) {
            z.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            z.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
            z.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
            z.equipStack(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
        }
        for (EquipmentSlot s : EquipmentSlot.values()) z.setEquipmentDropChance(s, 0.0f);
        z.setCustomName(Text.translatable(armored ? "entity.arcane.guardian_wish" : "entity.arcane.guardian_warrior")
                .formatted(armored ? Formatting.DARK_PURPLE : Formatting.GOLD));
        z.setCustomNameVisible(true);
        z.setPersistent();
        z.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 1000000, 0, false, false));
        w.spawnEntity(z);
        return z;
    }

    private static GuardianArcherEntity spawnArcher(ServerPlayerEntity p, double angle, double radius) {
        ServerWorld w = p.getServerWorld();
        GuardianArcherEntity a = new GuardianArcherEntity(ModEntities.GUARDIAN_ARCHER, w);
        a.setOwnerId(p.getUuid());
        a.refreshPositionAndAngles(p.getX() + Math.cos(angle) * radius, p.getY(), p.getZ() + Math.sin(angle) * radius, 0.0f, 0.0f);
        a.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        for (EquipmentSlot s : EquipmentSlot.values()) a.setEquipmentDropChance(s, 0.0f);
        a.setCustomName(Text.translatable("entity.arcane.guardian_archer").formatted(Formatting.DARK_PURPLE));
        a.setCustomNameVisible(true);
        a.setPersistent();
        a.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 1000000, 0, false, false));
        w.spawnEntity(a);
        return a;
    }

    /** Рог: 3 защитника, а с Желанием 3 лучника и 2 воина в железной броне. */
    private static void horn(ServerPlayerEntity p, UUID id, int now) {
        if (cooldown(p, HORN_CD, id, now)) return;
        discardGuards(p);
        List<MobEntity> list = new ArrayList<>();
        boolean wish = hasWish(p);
        if (wish) {
            for (int i = 0; i < 3; i++) list.add(spawnArcher(p, i * 2.0 * Math.PI / 3.0, 3.0));
            for (int i = 0; i < 2; i++) list.add(spawnWarrior(p, Math.PI / 2.0 + i * Math.PI, 2.0, true));
        } else {
            for (int i = 0; i < 3; i++) list.add(spawnWarrior(p, i * 2.0 * Math.PI / 3.0, 2.0, false));
        }
        GUARDS.put(id, list);
        HORN_CD.put(id, now + HORN_COOLDOWN);

        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BELL_USE, SoundCategory.PLAYERS, 1.5f, 0.5f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0f, 0.6f);
        for (int i = 0; i < 30; i++) {
            double a = p.getRandom().nextDouble() * Math.PI * 2.0;
            w.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX() + Math.cos(a) * 2.0, p.getY() + 1.0,
                    p.getZ() + Math.sin(a) * 2.0, 1, 0, 0, 0, 0);
        }
        p.sendMessage(Text.translatable(wish ? "message.arcane.horn_wish" : "message.arcane.horn_normal"), true);
    }

    private static LivingEntity findTarget(ServerPlayerEntity p) {
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f);
        Vec3d end = start.add(dir.multiply(TARGET_RANGE));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : p.getServerWorld().getOtherEntities(p,
                p.getBoundingBox().stretch(dir.multiply(TARGET_RANGE)).expand(1.0))) {
            if (!(e instanceof LivingEntity living) || !living.isAlive() || e instanceof KingGuardian) continue;
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(start, end);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = living;
                }
            }
        }
        return best;
    }

    /** Атака: все защитники бросаются на цель, на которую смотрит Король. */
    private static void attack(ServerPlayerEntity p, UUID id, int now) {
        if (cooldown(p, ATTACK_CD, id, now)) return;
        rescan(p);
        List<MobEntity> list = GUARDS.get(id);
        if (list == null) list = new ArrayList<>();
        list.removeIf(g -> !g.isAlive());
        if (list.isEmpty()) {
            p.sendMessage(Text.translatable("message.arcane.no_guards"), true);
            return;
        }
        LivingEntity target = findTarget(p);
        if (target == null) {
            p.sendMessage(Text.translatable("message.arcane.no_target"), true);
            return;
        }
        FOCUS.put(id, target);
        for (MobEntity g : list) g.setTarget(target);
        ATTACK_CD.put(id, now + ATTACK_COOLDOWN);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 0.5f, 1.2f);
        p.sendMessage(Text.translatable("message.arcane.guards_attack"), true);
    }

    /** Возврат: защитники прекращают бой и встают вокруг Короля. */
    private static void back(ServerPlayerEntity p, UUID id, int now) {
        if (cooldown(p, RETURN_CD, id, now)) return;
        rescan(p);
        List<MobEntity> list = GUARDS.get(id);
        if (list == null) list = new ArrayList<>();
        list.removeIf(g -> !g.isAlive());
        if (list.isEmpty()) {
            p.sendMessage(Text.translatable("message.arcane.no_guards"), true);
            return;
        }
        FOCUS.remove(id);
        double step = 2.0 * Math.PI / list.size();
        for (int i = 0; i < list.size(); i++) {
            MobEntity g = list.get(i);
            g.setTarget(null);
            g.requestTeleport(p.getX() + Math.cos(i * step) * 2.0, p.getY(), p.getZ() + Math.sin(i * step) * 2.0);
        }
        RETURN_CD.put(id, now + RETURN_COOLDOWN);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.5f, 1.0f);
        p.sendMessage(Text.translatable("message.arcane.guards_return"), true);
    }

    /** Невидимость и скорость на 10 секунд. Только с Желанием Короля. */
    private static void invisibility(ServerPlayerEntity p, UUID id, int now) {
        if (!hasWish(p)) return;
        if (cooldown(p, INVIS_CD, id, now)) return;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, INVIS_TICKS, 0, false, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, INVIS_TICKS, 2, false, true));
        INVIS_CD.put(id, now + INVIS_COOLDOWN);
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.5f);
        w.spawnParticles(ParticleTypes.SMOKE, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.5, 0.8, 0.5, 0.03);
        p.sendMessage(Text.translatable("message.arcane.escape"), true);
    }

    // ---------- тик ----------

    public static void tick(MinecraftServer server, int t) {
        if (t % 40 == 0) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (Forms.isActive(p, Form.KING)) rescan(p);
            }
        }
        for (Map.Entry<UUID, List<MobEntity>> en : new ArrayList<>(GUARDS.entrySet())) {
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(en.getKey());
            List<MobEntity> list = en.getValue();
            list.removeIf(g -> !g.isAlive());
            if (owner == null || !Forms.isActive(owner, Form.KING)) {
                for (MobEntity g : list) g.discard();
                GUARDS.remove(en.getKey());
                FOCUS.remove(en.getKey());
                continue;
            }
            LivingEntity focus = FOCUS.get(en.getKey());
            if (focus != null && !focus.isAlive()) {
                FOCUS.remove(en.getKey());
                focus = null;
            }
            for (MobEntity g : list) {
                LivingEntity target = g.getTarget();
                // защитники не трогают хозяина и игроков без приказа
                if (target == owner || (target instanceof net.minecraft.entity.player.PlayerEntity && target != focus)) g.setTarget(null);
                else if (focus != null && t % 10 == 0) g.setTarget(focus);
            }
        }
    }
}

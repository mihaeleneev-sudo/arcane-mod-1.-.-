package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.TitleFadeS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Зевс. Пробуждение: жилет на груди, гроза - через некоторое время в игрока бьёт молния ("Подобен богу").
 * Умение 1 (R) "Щиток": молния из рук. Умение 2 (G) "Я сам бог": молния с неба по противнику.
 * Пассивно копится статическое электричество; когда шкала полна, 30 секунд умения усилены:
 * "Щиток" бьёт по области, "Я сам бог" затягивает небо тучами и трижды бьёт случайных противников.
 */
public final class ZeusAbilities {
    private static final String TAG_STATIC = "arcane_static_";
    private static final String TAG_OVER = "arcane_zeus_over";

    public static final int STATIC_MAX = 100;
    private static final int OVER_TICKS = 30 * 20;
    private static final int SKILL1_COOLDOWN = 3 * 20;
    private static final int SKILL2_COOLDOWN = 8 * 20;
    private static final int CHARGE_SKILL1 = 20;
    private static final int CHARGE_SKILL2 = 35;

    private static final DustParticleEffect BLUE = new DustParticleEffect(new Vector3f(0.45f, 0.75f, 1.0f), 1.0f);
    private static final DustParticleEffect WHITE = new DustParticleEffect(new Vector3f(0.95f, 0.97f, 1.0f), 0.8f);

    private static final class Cast {
        final ServerWorld world;
        int ticks = 0;

        Cast(ServerWorld world) {
            this.world = world;
        }
    }

    private static final Map<UUID, Integer> STORM = new HashMap<>();       // отсчёт до удара молнии при пробуждении
    private static final Map<UUID, Integer> OVER_END = new HashMap<>();    // конец усиления (тик сервера)
    private static final Map<UUID, Integer> CD1 = new HashMap<>();
    private static final Map<UUID, Integer> CD2 = new HashMap<>();
    private static final Map<UUID, Cast> CASTS = new HashMap<>();
    private static final Set<UUID> DIRTY = new HashSet<>();

    private ZeusAbilities() {}

    // ---------- состояние (теги игрока, поэтому сохраняется) ----------

    public static boolean isOvercharged(PlayerEntity p) { return p.getCommandTags().contains(TAG_OVER); }

    public static int getStatic(PlayerEntity p) {
        for (String tag : p.getCommandTags()) {
            if (tag.startsWith(TAG_STATIC)) {
                try {
                    return Integer.parseInt(tag.substring(TAG_STATIC.length()));
                } catch (NumberFormatException ignored) {
                    // битый тег пропускаем
                }
            }
        }
        return 0;
    }

    private static void setStatic(ServerPlayerEntity p, int value) {
        for (String tag : new ArrayList<>(p.getCommandTags())) {
            if (tag.startsWith(TAG_STATIC)) p.removeScoreboardTag(tag);
        }
        int v = Math.max(0, Math.min(STATIC_MAX, value));
        if (v > 0) p.addCommandTag(TAG_STATIC + v);
        DIRTY.add(p.getUuid());
    }

    public static void clear(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_OVER);
        setStatic(p, 0);
        OVER_END.remove(p.getUuid());
        CASTS.remove(p.getUuid());
        STORM.remove(p.getUuid());
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        int s = getStatic(oldP);
        if (s > 0) newP.addCommandTag(TAG_STATIC + s);
        if (isOvercharged(oldP)) newP.addCommandTag(TAG_OVER);
    }

    public static void onDeactivate(ServerPlayerEntity p, Form was) {
        if (was == Form.ZEUS) CASTS.remove(p.getUuid());
    }

    public static void sendStatic(ServerPlayerEntity p) {
        boolean on = Forms.character(p) == Form.ZEUS;
        int left = -1;
        if (on && isOvercharged(p)) {
            Integer end = OVER_END.get(p.getUuid());
            if (end != null) left = Math.max(0, end - p.getServer().getTicks());
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(on ? getStatic(p) : -1);
        buf.writeInt(left);
        ServerPlayNetworking.send(p, Packets.STATIC, buf);
    }

    // ---------- пробуждение: жилет + гроза ----------

    private static void awaken(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        bolt(w, p.getPos());   // молния без урона и огня
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.5, 1.0, 0.5, 0.3);
        Forms.setCharacter(p, Form.ZEUS);
        p.networkHandler.sendPacket(new TitleFadeS2CPacket(10, 80, 30));
        p.networkHandler.sendPacket(new TitleS2CPacket(Text.translatable("title.arcane.like_god")
                .formatted(Formatting.AQUA, Formatting.BOLD)));
    }

    // ---------- молния-эффект ----------

    /** Настоящая молния ради вспышки и грома, но косметическая: не бьёт и не поджигает. */
    private static void bolt(ServerWorld w, Vec3d pos) {
        LightningEntity b = EntityType.LIGHTNING_BOLT.create(w);
        if (b == null) return;
        b.refreshPositionAfterTeleport(pos.x, pos.y, pos.z);
        b.setCosmetic(true);
        w.spawnEntity(b);
    }

    /** Рваная дуга молнии между двумя точками. */
    private static void jagged(ServerWorld w, Vec3d a, Vec3d b) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 0.1) return;
        Vec3d dir = d.normalize();
        Vec3d helper = Math.abs(dir.y) > 0.95 ? new Vec3d(1.0, 0.0, 0.0) : new Vec3d(0.0, 1.0, 0.0);
        Vec3d s1 = dir.crossProduct(helper).normalize();
        Vec3d s2 = dir.crossProduct(s1).normalize();
        int steps = Math.max(2, (int) (len / 0.5));
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            double env = Math.sin(Math.PI * t);   // на концах дуга сходится в точку
            Vec3d pt = a.add(dir.multiply(t * len))
                    .add(s1.multiply(w.getRandom().nextGaussian() * 0.18 * env))
                    .add(s2.multiply(w.getRandom().nextGaussian() * 0.18 * env));
            w.spawnParticles(BLUE, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
            if (i % 2 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.02);
            if (i % 5 == 0) w.spawnParticles(WHITE, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private static Vec3d hand(ServerPlayerEntity p) {
        Vec3d dir = p.getRotationVec(1.0f).normalize();
        Vec3d flat = new Vec3d(dir.x, 0.0, dir.z);
        Vec3d right = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1.0, 0.0, 0.0) : new Vec3d(-flat.z, 0.0, flat.x).normalize();
        return p.getEyePos().add(dir.multiply(0.6)).add(right.multiply(0.25)).add(0.0, -0.35, 0.0);
    }

    /** Ищет цель по взгляду; out[0] получает точку попадания (цель, блок или конец луча). */
    private static LivingEntity pick(ServerPlayerEntity p, double range, Vec3d[] out) {
        ServerWorld w = p.getServerWorld();
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f).normalize();
        Vec3d end = start.add(dir.multiply(range));
        BlockHitResult bh = w.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        double len = bh.getType() == HitResult.Type.MISS ? range : start.distanceTo(bh.getPos());
        Vec3d lineEnd = start.add(dir.multiply(len));

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(start, lineEnd).expand(1.0),
                ent -> ent != p && ent.isAlive() && !(ent instanceof ArmorStandEntity))) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(start, lineEnd);
            if (hit.isPresent()) {
                double d = start.distanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        out[0] = best != null ? best.getBoundingBox().getCenter() : lineEnd;
        return best;
    }

    private static List<LivingEntity> enemiesAround(ServerPlayerEntity p, double r) {
        double r2 = r * r;
        return p.getServerWorld().getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r),
                e -> e != p && e.isAlive() && !(e instanceof ArmorStandEntity) && e.squaredDistanceTo(p) <= r2);
    }

    /** Удар током: цель на пару секунд замедляется и слабеет. */
    private static void shock(LivingEntity e) {
        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
        e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 0));
    }

    private static boolean cooldown(ServerPlayerEntity p, Map<UUID, Integer> map, int now) {
        int until = map.getOrDefault(p.getUuid(), 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return true;
        }
        return false;
    }

    // ---------- заряд и усиление ----------

    private static void addCharge(ServerPlayerEntity p, int amount) {
        if (isOvercharged(p)) return;
        int s = Math.min(STATIC_MAX, getStatic(p) + amount);
        setStatic(p, s);
        if (s >= STATIC_MAX) startOvercharge(p);
    }

    private static void startOvercharge(ServerPlayerEntity p) {
        p.addCommandTag(TAG_OVER);
        OVER_END.put(p.getUuid(), p.getServer().getTicks() + OVER_TICKS);
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 1.0f, 1.3f);
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI / 12.0;
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX() + Math.cos(a) * 1.5, p.getY() + 1.0, p.getZ() + Math.sin(a) * 1.5,
                    0, Math.cos(a) * 0.2, 0.05, Math.sin(a) * 0.2, 1.0);
        }
        p.sendMessage(Text.translatable("message.arcane.overcharge_on"), false);
        Forms.broadcast(p.getServer(), p);   // накидка начинает светиться
        sendStatic(p);
    }

    private static void endOvercharge(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_OVER);
        OVER_END.remove(p.getUuid());
        setStatic(p, 0);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.6, 1.0, 0.6, 0.2);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 1.0f, 1.2f);
        p.sendMessage(Text.translatable("message.arcane.overcharge_off"), true);
        Forms.broadcast(p.getServer(), p);
        sendStatic(p);
    }

    // ---------- умение 1 (клавиша R): "Щиток" ----------

    public static void skill1(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        if (cooldown(p, CD1, now)) return;
        CD1.put(p.getUuid(), now + SKILL1_COOLDOWN);

        ServerWorld w = p.getServerWorld();
        Vec3d[] end = new Vec3d[1];
        LivingEntity target = pick(p, 18.0, end);
        Vec3d from = hand(p);

        if (isOvercharged(p)) {
            areaStrike(p, w, from, end[0]);
        } else {
            jagged(w, from, end[0]);
            if (target != null) {
                target.damage(p.getDamageSources().playerAttack(p), 8.0f);
                shock(target);
            }
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, end[0].x, end[0].y, end[0].z, 18, 0.25, 0.25, 0.25, 0.25);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.PLAYERS, 0.6f, 1.8f);
        }
        addCharge(p, CHARGE_SKILL1);
    }

    /** Усиленный "Щиток": молния бьёт по области радиусом 5 блоков. */
    private static void areaStrike(ServerPlayerEntity p, ServerWorld w, Vec3d from, Vec3d center) {
        jagged(w, from, center);
        bolt(w, center);
        double r = 5.0;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(center.x - r, center.y - r, center.z - r,
                center.x + r, center.y + r, center.z + r),
                ent -> ent != p && ent.isAlive() && !(ent instanceof ArmorStandEntity) && ent.squaredDistanceTo(center) <= r * r)) {
            e.damage(p.getDamageSources().playerAttack(p), 10.0f);
            shock(e);
            e.takeKnockback(0.5, center.x - e.getX(), center.z - e.getZ());
        }
        for (int i = 0; i < 24; i++) {   // кольцо искр по границе области
            double a = i * Math.PI / 12.0;
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x + Math.cos(a) * r, center.y + 0.2, center.z + Math.sin(a) * r,
                    0, 0.0, 0.1, 0.0, 1.0);
        }
        for (int i = 0; i < 4; i++) {   // дуги расходятся от центра
            double a = w.getRandom().nextDouble() * Math.PI * 2.0;
            jagged(w, center, center.add(Math.cos(a) * 4.0, 0.3, Math.sin(a) * 4.0));
        }
    }

    // ---------- умение 2 (клавиша G): "Я сам бог" ----------

    public static void skill2(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        UUID id = p.getUuid();
        if (CASTS.containsKey(id)) return;
        if (cooldown(p, CD2, now)) return;

        ServerWorld w = p.getServerWorld();
        if (isOvercharged(p)) {
            if (enemiesAround(p, 16.0).isEmpty()) {
                p.sendMessage(Text.translatable("message.arcane.no_target"), true);
                return;
            }
            CASTS.put(id, new Cast(w));
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.8f, 0.6f);
        } else {
            Vec3d[] end = new Vec3d[1];
            LivingEntity target = pick(p, 30.0, end);
            if (target == null) {
                List<LivingEntity> near = enemiesAround(p, 20.0);
                if (!near.isEmpty()) target = near.get(p.getRandom().nextInt(near.size()));
            }
            if (target == null) {
                p.sendMessage(Text.translatable("message.arcane.no_target"), true);
                return;
            }
            strikeFromSky(p, w, target, 14.0f);
        }
        CD2.put(id, now + SKILL2_COOLDOWN);
        addCharge(p, CHARGE_SKILL2);
    }

    /** Молния с неба по противнику. */
    private static void strikeFromSky(ServerPlayerEntity p, ServerWorld w, LivingEntity target, float dmg) {
        bolt(w, target.getPos());
        target.damage(p.getDamageSources().playerAttack(p), dmg);
        shock(target);
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + target.getHeight() * 0.5, target.getZ(),
                30, 0.4, 0.5, 0.4, 0.3);
    }

    /** Усиленный "Я сам бог": тучи над головой и три удара молнии по случайным противникам. */
    private static void tickCasts(MinecraftServer server) {
        for (Map.Entry<UUID, Cast> en : new ArrayList<>(CASTS.entrySet())) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
            Cast c = en.getValue();
            if (p == null || !p.isAlive() || !Forms.isActive(p, Form.ZEUS) || p.getServerWorld() != c.world) {
                CASTS.remove(en.getKey());
                continue;
            }
            c.ticks++;
            ServerWorld w = c.world;

            // небо затягивает тучами
            double cloudY = p.getY() + 12.0;
            for (int i = 0; i < 28; i++) {
                double a = w.getRandom().nextDouble() * Math.PI * 2.0;
                double rad = 14.0 * Math.sqrt(w.getRandom().nextDouble());
                w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX() + Math.cos(a) * rad, cloudY + w.getRandom().nextDouble() * 2.0,
                        p.getZ() + Math.sin(a) * rad, 1, 0.0, 0.0, 0.0, 0.0);
            }
            for (int i = 0; i < 6; i++) {
                double a = w.getRandom().nextDouble() * Math.PI * 2.0;
                double rad = 14.0 * Math.sqrt(w.getRandom().nextDouble());
                w.spawnParticles(ParticleTypes.CLOUD, p.getX() + Math.cos(a) * rad, cloudY, p.getZ() + Math.sin(a) * rad,
                        1, 0.0, 0.0, 0.0, 0.0);
            }

            if (c.ticks == 20 || c.ticks == 40 || c.ticks == 60) {   // три удара
                List<LivingEntity> enemies = enemiesAround(p, 16.0);
                if (!enemies.isEmpty()) {
                    LivingEntity target = enemies.get(p.getRandom().nextInt(enemies.size()));
                    strikeFromSky(p, w, target, 12.0f);
                }
            }
            if (c.ticks >= 80) {
                CASTS.remove(en.getKey());
                w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.6f, 0.5f);
            }
        }
    }

    // ---------- тик ----------

    private static void aura(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        int count = 1 + getStatic(p) / 25 + (isOvercharged(p) ? 3 : 0);
        for (int i = 0; i < count; i++) {
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                    p.getX() + (w.getRandom().nextDouble() - 0.5) * 1.2, p.getY() + 0.2 + w.getRandom().nextDouble() * 1.8,
                    p.getZ() + (w.getRandom().nextDouble() - 0.5) * 1.2, 1, 0.0, 0.0, 0.0, 0.02);
        }
    }

    public static void tick(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            boolean zeus = Forms.character(p) == Form.ZEUS;

            // пробуждение: жилет на груди и гроза. Через 30-90 секунд в игрока бьёт молния
            boolean eligible = !zeus && p.getEquippedStack(EquipmentSlot.CHEST).isOf(ModItems.ZEUS_VEST)
                    && p.getServerWorld().isThundering();
            if (!eligible) {
                STORM.remove(id);
            } else {
                Integer left = STORM.get(id);
                if (left == null) left = 600 + p.getRandom().nextInt(1200);
                else left--;
                if (left <= 0) {
                    STORM.remove(id);
                    awaken(p);
                } else {
                    STORM.put(id, left);
                }
            }
            if (!zeus) continue;

            // усиление: 30 секунд, потом шкала сбрасывается
            if (isOvercharged(p)) {
                Integer end = OVER_END.get(id);
                if (end == null) OVER_END.put(id, t + OVER_TICKS);   // после перезапуска сервера
                else if (t >= end) endOvercharge(p);
            }
            if (Forms.isActive(p, Form.ZEUS) && t % 5 == 0) aura(p);
            if (DIRTY.remove(id) || t % 20 == 0) sendStatic(p);
        }
        tickCasts(server);
    }
}

package com.arcane;

import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Хантер: однозарядный дробовик (ПКМ), "Ловушка" (R) - капкан, видимый только Хантеру,
 * "Мишень" (G) - переключатель дробь / дальний патрон.
 * У баунти хантера вместо капкана удар прикладом.
 */
public final class HunterAbilities {
    private static final String TAG_SLUG = "arcane_hunter_slug";
    private static final String TAG_BOUNTY = "arcane_hunter_bounty";

    private static final int SKILL_COOLDOWN = 5 * 20;
    private static final int MISS_COOLDOWN = 20;
    private static final int TRAP_MAX = 3;
    private static final int TRAP_LOCK_TICKS = 3 * 20;
    private static final int RELOAD_PELLETS = 2 * 20;
    private static final int RELOAD_SLUG = 3 * 20;

    private static final DustParticleEffect STEEL = new DustParticleEffect(new Vector3f(0.62f, 0.64f, 0.7f), 1.0f);
    private static final DustParticleEffect TRACER = new DustParticleEffect(new Vector3f(1.0f, 0.85f, 0.4f), 0.8f);
    private static final DustParticleEffect TRACER_SMALL = new DustParticleEffect(new Vector3f(1.0f, 0.8f, 0.35f), 0.55f);
    private static final DustParticleEffect SWING = new DustParticleEffect(new Vector3f(0.95f, 0.95f, 1.0f), 1.3f);

    private static final class Trap {
        final ServerWorld world;
        final Vec3d pos;
        final UUID owner;

        Trap(ServerWorld world, Vec3d pos, UUID owner) {
            this.world = world;
            this.pos = pos;
            this.owner = owner;
        }
    }

    private static final class Trapped {
        final LivingEntity entity;
        int ticks;

        Trapped(LivingEntity entity, int ticks) {
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    /** Отложенный звук после выстрела: передёргивание затвора и щелчок готовности. */
    private static final class Delayed {
        final UUID player;
        final SoundEvent sound;
        final float pitch;
        final boolean casing;
        int delay;

        Delayed(UUID player, SoundEvent sound, float pitch, boolean casing, int delay) {
            this.player = player;
            this.sound = sound;
            this.pitch = pitch;
            this.casing = casing;
            this.delay = delay;
        }
    }

    private static final List<Trap> TRAPS = new ArrayList<>();
    private static final Map<UUID, Trapped> TRAPPED = new HashMap<>();
    private static final Map<UUID, Integer> SKILL_CD = new HashMap<>();
    private static final List<Delayed> DELAYED = new ArrayList<>();

    private HunterAbilities() {}

    // ---------- состояние ----------

    public static boolean hasBounty(PlayerEntity p) { return p.getCommandTags().contains(TAG_BOUNTY); }

    public static boolean isSlug(PlayerEntity p) { return p.getCommandTags().contains(TAG_SLUG); }

    public static void becomeBounty(ServerPlayerEntity p) {
        p.addCommandTag(TAG_BOUNTY);
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(ParticleTypes.CRIT, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.5, 0.9, 0.5, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_VILLAGER_YES, SoundCategory.PLAYERS, 1.0f, 0.8f);
        p.sendMessage(Text.translatable("message.arcane.bounty_hunter"), false);
    }

    public static void clear(ServerPlayerEntity p) {
        p.removeScoreboardTag(TAG_BOUNTY);
        p.removeScoreboardTag(TAG_SLUG);
        removeTraps(p.getUuid());
    }

    public static void copy(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        if (hasBounty(oldP)) newP.addCommandTag(TAG_BOUNTY);
        if (isSlug(oldP)) newP.addCommandTag(TAG_SLUG);
    }

    // ---------- форма ----------

    public static void giveShotgun(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.HUNTER_SHOTGUN)) return;
        }
        inv.offerOrDrop(new ItemStack(ModItems.HUNTER_SHOTGUN));
    }

    public static void onDeactivate(ServerPlayerEntity p, Form was) {
        if (was != Form.HUNTER) return;
        removeTraps(p.getUuid());
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.HUNTER_SHOTGUN)) inv.setStack(i, ItemStack.EMPTY);
        }
    }

    private static void removeTraps(UUID owner) {
        TRAPS.removeIf(t -> t.owner.equals(owner));
    }

    // ---------- умение 1 (клавиша R) ----------

    public static void skill1(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        int now = p.getServer().getTicks();
        int until = SKILL_CD.getOrDefault(id, 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }
        if (hasBounty(p)) buttStrike(p, id, now);
        else placeTrap(p, id, now);
    }

    private static Vec3d flatLook(ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0.0, look.z);
        return flat.lengthSquared() < 1.0E-4 ? new Vec3d(0.0, 0.0, 1.0) : flat.normalize();
    }

    /** Капкан: обычный стальной капкан. Его видит только владелец, остальным он невидим. */
    private static void placeTrap(ServerPlayerEntity p, UUID id, int now) {
        Vec3d pos = p.getPos().add(flatLook(p).multiply(1.5));
        int mine = 0;
        for (Trap t : TRAPS) if (t.owner.equals(id)) mine++;
        while (mine >= TRAP_MAX) {   // не больше трёх: старейший исчезает
            Iterator<Trap> it = TRAPS.iterator();
            while (it.hasNext()) {
                if (it.next().owner.equals(id)) {
                    it.remove();
                    break;
                }
            }
            mine--;
        }
        TRAPS.add(new Trap(p.getServerWorld(), pos, id));
        setSkillCooldown(id, now);
        p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE,
                SoundCategory.PLAYERS, 1.0f, 0.7f);
        p.sendMessage(Text.translatable("message.arcane.trap_placed", mine + 1, TRAP_MAX), true);
    }

    private static void setSkillCooldown(UUID id, int now) {
        SKILL_CD.put(id, now + SKILL_COOLDOWN);
    }

    // ---------- удар прикладом: эффекты ----------

    /** Дуга взмаха перед игроком: две полосы частиц, вспышка-серп и искры на концах. */
    private static void swingEffect(ServerWorld w, ServerPlayerEntity p, Vec3d fwd) {
        Vec3d base = p.getPos().add(0.0, 1.1, 0.0);
        for (int deg = -80; deg <= 80; deg += 10) {
            double a = Math.toRadians(deg);
            double dx = fwd.x * Math.cos(a) - fwd.z * Math.sin(a);
            double dz = fwd.x * Math.sin(a) + fwd.z * Math.cos(a);
            double lift = (80 - Math.abs(deg)) / 400.0;   // дуга чуть выгнута вверх
            for (double r = 1.5; r <= 2.4; r += 0.45) {
                w.spawnParticles(SWING, base.x + dx * r, base.y + lift, base.z + dz * r, 1, 0.0, 0.0, 0.0, 0.0);
            }
            if (Math.abs(deg) == 80 || deg == 0) {
                w.spawnParticles(ParticleTypes.CRIT, base.x + dx * 2.2, base.y + lift, base.z + dz * 2.2, 3, 0.1, 0.1, 0.1, 0.2);
            }
        }
        Vec3d mid = base.add(fwd.multiply(1.8));
        w.spawnParticles(ParticleTypes.SWEEP_ATTACK, mid.x, mid.y, mid.z, 1, 0.0, 0.0, 0.0, 0.0);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.2f, 0.7f);
    }

    /** Удар прикладом: сильно отбрасывает того, кто стоит впереди. */
    private static void buttStrike(ServerPlayerEntity p, UUID id, int now) {
        ServerWorld w = p.getServerWorld();
        Vec3d fwd = flatLook(p);
        swingEffect(w, p, fwd);   // взмах виден всегда, даже при промахе

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(3.5, 1.5, 3.5),
                ent -> ent != p && ent.isAlive())) {
            Vec3d rel = new Vec3d(e.getX() - p.getX(), 0.0, e.getZ() - p.getZ());
            double dist = rel.length();
            if (dist > 3.2 || dist < 1.0E-4) continue;
            if (rel.normalize().dotProduct(fwd) < 0.5) continue;
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        if (best == null) {
            SKILL_CD.put(id, now + MISS_COOLDOWN);   // промах: короткая пауза
            return;
        }

        best.damage(p.getDamageSources().playerAttack(p), 5.0f);
        best.takeKnockback(2.4, p.getX() - best.getX(), p.getZ() - best.getZ());
        best.setVelocity(best.getVelocity().add(0.0, 0.3, 0.0));
        best.velocityModified = true;

        // эффект попадания: искры, облачко и кольцо удара под целью
        double hx = best.getX();
        double hy = best.getY() + best.getHeight() * 0.6;
        double hz = best.getZ();
        w.spawnParticles(ParticleTypes.CRIT, hx, hy, hz, 25, 0.3, 0.4, 0.3, 0.4);
        w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, hx, hy, hz, 3, 0.2, 0.3, 0.2, 0.1);
        w.spawnParticles(ParticleTypes.POOF, hx, hy, hz, 6, 0.2, 0.2, 0.2, 0.08);
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6.0;
            w.spawnParticles(ParticleTypes.CLOUD, hx + Math.cos(a) * 1.1, best.getY() + 0.1, hz + Math.sin(a) * 1.1,
                    0, Math.cos(a) * 0.15, 0.02, Math.sin(a) * 0.15, 1.0);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1.5f, 0.8f);
        w.playSound(null, best.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_DAMAGE, SoundCategory.PLAYERS, 0.8f, 1.3f);
        SKILL_CD.put(id, now + SKILL_COOLDOWN);
    }

    // ---------- умение 2 (клавиша G): "Мишень" ----------

    /** Переключатель: дробь (разброс) или дальний патрон (точный выстрел, помечает цель). */
    public static void toggleAmmo(ServerPlayerEntity p) {
        boolean slug;
        if (isSlug(p)) {
            p.removeScoreboardTag(TAG_SLUG);
            slug = false;
        } else {
            p.addCommandTag(TAG_SLUG);
            slug = true;
        }
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getBlockPos(), SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE,
                SoundCategory.PLAYERS, 1.0f, slug ? 0.8f : 1.2f);
        // маленькая вспышка у ствола и выброшенная гильза/дробь
        Vec3d hand = p.getEyePos().add(p.getRotationVec(1.0f).multiply(0.7)).add(0.0, -0.35, 0.0);
        w.spawnParticles(slug ? ParticleTypes.ELECTRIC_SPARK : ParticleTypes.CRIT, hand.x, hand.y, hand.z, 8, 0.12, 0.12, 0.12, 0.15);
        p.sendMessage(Text.translatable(slug ? "message.arcane.ammo_slug" : "message.arcane.ammo_pellets"), true);
    }

    // ---------- дробовик ----------

    private static final class Shot {
        final LivingEntity entity;
        final float amount;

        Shot(LivingEntity entity, float amount) {
            this.entity = entity;
            this.amount = amount;
        }
    }

    /** Один луч дроби или пули с трассером и эффектом попадания в блок. */
    private static Shot trace(ServerPlayerEntity p, Vec3d start, Vec3d dir, double range, float dmg,
                              double falloff, boolean slug) {
        ServerWorld w = p.getServerWorld();
        Vec3d end = start.add(dir.multiply(range));
        BlockHitResult bh = w.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        double len = bh.getType() == HitResult.Type.MISS ? range : start.distanceTo(bh.getPos());
        Vec3d lineEnd = start.add(dir.multiply(len));

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(start, lineEnd).expand(1.0),
                ent -> ent != p && ent.isAlive())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.15).raycast(start, lineEnd);
            if (hit.isPresent()) {
                double d = start.distanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        double shown = best != null ? bestDist : len;

        // трассер: у пули яркая сплошная линия с дымным следом, у дроби короткие штрихи
        if (slug) {
            for (double d = 0.8; d <= shown; d += 0.5) {
                Vec3d pt = start.add(dir.multiply(d));
                w.spawnParticles(TRACER, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
                if (((int) (d * 2)) % 6 == 0) w.spawnParticles(ParticleTypes.SMOKE, pt.x, pt.y, pt.z, 1, 0.03, 0.03, 0.03, 0.0);
                if (((int) (d * 2)) % 4 == 0) w.spawnParticles(ParticleTypes.CRIT, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0.05);
            }
        } else {
            for (double d = 1.0; d <= shown; d += 1.2) {
                Vec3d pt = start.add(dir.multiply(d));
                w.spawnParticles(TRACER_SMALL, pt.x, pt.y, pt.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }

        if (best == null) {
            if (bh.getType() != HitResult.Type.MISS) {
                // попадание в блок: крошка блока, дым и искры
                Vec3d hp = bh.getPos();
                BlockState bs = w.getBlockState(bh.getBlockPos());
                if (!bs.isAir()) {
                    w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, bs), hp.x, hp.y, hp.z,
                            slug ? 14 : 4, 0.12, 0.12, 0.12, 0.1);
                }
                w.spawnParticles(ParticleTypes.SMOKE, hp.x, hp.y, hp.z, slug ? 6 : 2, 0.08, 0.08, 0.08, 0.02);
                w.spawnParticles(ParticleTypes.CRIT, hp.x, hp.y, hp.z, slug ? 8 : 2, 0.1, 0.1, 0.1, 0.25);
                if (slug) w.spawnParticles(ParticleTypes.POOF, hp.x, hp.y, hp.z, 3, 0.1, 0.1, 0.1, 0.05);
            }
            return null;
        }
        float amount = dmg * (float) Math.max(0.35, 1.0 - falloff * bestDist / range);
        return new Shot(best, amount);
    }

    /** Эффект выстрела у ствола: вспышка, язык пламени, дым, искры, гильза. */
    private static void muzzleEffects(ServerWorld w, ServerPlayerEntity p, Vec3d start, Vec3d dir, boolean slug) {
        Vec3d flat = new Vec3d(dir.x, 0.0, dir.z);
        Vec3d right = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1.0, 0.0, 0.0)
                : new Vec3d(-flat.z, 0.0, flat.x).normalize();
        Vec3d muzzle = start.add(dir.multiply(0.9)).add(right.multiply(0.25)).add(0.0, -0.1, 0.0);

        w.spawnParticles(ParticleTypes.FLASH, muzzle.x, muzzle.y, muzzle.z, 1, 0.0, 0.0, 0.0, 0.0);
        if (slug) w.spawnParticles(ParticleTypes.EXPLOSION, muzzle.x, muzzle.y, muzzle.z, 1, 0.0, 0.0, 0.0, 0.0);

        // язык пламени вперёд
        int flames = slug ? 8 : 6;
        for (int i = 0; i < flames; i++) {
            double sp = 0.35 + p.getRandom().nextDouble() * 0.3;
            w.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 0,
                    dir.x * sp + p.getRandom().nextGaussian() * 0.03,
                    dir.y * sp + p.getRandom().nextGaussian() * 0.03,
                    dir.z * sp + p.getRandom().nextGaussian() * 0.03, 1.0);
        }
        // дымные клубы вперёд и вверх
        for (int i = 0; i < 10; i++) {
            double sp = 0.1 + p.getRandom().nextDouble() * 0.12;
            w.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 0,
                    dir.x * sp + p.getRandom().nextGaussian() * 0.02,
                    dir.y * sp + 0.03 + p.getRandom().nextGaussian() * 0.02,
                    dir.z * sp + p.getRandom().nextGaussian() * 0.02, 1.0);
        }
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, muzzle.x, muzzle.y, muzzle.z, 3, 0.1, 0.1, 0.1, 0.02);
        w.spawnParticles(ParticleTypes.CRIT, muzzle.x, muzzle.y, muzzle.z, 10, 0.1, 0.1, 0.1, 0.5);

        // звук: хлопок, выстрел и эхо
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, slug ? 0.7f : 0.5f, slug ? 1.6f : 1.9f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.6f, slug ? 0.5f : 0.7f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST_FAR, SoundCategory.PLAYERS, 1.0f, 0.8f);
    }

    public static void fire(ServerPlayerEntity p, Item gun) {
        ServerWorld w = p.getServerWorld();
        Vec3d dir = p.getRotationVec(1.0f).normalize();
        Vec3d start = p.getEyePos().add(0.0, -0.15, 0.0);
        boolean slug = isSlug(p);

        Map<LivingEntity, Float> totals = new HashMap<>();
        if (slug) {
            Shot s = trace(p, start, dir, 60.0, 14.0f, 0.0, true);
            if (s != null) {
                totals.merge(s.entity, s.amount, Float::sum);
                // "мишень": попавшая цель подсвечивается
                s.entity.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 80, 0, false, false));
            }
        } else {
            for (int i = 0; i < 8; i++) {   // 8 дробин с разбросом
                Vec3d d = new Vec3d(dir.x + p.getRandom().nextGaussian() * 0.05,
                        dir.y + p.getRandom().nextGaussian() * 0.05,
                        dir.z + p.getRandom().nextGaussian() * 0.05).normalize();
                Shot s = trace(p, start, d, 18.0, 3.0f, 0.6, false);
                if (s != null) totals.merge(s.entity, s.amount, Float::sum);
            }
        }
        // дробины складываются в один удар, иначе неуязвимость после первого попадания съела бы остальные
        for (Map.Entry<LivingEntity, Float> en : totals.entrySet()) {
            LivingEntity e = en.getKey();
            e.timeUntilRegen = 0;
            e.damage(p.getDamageSources().playerAttack(p), en.getValue());
            double hy = e.getY() + e.getHeight() * 0.6;
            // эффект попадания в цель
            w.spawnParticles(ParticleTypes.CRIT, e.getX(), hy, e.getZ(), slug ? 24 : 12, 0.25, 0.3, 0.25, 0.35);
            w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, e.getX(), hy, e.getZ(), slug ? 4 : 2, 0.2, 0.3, 0.2, 0.1);
            w.spawnParticles(ParticleTypes.SMOKE, e.getX(), hy, e.getZ(), 4, 0.15, 0.2, 0.15, 0.02);
            if (slug) w.spawnParticles(ParticleTypes.POOF, e.getX(), hy, e.getZ(), 5, 0.2, 0.2, 0.2, 0.06);
            w.playSound(null, e.getBlockPos(), SoundEvents.ENTITY_ARROW_HIT_PLAYER, SoundCategory.PLAYERS, 0.8f, slug ? 0.8f : 1.2f);
        }

        muzzleEffects(w, p, start, dir, slug);

        int reload = slug ? RELOAD_SLUG : RELOAD_PELLETS;
        p.getItemCooldownManager().set(gun, reload);
        // передёргивание затвора и щелчок готовности
        DELAYED.add(new Delayed(p.getUuid(), SoundEvents.ITEM_CROSSBOW_LOADING_MIDDLE, 0.9f, true, 12));
        DELAYED.add(new Delayed(p.getUuid(), SoundEvents.ITEM_CROSSBOW_LOADING_END, 1.0f, false, Math.max(1, reload - 1)));
    }

    // ---------- тик: капканы и отложенные звуки ----------

    public static void tick(MinecraftServer server, int t) {
        // отложенные звуки и вылет гильзы
        Iterator<Delayed> dit = DELAYED.iterator();
        while (dit.hasNext()) {
            Delayed d = dit.next();
            if (--d.delay > 0) continue;
            dit.remove();
            ServerPlayerEntity pl = server.getPlayerManager().getPlayer(d.player);
            if (pl == null || !pl.isAlive()) continue;
            ServerWorld w = pl.getServerWorld();
            w.playSound(null, pl.getBlockPos(), d.sound, SoundCategory.PLAYERS, 1.0f, d.pitch);
            if (d.casing) {
                Vec3d look = pl.getRotationVec(1.0f);
                Vec3d flat = new Vec3d(look.x, 0.0, look.z);
                Vec3d right = flat.lengthSquared() < 1.0E-4 ? new Vec3d(1.0, 0.0, 0.0)
                        : new Vec3d(-flat.z, 0.0, flat.x).normalize();
                Vec3d pos = pl.getEyePos().add(look.multiply(0.4)).add(right.multiply(0.3)).add(0.0, -0.4, 0.0);
                w.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.RED_WOOL)),
                        pos.x, pos.y, pos.z, 0, right.x * 0.15, 0.18, right.z * 0.15, 1.0);
            }
        }

        if (t % 2 == 0) {
            Iterator<Trap> it = TRAPS.iterator();
            while (it.hasNext()) {
                Trap tr = it.next();
                ServerPlayerEntity owner = server.getPlayerManager().getPlayer(tr.owner);
                if (owner == null) continue;   // владелец вышел: капкан спит

                // видно только владельцу: частицы отправляются ему одному
                if (t % 10 == 0) {
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4.0;
                        tr.world.spawnParticles(owner, STEEL, true,
                                tr.pos.x + Math.cos(a) * 0.45, tr.pos.y + 0.05, tr.pos.z + Math.sin(a) * 0.45,
                                1, 0, 0, 0, 0);
                    }
                }

                List<LivingEntity> found = tr.world.getEntitiesByClass(LivingEntity.class,
                        new Box(tr.pos.x - 0.9, tr.pos.y - 1.0, tr.pos.z - 0.9, tr.pos.x + 0.9, tr.pos.y + 1.2, tr.pos.z + 0.9),
                        ent -> ent.isAlive() && !ent.getUuid().equals(tr.owner) && !TRAPPED.containsKey(ent.getUuid()));
                if (!found.isEmpty()) {
                    LivingEntity victim = found.get(0);
                    victim.damage(owner.getDamageSources().playerAttack(owner), 8.0f);
                    TRAPPED.put(victim.getUuid(), new Trapped(victim, TRAP_LOCK_TICKS));
                    tr.world.spawnParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + 0.2, victim.getZ(), 20, 0.3, 0.1, 0.3, 0.3);
                    tr.world.playSound(null, victim.getBlockPos(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 0.6f, 1.6f);
                    owner.sendMessage(Text.translatable("message.arcane.trap_triggered"), true);
                    it.remove();
                }
            }
        }

        // пойманный в капкан не может двигаться
        Iterator<Map.Entry<UUID, Trapped>> tit = TRAPPED.entrySet().iterator();
        while (tit.hasNext()) {
            Trapped tp = tit.next().getValue();
            LivingEntity e = tp.entity;
            if (!e.isAlive() || --tp.ticks <= 0) {
                tit.remove();
                continue;
            }
            Vec3d v = e.getVelocity();
            e.setVelocity(0.0, Math.min(v.y, 0.0), 0.0);
            e.velocityModified = true;
            if (e instanceof MobEntity mob) mob.getNavigation().stop();
        }
    }
}

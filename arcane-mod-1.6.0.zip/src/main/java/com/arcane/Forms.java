package com.arcane;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.joml.Vector3f;

/**
 * Серверная логика персонажей и форм.
 * "Персонаж" (arcane_char_*) - какая сила у игрока. "Форма" (arcane_on_*) - включено ли превращение сейчас.
 * Всё хранится в командных тегах игрока, поэтому сохраняется вместе с миром.
 */
public final class Forms {
    public static final int COOLDOWN_TICKS = 30 * 20;
    public static final double EIRO_RADIUS = 5.0;
    private static final int AURA_TICKS = 60;

    private static final Map<UUID, Integer> COOLDOWN_UNTIL = new HashMap<>();
    private static final Map<UUID, Integer> AURA = new HashMap<>();

    private Forms() {}

    private static String charTag(Form f) { return "arcane_char_" + f.key; }
    private static String onTag(Form f) { return "arcane_on_" + f.key; }

    // ---------- состояние ----------

    public static Form character(PlayerEntity p) {
        for (Form f : Form.values()) {
            if (f != Form.NONE && p.getCommandTags().contains(charTag(f))) return f;
        }
        return Form.NONE;
    }

    public static Form active(PlayerEntity p) {
        for (Form f : Form.values()) {
            if (f != Form.NONE && p.getCommandTags().contains(onTag(f))) return f;
        }
        return Form.NONE;
    }

    public static boolean isActive(PlayerEntity p, Form f) {
        return p.getCommandTags().contains(onTag(f));
    }

    public static void setCharacter(ServerPlayerEntity p, Form f) {
        deactivate(p, false);
        for (Form old : Form.values()) {
            if (old != Form.NONE) p.removeScoreboardTag(charTag(old));
        }
        if (f == Form.MECHA && getMetal(p) == 0) setMetal(p, 50);
        if (f != Form.MECHA) clearMetal(p);
        if (f != Form.SAIR) SairUpgrade.clear(p);
        if (f != Form.ZET) ZetAbilities.clear(p);
        if (f != Form.NONE) {
            p.addCommandTag(charTag(f));
            p.sendMessage(Text.translatable("message.arcane.unlocked_" + f.key), false);
        } else {
            p.sendMessage(Text.translatable("message.arcane.power_removed"), false);
        }
        sendMecha(p);
        SairUpgrade.sendDuel(p);
    }

    public static void restoreCharacter(ServerPlayerEntity oldP, ServerPlayerEntity newP) {
        Form f = character(oldP);
        if (f != Form.NONE) newP.addCommandTag(charTag(f));
        if (f == Form.MECHA) newP.addCommandTag(METAL_PREFIX + getMetal(oldP));
        SairUpgrade.copy(oldP, newP);
    }

    // ---------- превращение ----------

    /** Нажатие Alt. */
    public static void toggle(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();

        if (active(p) != Form.NONE) {
            deactivate(p, true);
            COOLDOWN_UNTIL.put(p.getUuid(), now + COOLDOWN_TICKS);
            return;
        }

        Form ch = character(p);
        if (ch == Form.NONE) {
            p.sendMessage(Text.translatable("message.arcane.no_power"), true);
            return;
        }

        int until = COOLDOWN_UNTIL.getOrDefault(p.getUuid(), 0);
        if (now < until) {
            int seconds = (until - now + 19) / 20;
            p.sendMessage(Text.translatable("message.arcane.cooldown", seconds), true);
            return;
        }
        activate(p, ch);
    }

    private static void activate(ServerPlayerEntity p, Form f) {
        p.addCommandTag(onTag(f));
        ServerWorld w = p.getServerWorld();

        if (f == Form.SAIR) {
            w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 120, 0.5, 1.0, 0.5, 0.8);
            w.spawnParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1, p.getZ(), 60, 0.6, 1.0, 0.6, 0.5);
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0f, 0.7f);
            p.getInventory().offerOrDrop(new ItemStack(ModItems.SAIR_KATANA));
        } else if (f == Form.EIRO) {
            AURA.put(p.getUuid(), AURA_TICKS);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.5f, 0.6f);
        } else if (f == Form.JESTER) {
            HANDS.remove(p.getUuid());
            syncHand(p, false);
            w.spawnParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 40, 0.5, 0.9, 0.5, 0.05);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0f, 1.3f);
        } else if (f == Form.MECHA) {
            FORM_END.put(p.getUuid(), p.getServer().getTicks() + MECHA_FORM_TICKS);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 60, 0.6, 1.0, 0.6, 0.2);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_REPAIR, SoundCategory.PLAYERS, 1.2f, 0.6f);
            sendMecha(p);
        } else if (f == Form.ZET) {
            w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 0.5, 1.0, 0.5, 0.6);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 1.0f, 1.5f);
        }

        applyEffects(p);
        broadcast(p.getServer(), p);
        p.sendMessage(Text.translatable("message.arcane.on_" + f.key), false);
    }

    public static void deactivate(ServerPlayerEntity p, boolean notify) {
        Form was = active(p);
        if (was == Form.NONE) return;

        p.removeScoreboardTag(onTag(was));
        SairUpgrade.onDeactivate(p);
        ZetAbilities.onDeactivate(p, was);
        AURA.remove(p.getUuid());
        if (was == Form.JESTER) {
            HANDS.remove(p.getUuid());
            syncHand(p, false);
        }
        if (was == Form.MECHA) {
            FORM_END.remove(p.getUuid());
            LASERS.remove(p.getUuid());
            sendMecha(p);
        }
        p.removeStatusEffect(StatusEffects.SPEED);
        p.removeStatusEffect(StatusEffects.STRENGTH);
        p.removeStatusEffect(StatusEffects.FIRE_RESISTANCE);
        p.removeStatusEffect(StatusEffects.RESISTANCE);
        removeKatana(p);
        broadcast(p.getServer(), p);
        if (notify) p.sendMessage(Text.translatable("message.arcane.off"), false);
    }

    private static void removeKatana(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.SAIR_KATANA)) inv.setStack(i, ItemStack.EMPTY);
        }
    }

    private static void applyEffects(ServerPlayerEntity p) {
        Form f = active(p);
        if (f == Form.SAIR) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120, 1, true, false, true));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 120, SairUpgrade.isUpgraded(p) ? 1 : 0, true, false, true));
        } else if (f == Form.EIRO) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 120, 1, true, false, true));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 120, 0, true, false, true));
        } else if (f == Form.MECHA) {
            // чем больше железа, тем сильнее носитель
            int m = getMetal(p);
            if (m >= 25) p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 120, m >= 60 ? 1 : 0, true, false, true));
            if (m >= 40) p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 120, m >= 80 ? 1 : 0, true, false, true));
        }
    }

    // ---------- тик сервера ----------

    public static void tick(MinecraftServer server) {
        int t = server.getTicks();

        tickJester(server, t);
        tickMecha(server, t);
        SairUpgrade.tick(server, t);
        ZetAbilities.tick(server, t);

        if (t % 40 == 0) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (active(p) != Form.NONE) applyEffects(p);
            }
        }

        // голоса: раз в секунду бросаем кубик (в форме чаще, чем без неё)
        if (t % 20 == 0) {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (character(p) != Form.EIRO) continue;
                int chance = active(p) == Form.EIRO ? 20 : 120;
                if (p.getRandom().nextInt(chance) == 0) {
                    PacketByteBuf buf = PacketByteBufs.create();
                    buf.writeInt(p.getRandom().nextInt(3));
                    ServerPlayNetworking.send(p, Packets.VOICE, buf);
                }
            }
        }

        tickThrown();

        // огненная волна Эйро
        Iterator<Map.Entry<UUID, Integer>> it = AURA.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            if (p == null || !p.isAlive()) { it.remove(); continue; }

            ServerWorld w = p.getServerWorld();
            // только частицы: блоки не поджигаются
            w.spawnParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 0.8, p.getZ(), 30, 2.4, 0.8, 2.4, 0.04);
            w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 0.8, p.getZ(), 6, 2.4, 0.8, 2.4, 0.02);

            int left = e.getValue();
            if (left % 10 == 0) igniteAround(p);
            if (left <= 1) it.remove(); else e.setValue(left - 1);
        }
    }

    /** Поджигает только живых существ (мобов и игроков), кроме самого носителя. */
    private static void igniteAround(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Box box = p.getBoundingBox().expand(EIRO_RADIUS);
        double r2 = EIRO_RADIUS * EIRO_RADIUS;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                x -> x != p && x.isAlive() && x.squaredDistanceTo(p) <= r2)) {
            e.setOnFireFor(4);
        }
    }

    // ---------- Шут: 8 карт ----------

    private static final int HAND_MAX = 4;
    private static final int CARD_LIFETIME = 10 * 20;

    private static final class HandCard {
        final Card card;
        final int expires;

        HandCard(Card card, int expires) {
            this.card = card;
            this.expires = expires;
        }
    }

    private static final class PendingSound {
        final ServerWorld world;
        final double x, y, z;
        final float pitch;
        int delay;

        PendingSound(ServerWorld world, double x, double y, double z, float pitch, int delay) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.pitch = pitch;
            this.delay = delay;
        }
    }

    private static final Map<UUID, List<HandCard>> HANDS = new HashMap<>();
    private static final List<PendingSound> PENDING = new ArrayList<>();

    /** Вытягивает случайную из 8 карт и кладёт её в руку (максимум 4 карты, каждая живёт 10 секунд). */
    private static Card draw(ServerPlayerEntity p) {
        Card c = Card.byId(p.getRandom().nextInt(8));
        int now = p.getServer().getTicks();
        List<HandCard> hand = HANDS.computeIfAbsent(p.getUuid(), k -> new ArrayList<>());
        hand.removeIf(h -> h.expires <= now);
        while (hand.size() >= HAND_MAX) hand.remove(0);
        hand.add(new HandCard(c, now + CARD_LIFETIME));
        syncHand(p, true);
        return c;
    }

    private static int luckInHand(ServerPlayerEntity p) {
        List<HandCard> hand = HANDS.get(p.getUuid());
        if (hand == null) return 0;
        int now = p.getServer().getTicks();
        int n = 0;
        for (HandCard h : hand) if (h.card.luck && h.expires > now) n++;
        return n;
    }

    private static void syncHand(ServerPlayerEntity p, boolean fresh) {
        List<HandCard> hand = HANDS.get(p.getUuid());
        int now = p.getServer().getTicks();
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(fresh);
        if (hand == null) {
            buf.writeInt(0);
        } else {
            buf.writeInt(hand.size());
            for (HandCard h : hand) {
                buf.writeInt(h.card.id);
                buf.writeInt(Math.max(1, h.expires - now));
            }
        }
        ServerPlayNetworking.send(p, Packets.CARDS, buf);
    }

    /** Звон монет: чем больше карт удачи в руке, тем больше монет звякает подряд. */
    private static void playCoins(ServerPlayerEntity p, int count) {
        ServerWorld w = p.getServerWorld();
        for (int i = 0; i < Math.max(1, count); i++) {
            PENDING.add(new PendingSound(w, p.getX(), p.getY(), p.getZ(), 1.5f + 0.12f * i, 1 + i * 3));
        }
    }

    private static void reactToCard(ServerPlayerEntity p, Card c) {
        if (c.luck) {
            playCoins(p, luckInHand(p));
        } else {
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_VILLAGER_NO,
                    SoundCategory.PLAYERS, 0.5f, 0.8f);
        }
    }

    /** Любой урон шута: тянется карта и урон умножается (x1.5, x2, x3, x4) или делится (на 1.5, 2, 3, 4). */
    public static float rollDamage(ServerPlayerEntity attacker, LivingEntity target, float amount) {
        if (target.timeUntilRegen > 10) return amount; // повторный удар во время неуязвимости карту не тратит
        Card c = draw(attacker);
        reactToCard(attacker, c);
        return amount * c.damageMult;
    }

    /** Создание предмета: карта удачи улучшает его, карта неудачи отнимает прочность (10 / 25 / 75 / 100%). */
    public static void onCraft(ServerPlayerEntity p, ItemStack stack) {
        if (!isActive(p, Form.JESTER)) return;
        if (!(p.currentScreenHandler instanceof CraftingScreenHandler
                || p.currentScreenHandler instanceof PlayerScreenHandler)) return;

        Card c = draw(p);
        reactToCard(p, c);
        if (c.luck) {
            boolean changed = upgrade(stack, c.tier);
            p.sendMessage(Text.translatable(changed ? "message.arcane.craft_luck" : "message.arcane.craft_nothing"), true);
        } else {
            int percent = Card.CRAFT_LOSS_PERCENT[c.tier - 1];
            boolean changed = degrade(stack, percent);
            if (changed) p.sendMessage(Text.translatable("message.arcane.craft_bad", percent), true);
            else p.sendMessage(Text.translatable("message.arcane.craft_nothing"), true);
        }
    }

    private static boolean upgrade(ItemStack stack, int tier) {
        Item item = stack.getItem();
        Enchantment main = null;
        if (item instanceof SwordItem) main = Enchantments.SHARPNESS;
        else if (item instanceof MiningToolItem) main = Enchantments.EFFICIENCY;
        else if (item instanceof ArmorItem) main = Enchantments.PROTECTION;
        else if (item instanceof BowItem) main = Enchantments.POWER;
        else if (item instanceof CrossbowItem) main = Enchantments.QUICK_CHARGE;

        boolean changed = addEnchant(stack, main, tier);
        changed |= addEnchant(stack, Enchantments.UNBREAKING, Math.min(tier, 3));
        if (tier >= 4) changed |= addEnchant(stack, Enchantments.MENDING, 1);
        return changed;
    }

    private static boolean addEnchant(ItemStack stack, Enchantment e, int level) {
        if (e == null || !e.isAcceptableItem(stack)) return false;
        int lvl = Math.min(level, e.getMaxLevel());
        if (EnchantmentHelper.getLevel(e, stack) >= lvl) return false;
        for (Enchantment other : EnchantmentHelper.get(stack).keySet()) {
            if (other != e && !e.canCombine(other)) return false;
        }
        stack.addEnchantment(e, lvl);
        return true;
    }

    /** При 100% у предмета остаётся 1 единица прочности. */
    private static boolean degrade(ItemStack stack, int percent) {
        if (!stack.isDamageable()) return false;
        int max = stack.getMaxDamage();
        int loss = Math.min(max - 1, (int) Math.ceil(max * percent / 100.0));
        stack.setDamage(Math.max(stack.getDamage(), loss));
        return true;
    }

    private static void tickJester(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!isActive(p, Form.JESTER)) continue;
            if (t % 10 == 0) {
                p.getServerWorld().spawnParticles(ParticleTypes.END_ROD,
                        p.getX(), p.getY() + 1.0, p.getZ(), 2, 0.3, 0.6, 0.3, 0.01);
            }
            if (t % 20 == 0) {
                List<HandCard> hand = HANDS.get(p.getUuid());
                if (hand != null) hand.removeIf(h -> h.expires <= t);
            }
        }
        Iterator<PendingSound> it = PENDING.iterator();
        while (it.hasNext()) {
            PendingSound s = it.next();
            if (--s.delay > 0) continue;
            s.world.playSound(null, s.x, s.y, s.z, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                    SoundCategory.PLAYERS, 0.7f, s.pitch);
            it.remove();
        }
    }

    // ---------- Меха ----------

    public static final int METAL_MAX = 100;
    public static final int MECHA_FORM_TICKS = 40 * 20;
    private static final String METAL_PREFIX = "arcane_metal_";
    private static final int SLAM_COST = 30;
    private static final int SLAM_COOLDOWN_TICKS = 60;
    private static final double SLAM_RADIUS = 7.0;
    private static final int LASER_INTERVAL = 5;
    private static final int LASER_COST = 1;
    private static final double LASER_RANGE = 24.0;
    private static final int ULT_HOLD_TICKS = 60;
    private static final int ULT_MAX_TICKS = 160;
    private static final int ULT_COST = 5;
    private static final double ULT_RADIUS = 6.5;

    private static final DustParticleEffect LASER_DUST = new DustParticleEffect(new Vector3f(1.0f, 0.3f, 0.1f), 1.0f);
    private static final DustParticleEffect GOLD_DUST = new DustParticleEffect(new Vector3f(1.0f, 0.78f, 0.15f), 1.3f);

    private static final TagKey<Item> TAG_INGOTS = TagKey.of(RegistryKeys.ITEM, new Identifier("c", "ingots"));
    private static final TagKey<Item> TAG_NUGGETS = TagKey.of(RegistryKeys.ITEM, new Identifier("c", "nuggets"));
    private static final TagKey<Item> TAG_RAW = TagKey.of(RegistryKeys.ITEM, new Identifier("c", "raw_materials"));

    private static final Map<UUID, Integer> FORM_END = new HashMap<>();
    private static final Set<UUID> METAL_DIRTY = new HashSet<>();
    private static final Map<UUID, LaserState> LASERS = new HashMap<>();

    private static final class LaserState {
        int heldTicks = 0;
        boolean ultimate = false;
        int ultTicks = 0;
        Vec3d anchor = Vec3d.ZERO;
    }

    // --- шкала железа (хранится в тегах игрока, поэтому сохраняется) ---

    public static int getMetal(PlayerEntity p) {
        for (String tag : p.getCommandTags()) {
            if (tag.startsWith(METAL_PREFIX)) {
                try {
                    return Integer.parseInt(tag.substring(METAL_PREFIX.length()));
                } catch (NumberFormatException ignored) {
                    // битый тег пропускаем
                }
            }
        }
        return 0;
    }

    private static void clearMetal(ServerPlayerEntity p) {
        for (String tag : new ArrayList<>(p.getCommandTags())) {
            if (tag.startsWith(METAL_PREFIX)) p.removeScoreboardTag(tag);
        }
    }

    public static void setMetal(ServerPlayerEntity p, int value) {
        int v = Math.max(0, Math.min(METAL_MAX, value));
        clearMetal(p);
        p.addCommandTag(METAL_PREFIX + v);
        METAL_DIRTY.add(p.getUuid());
    }

    public static void addMetal(ServerPlayerEntity p, int amount) {
        setMetal(p, getMetal(p) + amount);
    }

    private static boolean spendMetal(ServerPlayerEntity p, int cost) {
        int m = getMetal(p);
        if (m < cost) return false;
        setMetal(p, m - cost);
        return true;
    }

    /** Сколько железа даёт предмет-металл (0 - не металл). */
    public static int metalValue(ItemStack s) {
        Item i = s.getItem();
        if (i == Items.IRON_INGOT) return 10;
        if (i == Items.IRON_NUGGET) return 1;
        if (i == Items.IRON_BLOCK) return 90;
        if (i == Items.RAW_IRON) return 6;
        if (i == Items.RAW_IRON_BLOCK) return 54;
        if (i == Items.GOLD_INGOT) return 12;
        if (i == Items.GOLD_NUGGET) return 1;
        if (i == Items.GOLD_BLOCK) return 100;
        if (i == Items.RAW_GOLD) return 7;
        if (i == Items.COPPER_INGOT) return 8;
        if (i == Items.COPPER_BLOCK) return 72;
        if (i == Items.RAW_COPPER) return 5;
        if (i == Items.NETHERITE_INGOT) return 40;
        if (i == Items.NETHERITE_SCRAP) return 15;
        if (s.isIn(TAG_INGOTS)) return 10;   // слитки из других модов
        if (s.isIn(TAG_NUGGETS)) return 1;
        if (s.isIn(TAG_RAW)) return 6;
        return 0;
    }

    public static void sendMecha(ServerPlayerEntity p) {
        boolean mecha = character(p) == Form.MECHA;
        int left = -1;
        if (mecha && isActive(p, Form.MECHA)) {
            Integer end = FORM_END.get(p.getUuid());
            if (end != null) left = Math.max(0, end - p.getServer().getTicks());
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(mecha ? getMetal(p) : -1);
        buf.writeInt(left);
        ServerPlayNetworking.send(p, Packets.MECHA, buf);
    }

    // --- удары и лучи ---

    /** Сильный удар по земле: отбрасывает всех вокруг и наносит урон. */
    private static void slam(ServerPlayerEntity p) {
        int now = p.getServer().getTicks();
        int until = ABILITY_COOLDOWN.getOrDefault(p.getUuid(), 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }
        if (!spendMetal(p, SLAM_COST)) {
            p.sendMessage(Text.translatable("message.arcane.no_metal"), true);
            return;
        }
        ABILITY_COOLDOWN.put(p.getUuid(), now + SLAM_COOLDOWN_TICKS);

        ServerWorld w = p.getServerWorld();
        float dmg = 10.0f + 6.0f * getMetal(p) / METAL_MAX;
        double r2 = SLAM_RADIUS * SLAM_RADIUS;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(SLAM_RADIUS, 2.0, SLAM_RADIUS),
                ent -> ent != p && ent.isAlive() && ent.squaredDistanceTo(p) <= r2)) {
            e.damage(p.getDamageSources().playerAttack(p), dmg);
            e.takeKnockback(1.7, p.getX() - e.getX(), p.getZ() - e.getZ());
            e.setVelocity(e.getVelocity().add(0, 0.5, 0));
            e.velocityModified = true;
        }

        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 0.2, p.getZ(), 1, 0, 0, 0, 0);
        BlockState floor = w.getBlockState(p.getBlockPos().down());
        if (!floor.isAir()) {
            w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, floor),
                    p.getX(), p.getY() + 0.3, p.getZ(), 120, SLAM_RADIUS * 0.4, 0.2, SLAM_RADIUS * 0.4, 0.3);
        }
        w.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 60, 3.0, 0.1, 3.0, 0.25);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.2f, 0.7f);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_DAMAGE, SoundCategory.PLAYERS, 1.5f, 0.5f);
    }

    /** Клавиша лучей: нажата - лучи из рук, удержание 3 секунды - золотой ливень. */
    public static void handleLaserKey(ServerPlayerEntity p, boolean pressed) {
        if (isActive(p, Form.ZET)) {
            ZetAbilities.gKey(p, pressed);
            return;
        }
        if (!pressed) ZetAbilities.gKey(p, false);
        if (pressed) {
            if (!isActive(p, Form.MECHA)) return;
            if (getMetal(p) <= 0) {
                p.sendMessage(Text.translatable("message.arcane.no_metal"), true);
                return;
            }
            LASERS.put(p.getUuid(), new LaserState());
        } else {
            LASERS.remove(p.getUuid());
        }
    }

    private static void fireLaser(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d dir = p.getRotationVec(1.0f).normalize();
        Vec3d start = p.getEyePos().add(0, -0.35, 0);
        HitResult hit = p.raycast(LASER_RANGE, 1.0f, false);
        double len = hit.getType() == HitResult.Type.MISS
                ? LASER_RANGE
                : Math.max(1.0, p.getEyePos().distanceTo(hit.getPos()));

        for (double d = 0.8; d <= len; d += 0.6) {
            Vec3d pt = start.add(dir.multiply(d));
            w.spawnParticles(LASER_DUST, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, start.x + dir.x, start.y, start.z + dir.z, 3, 0.1, 0.1, 0.1, 0.05);
        damageAlong(p, start, dir, len, 0.9, 3.0f + 3.0f * getMetal(p) / METAL_MAX, 2);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 0.5f, 2.0f);
    }

    /** Урон всем живым существам вдоль луча (кроме самого игрока). */
    private static void damageAlong(ServerPlayerEntity p, Vec3d start, Vec3d dir, double len,
                                    double radius, float dmg, int fireSeconds) {
        ServerWorld w = p.getServerWorld();
        Vec3d end = start.add(dir.multiply(len));
        Box box = new Box(start, end).expand(radius + 0.5);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, ent -> ent != p && ent.isAlive())) {
            Vec3d c = e.getBoundingBox().getCenter();
            double t = Math.max(0.0, Math.min(len, c.subtract(start).dotProduct(dir)));
            Vec3d closest = start.add(dir.multiply(t));
            if (c.distanceTo(closest) > radius + e.getWidth() * 0.5) continue;
            e.damage(p.getDamageSources().playerAttack(p), dmg);
            if (fireSeconds > 0) e.setOnFireFor(fireSeconds);
        }
    }

    /** Золотой ливень: огонь льётся там, где ты стоял, а из тела бьют золотые молнии. Блоки не горят. */
    private static void ultimateTick(ServerPlayerEntity p, LaserState s) {
        ServerWorld w = p.getServerWorld();
        Vec3d a = s.anchor;

        w.spawnParticles(ParticleTypes.FALLING_LAVA, a.x, a.y + 7.0, a.z, 25, 4.0, 0.5, 4.0, 0.0);
        w.spawnParticles(ParticleTypes.FLAME, a.x, a.y + 3.0, a.z, 20, 4.0, 2.5, 4.0, 0.02);
        w.spawnParticles(ParticleTypes.LAVA, a.x, a.y + 0.3, a.z, 3, 4.0, 0.2, 4.0, 0.0);

        if (s.ultTicks % 10 == 0) {
            double r2 = ULT_RADIUS * ULT_RADIUS;
            Box area = new Box(a.x - ULT_RADIUS, a.y - 2.0, a.z - ULT_RADIUS, a.x + ULT_RADIUS, a.y + 8.0, a.z + ULT_RADIUS);
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, area,
                    ent -> ent != p && ent.isAlive()
                            && (ent.getX() - a.x) * (ent.getX() - a.x) + (ent.getZ() - a.z) * (ent.getZ() - a.z) <= r2)) {
                e.damage(p.getDamageSources().playerAttack(p), 6.0f + 4.0f * getMetal(p) / METAL_MAX);
                e.setOnFireFor(4);
            }
        }

        if (s.ultTicks % 4 == 0) {
            Vec3d origin = p.getPos().add(0, 1.0, 0);
            boolean hurt = s.ultTicks % 8 == 0;
            for (int i = 0; i < 6; i++) {
                Vec3d d = new Vec3d(p.getRandom().nextGaussian(), p.getRandom().nextGaussian() * 0.5, p.getRandom().nextGaussian());
                if (d.lengthSquared() < 1.0E-4) continue;
                d = d.normalize();
                double len = 8.0;
                for (double k = 0.5; k <= len; k += 0.5) {
                    Vec3d pt = origin.add(d.multiply(k));
                    w.spawnParticles(GOLD_DUST, pt.x, pt.y, pt.z, 1, 0.05, 0.05, 0.05, 0);
                    if (k % 2.0 == 0) w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0.1, 0.1, 0.1, 0.02);
                }
                if (hurt) damageAlong(p, origin, d, len, 0.8, 5.0f + 3.0f * getMetal(p) / METAL_MAX, 0);
            }
        }
        if (s.ultTicks % 20 == 0) {
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.4f, 1.8f);
        }
    }

    private static void tickLasers(MinecraftServer server) {
        Iterator<Map.Entry<UUID, LaserState>> it = LASERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, LaserState> e = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(e.getKey());
            if (p == null || !p.isAlive() || !isActive(p, Form.MECHA)) {
                it.remove();
                continue;
            }
            LaserState s = e.getValue();

            if (!s.ultimate) {
                s.heldTicks++;
                if (s.heldTicks % LASER_INTERVAL == 1) {
                    if (!spendMetal(p, LASER_COST)) {
                        it.remove();
                        continue;
                    }
                    fireLaser(p);
                }
                if (s.heldTicks >= ULT_HOLD_TICKS) {
                    s.ultimate = true;
                    s.anchor = p.getPos();
                    p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                            SoundCategory.PLAYERS, 1.0f, 1.4f);
                    p.sendMessage(Text.translatable("message.arcane.ultimate"), true);
                }
            } else {
                s.ultTicks++;
                ultimateTick(p, s);
                if (s.ultTicks % 10 == 0 && !spendMetal(p, ULT_COST)) {
                    it.remove();
                    continue;
                }
                if (s.ultTicks >= ULT_MAX_TICKS) it.remove();
            }
        }
    }

    // --- Меха Полдень: предмет «прилипает» к игроку, как только окажется в инвентаре ---

    private static void scanForNoon(ServerPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(ModItems.MECHA_NOON)) {
                inv.setStack(i, ItemStack.EMPTY);
                if (character(p) == Form.MECHA) {
                    addMetal(p, 40);
                } else {
                    setCharacter(p, Form.MECHA);
                    setMetal(p, Math.max(getMetal(p), 60));
                    activate(p, Form.MECHA);
                }
                p.sendMessage(Text.translatable("message.arcane.noon_fused"), false);
                return;
            }
        }
    }

    private static void tickMecha(MinecraftServer server, int t) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (t % 10 == 0) scanForNoon(p);
            if (character(p) != Form.MECHA) continue;
            UUID id = p.getUuid();

            // без пополнения железо очень медленно тратится само
            if (t % 200 == 0 && getMetal(p) > 0) setMetal(p, getMetal(p) - 1);

            if (isActive(p, Form.MECHA)) {
                Integer end = FORM_END.get(id);
                if (end != null && t >= end) {
                    COOLDOWN_UNTIL.put(id, t + COOLDOWN_TICKS);
                    deactivate(p, true);
                } else if (end != null && t % 10 == 0) {
                    double progress = 1.0 - (end - t) / (double) MECHA_FORM_TICKS;
                    p.getServerWorld().spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                            p.getX(), p.getY() + 1.0, p.getZ(), 2 + (int) (4.0 * progress), 0.4, 0.8, 0.4, 0.05);
                }
            }
            if (METAL_DIRTY.remove(id) || t % 20 == 0) sendMecha(p);
        }
        tickLasers(server);
    }

    // ---------- способность Эйро: бросок блока ----------

    public static final int THROW_COOLDOWN_TICKS = 6 * 20;
    private static final double THROW_REACH = 6.0;
    private static final float THROW_DAMAGE = 10.0f;
    private static final Map<UUID, Integer> ABILITY_COOLDOWN = new HashMap<>();
    private static final List<Thrown> THROWN = new ArrayList<>();

    private static final class Thrown {
        final FallingBlockEntity entity;
        final ServerWorld world;
        final UUID thrower;
        int age = 0;

        Thrown(FallingBlockEntity entity, ServerWorld world, UUID thrower) {
            this.entity = entity;
            this.world = world;
            this.thrower = thrower;
        }
    }

    /** Нажатие клавиши способности. Эйро хватает блок, на который смотрит, и швыряет его вперёд. */
    public static void useAbility(ServerPlayerEntity p, boolean pressed) {
        Form current = active(p);
        if (current == Form.ZET) {
            ZetAbilities.screamKey(p, pressed);
            return;
        }
        if (!pressed) return;
        if (current == Form.MECHA) {
            slam(p);
            return;
        }
        if (current != Form.EIRO) {
            p.sendMessage(Text.translatable("message.arcane.ability_eiro_only"), true);
            return;
        }
        int now = p.getServer().getTicks();
        int until = ABILITY_COOLDOWN.getOrDefault(p.getUuid(), 0);
        if (now < until) {
            p.sendMessage(Text.translatable("message.arcane.ability_cooldown", (until - now + 19) / 20), true);
            return;
        }

        ServerWorld w = p.getServerWorld();
        HitResult hit = p.raycast(THROW_REACH, 1.0f, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            p.sendMessage(Text.translatable("message.arcane.no_block"), true);
            return;
        }
        BlockPos pos = ((BlockHitResult) hit).getBlockPos();
        BlockState state = w.getBlockState(pos);
        if (state.isAir() || state.getHardness(w, pos) < 0 || w.getBlockEntity(pos) != null
                || !state.getFluidState().isEmpty()) {
            p.sendMessage(Text.translatable("message.arcane.bad_block"), true);
            return;
        }

        // блок убирается из мира и становится летящим блоком
        FallingBlockEntity fb = FallingBlockEntity.spawnFromBlock(w, pos, state);
        Vec3d look = p.getRotationVec(1.0f).normalize();
        Vec3d start = p.getEyePos().add(look.multiply(1.6)).add(0, -0.4, 0);
        fb.setPosition(start.x, start.y, start.z);
        fb.setVelocity(look.multiply(2.0));
        fb.velocityModified = true;

        THROWN.add(new Thrown(fb, w, p.getUuid()));
        ABILITY_COOLDOWN.put(p.getUuid(), now + THROW_COOLDOWN_TICKS);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_RAVAGER_ATTACK, SoundCategory.PLAYERS, 1.2f, 0.7f);
    }

    /** Следит за летящими блоками: попадание в существо = урон, поджог и раскол блока. */
    private static void tickThrown() {
        Iterator<Thrown> it = THROWN.iterator();
        while (it.hasNext()) {
            Thrown t = it.next();
            FallingBlockEntity fb = t.entity;
            if (fb.isRemoved() || fb.isOnGround() || ++t.age > 200) {
                it.remove();
                continue;
            }
            ServerWorld w = t.world;
            w.spawnParticles(ParticleTypes.FLAME, fb.getX(), fb.getY() + 0.5, fb.getZ(), 3, 0.2, 0.2, 0.2, 0.01);

            List<LivingEntity> hits = w.getEntitiesByClass(LivingEntity.class, fb.getBoundingBox().expand(0.4),
                    e -> e.isAlive() && !e.getUuid().equals(t.thrower));
            if (hits.isEmpty()) continue;

            ServerPlayerEntity thrower = w.getServer().getPlayerManager().getPlayer(t.thrower);
            DamageSource src = thrower != null
                    ? thrower.getDamageSources().playerAttack(thrower)
                    : w.getDamageSources().generic();
            Vec3d dir = fb.getVelocity().normalize();
            for (LivingEntity e : hits) {
                e.damage(src, THROW_DAMAGE);
                e.takeKnockback(0.8, -dir.x, -dir.z);
                e.setOnFireFor(4);
            }
            w.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, fb.getBlockState()),
                    fb.getX(), fb.getY() + 0.5, fb.getZ(), 40, 0.4, 0.4, 0.4, 0.15);
            w.spawnParticles(ParticleTypes.EXPLOSION, fb.getX(), fb.getY() + 0.5, fb.getZ(), 1, 0, 0, 0, 0);
            w.playSound(null, fb.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8f, 1.3f);
            fb.discard();
            it.remove();
        }
    }

    // ---------- синхронизация с клиентами ----------

    /** Номер формы для клиентов: улучшенный Саир (шляпа Дэву) передаётся как 5. */
    private static int syncId(PlayerEntity p) {
        Form a = active(p);
        if (a == Form.SAIR && SairUpgrade.isUpgraded(p)) return 5;
        return a.id;
    }

    private static void sendSync(ServerPlayerEntity to, UUID who, int form) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(who);
        buf.writeInt(form);
        ServerPlayNetworking.send(to, Packets.SYNC, buf);
    }

    public static void broadcast(MinecraftServer server, ServerPlayerEntity p) {
        int form = syncId(p);
        for (ServerPlayerEntity to : server.getPlayerManager().getPlayerList()) {
            sendSync(to, p.getUuid(), form);
        }
    }

    public static void syncAllTo(MinecraftServer server, ServerPlayerEntity joiner) {
        for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
            sendSync(joiner, o.getUuid(), syncId(o));
        }
    }

    // ---------- способность Саира ----------

    /**
     * Разрез воздуха: поражает всех в конусе перед игроком.
     * @param exclude цель, которую не нужно бить повторно (при обычном ударе), или null
     */
    public static void airSlash(ServerPlayerEntity p, double range, float damage, net.minecraft.entity.Entity exclude) {
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f).normalize();

        Box box = p.getBoundingBox().stretch(look.multiply(range)).expand(range * 0.5, 1.5, range * 0.5);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, x -> x != p && x != exclude && x.isAlive())) {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) continue;
            if (to.normalize().dotProduct(look) < 0.6) continue;
            e.damage(p.getDamageSources().playerAttack(p), damage);
            e.takeKnockback(0.5, -look.x, -look.z);
        }

        for (int i = 1; i <= (int) range; i++) {
            Vec3d pt = eye.add(look.multiply(i));
            w.spawnParticles(ParticleTypes.SWEEP_ATTACK, pt.x, pt.y - 0.3, pt.z, 1, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.CRIT, pt.x, pt.y - 0.3, pt.z, 3, 0.3, 0.3, 0.3, 0.1);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.2f, 1.3f);
    }
}

package com.arcane.client;

import com.arcane.ArcaneMod;
import com.arcane.ModEntities;
import com.arcane.Packets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public class ArcaneClient implements ClientModInitializer {
    public static final EntityModelLayer SAIR_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume"), "main");
    public static final EntityModelLayer EIRO_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "eiro_overlay"), "main");
    // варианты для скинов с тонкими руками (Alex)
    public static final EntityModelLayer SAIR_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_slim"), "main");
    public static final EntityModelLayer EIRO_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "eiro_overlay_slim"), "main");
    public static final EntityModelLayer JESTER_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "jester_glow"), "main");
    public static final EntityModelLayer JESTER_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "jester_glow_slim"), "main");
    public static final EntityModelLayer SAIR_UP_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_up"), "main");
    public static final EntityModelLayer SAIR_UP_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "sair_costume_up_slim"), "main");
    public static final EntityModelLayer MECHA_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "mecha_plating"), "main");
    public static final EntityModelLayer MECHA_SLIM_LAYER =
            new EntityModelLayer(new Identifier(ArcaneMod.MOD_ID, "mecha_plating_slim"), "main");

    private static KeyBinding transformKey;
    private static KeyBinding abilityKey;
    private static KeyBinding laserKey;
    private static boolean laserDown = false;
    private static boolean abilityDown = false;
    private static KeyBinding slashKey;
    private static KeyBinding challengeKey;
    private static boolean slashDown = false;

    @Override
    public void onInitializeClient() {
        // Клавиша превращения (по умолчанию левый Alt, меняется в настройках управления)
        transformKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.transform", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "key.categories.arcane"));

        // Клавиша способности: бросок блока (по умолчанию R)
        abilityKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.ability", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.arcane"));

        // Клавиша лучей Меха (удерживать, по умолчанию G)
        laserKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.laser", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.arcane"));

        // Улучшенный Саир: V - "Разрез" (удерживать - ещё и вертикальный удар), C - "Вызов" (дуэль)
        slashKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.slash", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.arcane"));
        challengeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arcane.challenge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.arcane"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            abilityDown = pollKey(abilityKey, abilityDown, Packets.ABILITY, client);
            while (transformKey.wasPressed()) {
                if (client.player != null) {
                    ClientPlayNetworking.send(Packets.TOGGLE, PacketByteBufs.create());
                }
            }
            VoiceHud.tick();
            CardHud.tick();
            MechaHud.tick();
            ClientForms.tick();

            boolean slash = slashKey.isPressed() && client.player != null && client.currentScreen == null;
            if (slash != slashDown) {
                slashDown = slash;
                PacketByteBuf sb = PacketByteBufs.create();
                sb.writeBoolean(slash);
                ClientPlayNetworking.send(Packets.SLASH, sb);
            }
            while (challengeKey.wasPressed()) {
                if (client.player != null) ClientPlayNetworking.send(Packets.CHALLENGE, PacketByteBufs.create());
            }

            laserDown = pollKey(laserKey, laserDown, Packets.LASER, client);
        });

        // Данные от сервера
        ClientPlayNetworking.registerGlobalReceiver(Packets.SYNC, (client, handler, buf, sender) -> {
            UUID id = buf.readUuid();
            int form = buf.readInt();
            client.execute(() -> ClientForms.set(id, form));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.VOICE, (client, handler, buf, sender) -> {
            int index = buf.readInt();
            client.execute(() -> VoiceHud.show(index));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.CARDS, (client, handler, buf, sender) -> {
            boolean fresh = buf.readBoolean();
            int n = buf.readInt();
            int[] ids = new int[n];
            int[] ticks = new int[n];
            for (int i = 0; i < n; i++) {
                ids[i] = buf.readInt();
                ticks[i] = buf.readInt();
            }
            client.execute(() -> CardHud.setHand(fresh, ids, ticks));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.MECHA, (client, handler, buf, sender) -> {
            int metal = buf.readInt();
            int formTicks = buf.readInt();
            client.execute(() -> MechaHud.set(metal, formTicks));
        });
        ClientPlayNetworking.registerGlobalReceiver(Packets.DUEL, (client, handler, buf, sender) -> {
            int wins = buf.readInt();
            int guard = buf.readInt();
            boolean duel = buf.readBoolean();
            client.execute(() -> DuelHud.set(wins, guard, duel));
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            DuelHud.clear();
            slashDown = false;
            ClientForms.clear();
            CardHud.clear();
            MechaHud.clear();
            laserDown = false;
            abilityDown = false;
        });

        // Модели костюма и кожи
        EntityModelLayerRegistry.registerModelLayer(SAIR_LAYER, () -> createSairLayer(false));
        EntityModelLayerRegistry.registerModelLayer(SAIR_SLIM_LAYER, () -> createSairLayer(true));
        EntityModelLayerRegistry.registerModelLayer(EIRO_LAYER, () -> createEiroLayer(false));
        EntityModelLayerRegistry.registerModelLayer(EIRO_SLIM_LAYER, () -> createEiroLayer(true));
        EntityModelLayerRegistry.registerModelLayer(JESTER_LAYER, () -> createJesterLayer(false));
        EntityModelLayerRegistry.registerModelLayer(JESTER_SLIM_LAYER, () -> createJesterLayer(true));
        EntityModelLayerRegistry.registerModelLayer(SAIR_UP_LAYER, () -> createSairUpLayer(false));
        EntityModelLayerRegistry.registerModelLayer(SAIR_UP_SLIM_LAYER, () -> createSairUpLayer(true));
        EntityRendererRegistry.register(ModEntities.DUELIST, DuelistRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(MECHA_LAYER, () -> createMechaLayer(false));
        EntityModelLayerRegistry.registerModelLayer(MECHA_SLIM_LAYER, () -> createMechaLayer(true));

        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer pr) {
                helper.register(new FormFeatureRenderer(pr, context.getModelLoader()));
            }
        });

        HudRenderCallback.EVENT.register(VoiceHud::render);
        HudRenderCallback.EVENT.register(CardHud::render);
        HudRenderCallback.EVENT.register(MechaHud::render);
        HudRenderCallback.EVENT.register(DuelHud::render);
    }

    /** Костюм Саира: "одежда" чуть больше тела + высокая плетёная шляпа вместо головы. Текстура 128x64. */
    private static TexturedModelData createSairLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.3f), slim);
        data.getRoot().addChild("hat",
                ModelPartBuilder.create().uv(64, 0)
                        .cuboid(-5.0f, -11.0f, -5.0f, 10.0f, 12.0f, 10.0f, new Dilation(0.0f)),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 64);
    }

    /**
     * Следит за клавишей и шлёт серверу true при нажатии и false при отпускании.
     * Очень быстрый тап (короче такта) тоже не теряется.
     */
    private static boolean pollKey(KeyBinding key, boolean wasDown, Identifier packetId, MinecraftClient client) {
        boolean tapped = false;
        while (key.wasPressed()) tapped = true;
        boolean down = key.isPressed() && client.player != null && client.currentScreen == null;
        if (tapped && !down && !wasDown) {
            sendKey(packetId, true);
            sendKey(packetId, false);
        } else if (down != wasDown) {
            sendKey(packetId, down);
        }
        return down;
    }

    private static void sendKey(Identifier packetId, boolean pressed) {
        PacketByteBuf b = PacketByteBufs.create();
        b.writeBoolean(pressed);
        ClientPlayNetworking.send(packetId, b);
    }

    /** Улучшенный Саир: вместо высокой шляпы широкая японская шляпа Дэву (4 ступени). Текстура 128x64. */
    private static TexturedModelData createSairUpLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.3f), slim);
        data.getRoot().addChild("hat",
                ModelPartBuilder.create()
                        .uv(64, 24).cuboid(-7.0f, -8.0f, -7.0f, 14.0f, 1.0f, 14.0f)
                        .uv(64, 42).cuboid(-5.0f, -10.0f, -5.0f, 10.0f, 2.0f, 10.0f)
                        .uv(64, 55).cuboid(-3.0f, -12.0f, -3.0f, 6.0f, 2.0f, 6.0f)
                        .uv(92, 55).cuboid(-1.0f, -13.0f, -1.0f, 2.0f, 1.0f, 2.0f),
                ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 64);
    }

    /** Стальная броня Меха и золотые трещины (одна модель, две текстуры). Текстуры 64x64. */
    private static TexturedModelData createMechaLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.28f), slim);
        return TexturedModelData.of(data, 64, 64);
    }

    /** Золотое свечение Шута: тонкий слой чуть шире тела. Текстура 64x64. */
    private static TexturedModelData createJesterLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.12f), slim);
        return TexturedModelData.of(data, 64, 64);
    }

    /** Кожа Эйро: тонкий слой почти вплотную к телу. Текстура 64x64. */
    private static TexturedModelData createEiroLayer(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(new Dilation(0.08f), slim);
        return TexturedModelData.of(data, 64, 64);
    }
}

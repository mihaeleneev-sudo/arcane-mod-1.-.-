package com.arcane;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.UUID;

/**
 * Раздор - первый из "Всадников тьмы". Горбатый НПС, который ходит рядом с хозяином,
 * бьёт ближайших врагов и далеко от него не отходит. Умениями им управляет владелец (см. {@link Discord}).
 * Не сохраняется в мире: если игрок вышел, Раздор исчезает, а при следующем входе его снова зовут по Alt.
 */
public class DiscordEntity extends PathAwareEntity {
    /** Хозяин (игрок с проклятием). */
    public UUID owner;
    /** Команда "Каннибализм": подойти к хозяину и укусить. */
    public boolean wantsBite = false;
    public int biteTimeout = 0;

    public DiscordEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 0;
        this.setCustomNameVisible(true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createDiscordAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.38)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.4);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new BiteOwnerGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.3, false));
        this.goalSelector.add(5, new StayNearOwnerGoal(this));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new WanderAroundGoal(this, 0.7));
        this.goalSelector.add(8, new LookAroundGoal(this));
        // ближайшие враждебные мобы рядом с хозяином
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, LivingEntity.class, 5, true, false,
                e -> e instanceof Monster && !(e instanceof DiscordEntity) && nearOwner(e, 14.0)));
    }

    private boolean nearOwner(LivingEntity e, double radius) {
        ServerPlayerEntity o = ownerPlayer();
        return o != null && e.squaredDistanceTo(o) <= radius * radius;
    }

    public ServerPlayerEntity ownerPlayer() {
        MinecraftServer s = this.getServer();
        if (s == null || owner == null) return null;
        return s.getPlayerManager().getPlayer(owner);
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        ServerPlayerEntity o = ownerPlayer();
        if (o == null || !o.isAlive()) {
            this.discard();
            return;
        }
        if (biteTimeout > 0 && --biteTimeout == 0) wantsBite = false;

        // далеко не отходит: слишком далёкую цель бросает
        LivingEntity tgt = this.getTarget();
        if (tgt != null && (!tgt.isAlive() || tgt.squaredDistanceTo(o) > 18.0 * 18.0)) {
            this.setTarget(null);
            tgt = null;
        }
        // защищает хозяина от того, кто его ударил
        if (tgt == null && this.age % 10 == 0) {
            LivingEntity att = o.getAttacker();
            if (att != null && att.isAlive() && att != o && !(att instanceof DiscordEntity)
                    && att.squaredDistanceTo(o) < 100.0) {
                this.setTarget(att);
            }
        }
    }

    /** Хозяин не может ранить своего Раздора. */
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (owner != null && source.getAttacker() instanceof PlayerEntity pl && pl.getUuid().equals(owner)) return false;
        return super.damage(source, amount);
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        Discord.onEntityDied(this);
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        Discord.onEntityRemoved(this);
    }

    /** В чанк не записывается: исчезает вместе с выходом хозяина. */
    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_PLAYER_DEATH;
    }

    // ---------- цели ----------

    /** Держится рядом с хозяином: если отстал, догоняет, если очень далеко - телепортируется. */
    private static final class StayNearOwnerGoal extends Goal {
        private final DiscordEntity mob;

        StayNearOwnerGoal(DiscordEntity mob) {
            this.mob = mob;
            this.setControls(EnumSet.of(Goal.Control.MOVE));
        }

        @Override
        public boolean canStart() {
            ServerPlayerEntity o = mob.ownerPlayer();
            return o != null && mob.getTarget() == null && mob.squaredDistanceTo(o) > 36.0;
        }

        @Override
        public boolean shouldContinue() {
            ServerPlayerEntity o = mob.ownerPlayer();
            return o != null && mob.getTarget() == null && !mob.getNavigation().isIdle() && mob.squaredDistanceTo(o) > 9.0;
        }

        @Override
        public void start() {
            ServerPlayerEntity o = mob.ownerPlayer();
            if (o != null) mob.getNavigation().startMovingTo(o, 1.3);
        }

        @Override
        public void tick() {
            ServerPlayerEntity o = mob.ownerPlayer();
            if (o == null) return;
            if (mob.squaredDistanceTo(o) > 24.0 * 24.0) {
                mob.requestTeleport(o.getX(), o.getY(), o.getZ());
            } else {
                mob.getNavigation().startMovingTo(o, 1.3);
            }
        }
    }

    /** "Каннибализм": подбежать к хозяину и откусить часть его здоровья. */
    private static final class BiteOwnerGoal extends Goal {
        private final DiscordEntity mob;

        BiteOwnerGoal(DiscordEntity mob) {
            this.mob = mob;
            this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
        }

        @Override
        public boolean canStart() {
            return mob.wantsBite && mob.ownerPlayer() != null;
        }

        @Override
        public boolean shouldContinue() {
            return mob.wantsBite && mob.ownerPlayer() != null;
        }

        @Override
        public void tick() {
            ServerPlayerEntity o = mob.ownerPlayer();
            if (o == null) {
                mob.wantsBite = false;
                return;
            }
            mob.getLookControl().lookAt(o, 30.0f, 30.0f);
            mob.getNavigation().startMovingTo(o, 1.5);
            if (mob.squaredDistanceTo(o) < 3.0 * 3.0) {
                mob.wantsBite = false;
                Discord.onBite(o, mob);
            }
        }
    }
}

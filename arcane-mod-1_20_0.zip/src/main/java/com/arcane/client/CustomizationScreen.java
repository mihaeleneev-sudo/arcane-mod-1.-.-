package com.arcane.client;

import com.arcane.Cosmetics;
import com.arcane.CraftCatalog;
import com.arcane.Form;
import com.arcane.ModItems;
import com.arcane.Packets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Меню кастомизации (клавиша B). Две вкладки:
 * 1) "Крафты" - рецепты предметов персонажей, с кнопкой крафта из инвентаря;
 * 2) "Кастомизация" - аксессуары персонажа (маска на лицо и т.п.) и предпросмотр.
 */
public class CustomizationScreen extends Screen {
    private static final int W = 420;
    private static final int H = 262;
    private static final Form[] CHARACTERS = {Form.SAIR, Form.EIRO, Form.JESTER, Form.MECHA, Form.ZET,
            Form.HUNTER, Form.KING, Form.ZEUS, Form.FOVIUS};
    private static final int PER_PAGE = 7;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_DIM = 0xFFA0A0A8;
    private static final int COLOR_GOLD = 0xFFFFD060;

    private int left;
    private int top;
    private int tab = 0;        // 0 - крафты, 1 - кастомизация
    private int page = 0;
    private int selected = 0;
    private Form selChar = null;   // выбранный в сетке персонаж

    // ячейки предметов, над которыми можно показать подсказку (заполняется при рисовании)
    private final List<int[]> hoverBoxes = new ArrayList<>();
    private final List<ItemStack> hoverStacks = new ArrayList<>();

    public CustomizationScreen() {
        super(Text.translatable("screen.arcane.customize.title"));
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = (this.height - H) / 2;
        build();
        sendAction(0, "");   // запрос актуального состояния у сервера
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Пришли новые данные от сервера. */
    public void refresh() {
        build();
    }

    private static void sendAction(int action, String arg) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(action);
        buf.writeString(arg);
        ClientPlayNetworking.send(Packets.COSMETIC_ACTION, buf);
    }

    // ---------- кнопки ----------

    private void build() {
        this.clearChildren();

        this.addDrawableChild(tabButton(0, "screen.arcane.tab.crafts", left + 10));
        this.addDrawableChild(tabButton(1, "screen.arcane.tab.cosmetics", left + 10 + 150));

        if (tab == 0) buildCrafts();
        else buildCosmetics();

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), b -> this.close())
                .dimensions(left + W - 70, top + H - 26, 60, 20).build());
    }

    private ButtonWidget tabButton(int index, String langKey, int x) {
        ButtonWidget b = ButtonWidget.builder(Text.translatable(langKey), btn -> {
            tab = index;
            page = 0;
            selected = 0;
            build();
        }).dimensions(x, top + 8, 140, 20).build();
        b.active = tab != index;
        return b;
    }

    private void buildCrafts() {
        List<CraftCatalog.Entry> entries = CraftCatalog.ENTRIES;
        int pages = Math.max(1, (entries.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < PER_PAGE; i++) {
            int index = page * PER_PAGE + i;
            if (index >= entries.size()) break;
            CraftCatalog.Entry en = entries.get(index);
            Text label = new ItemStack(en.result()).getName();
            ButtonWidget b = ButtonWidget.builder(label, btn -> {
                selected = index;
                build();
            }).dimensions(left + 10, top + 36 + i * 22, 135, 20).build();
            b.active = index != selected;
            this.addDrawableChild(b);
        }

        if (pages > 1) {
            ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> {
                page--;
                build();
            }).dimensions(left + 10, top + H - 26, 30, 20).build();
            prev.active = page > 0;
            this.addDrawableChild(prev);
            ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> {
                page++;
                build();
            }).dimensions(left + 115, top + H - 26, 30, 20).build();
            next.active = page < pages - 1;
            this.addDrawableChild(next);
        }

        if (selected >= 0 && selected < entries.size()) {
            CraftCatalog.Entry en = entries.get(selected);
            Recipe<?> recipe = findRecipe(en);
            ButtonWidget craft = ButtonWidget.builder(Text.translatable("screen.arcane.craft"),
                    b -> sendAction(3, en.recipe)).dimensions(left + 160, top + H - 52, 100, 20).build();
            craft.active = recipe != null && this.client != null && this.client.player != null
                    && CraftCatalog.canCraft(this.client.player, recipe);
            this.addDrawableChild(craft);
        }
    }

    private void buildCosmetics() {
        Form sel = selectedForm();
        int row = 0;
        for (Cosmetics.Def def : Cosmetics.ALL) {
            if (def.form != sel) continue;
            boolean owned = ClientCosmetics.owns(def.id);
            boolean worn = ClientCosmetics.worn(def.id);
            Text label = Text.translatable(worn ? "screen.arcane.unequip" : (owned ? "screen.arcane.equip" : "screen.arcane.locked"));
            ButtonWidget b = ButtonWidget.builder(label, btn -> sendAction(worn ? 2 : 1, def.id))
                    .dimensions(RIGHT_X(), top + 82 + row * 46 + 22, 124, 18).build();
            b.active = owned;
            this.addDrawableChild(b);
            row++;
            if (row >= 3) break;
        }
    }

    private int RIGHT_X() { return left + 286; }

    /** Слот аксессуара выбранного персонажа (у Эйро - "Лицо", у Хантера - "Голова"). */
    private static Cosmetics.Slot slotFor(Form f) {
        for (Cosmetics.Def d : Cosmetics.ALL) {
            if (d.form == f) return d.slot;
        }
        return Cosmetics.Slot.FACE;
    }

    /** Выбранный в сетке персонаж (по умолчанию - свой, а если силы нет - первый в списке). */
    private Form selectedForm() {
        if (selChar != null) return selChar;
        Form own = formByKey(ClientCosmetics.character());
        return own != null ? own : CHARACTERS[0];
    }

    private static Form formByKey(String key) {
        for (Form f : CHARACTERS) if (f.key.equals(key)) return f;
        return null;
    }

    private static Item iconOf(Form f) {
        return switch (f) {
            case SAIR -> ModItems.SAIR_KATANA;
            case EIRO -> ModItems.EIRO_HEART;
            case JESTER -> ModItems.FOOL_CARD;
            case MECHA -> ModItems.MECHA_NOON;
            case ZET -> ModItems.ZET_ESSENCE;
            case HUNTER -> ModItems.HUNTER_LICENSE;
            case KING -> ModItems.KING_CROWN;
            case ZEUS -> ModItems.ZEUS_VEST;
            case FOVIUS -> ModItems.COFFIN_OF_REVENGE;
            default -> ModItems.ARCANE_SHARD;
        };
    }

    private int cellX(int i) { return left + 10 + (i % 3) * 54; }

    private int cellY(int i) { return top + 46 + (i / 3) * 54; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (tab == 1 && button == 0) {
            for (int i = 0; i < CHARACTERS.length; i++) {
                int x = cellX(i);
                int y = cellY(i);
                if (mouseX >= x && mouseX < x + 50 && mouseY >= y && mouseY < y + 50) {
                    selChar = CHARACTERS[i];
                    build();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private Recipe<?> findRecipe(CraftCatalog.Entry en) {
        if (this.client == null || this.client.world == null) return null;
        Optional<? extends Recipe<?>> opt = this.client.world.getRecipeManager().get(en.recipeId());
        return opt.isPresent() ? opt.get() : null;
    }

    // ---------- рисование ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx);
        ctx.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF555560);
        ctx.fill(left, top, left + W, top + H, 0xF0101018);

        hoverBoxes.clear();
        hoverStacks.clear();

        if (tab == 0) renderCrafts(ctx);
        else renderCosmetics(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);

        for (int i = 0; i < hoverBoxes.size(); i++) {
            int[] r = hoverBoxes.get(i);
            if (mouseX >= r[0] && mouseX < r[0] + r[2] && mouseY >= r[1] && mouseY < r[1] + r[3]) {
                ctx.drawItemTooltip(this.textRenderer, hoverStacks.get(i), mouseX, mouseY);
                break;
            }
        }
    }

    private void slotBox(DrawContext ctx, int x, int y, ItemStack stack) {
        ctx.fill(x, y, x + 18, y + 18, 0xFF303038);
        ctx.fill(x + 1, y + 1, x + 17, y + 17, 0xFF1A1A22);
        if (stack != null && !stack.isEmpty()) {
            ctx.drawItem(stack, x + 1, y + 1);
            hoverBoxes.add(new int[]{x, y, 18, 18});
            hoverStacks.add(stack);
        }
    }

    private void renderCrafts(DrawContext ctx) {
        List<CraftCatalog.Entry> entries = CraftCatalog.ENTRIES;
        if (selected < 0 || selected >= entries.size()) return;
        CraftCatalog.Entry en = entries.get(selected);
        ItemStack result = new ItemStack(en.result());

        int x0 = left + 160;
        ctx.drawText(this.textRenderer, result.getName(), x0, top + 38, COLOR_GOLD, false);
        ctx.drawText(this.textRenderer,
                Text.translatable("screen.arcane.craft.for", Text.translatable("character.arcane." + en.form.key)),
                x0, top + 50, COLOR_DIM, false);

        Recipe<?> recipe = findRecipe(en);
        if (recipe == null) {
            ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.craft.no_recipe"), x0, top + 80, COLOR_DIM, false);
            return;
        }

        // сетка 3x3
        int gx = x0;
        int gy = top + 68;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) slotBox(ctx, gx + c * 19, gy + r * 19, ItemStack.EMPTY);
        }
        List<Ingredient> ings = recipe.getIngredients();
        int width = recipe instanceof ShapedRecipe sr ? sr.getWidth() : 3;
        for (int i = 0; i < ings.size(); i++) {
            ItemStack[] options = ings.get(i).getMatchingStacks();
            if (options.length == 0) continue;
            ItemStack shown = options[(int) ((Util.getMeasuringTimeMs() / 1000L) % options.length)];
            int col = i % width;
            int row = i / width;
            if (col > 2 || row > 2) continue;
            slotBox(ctx, gx + col * 19, gy + row * 19, shown);
        }

        // стрелка и результат
        ctx.drawText(this.textRenderer, Text.literal("->"), gx + 3 * 19 + 8, gy + 24, COLOR_TEXT, false);
        slotBox(ctx, gx + 3 * 19 + 32, gy + 19, result);

        boolean can = this.client != null && this.client.player != null && CraftCatalog.canCraft(this.client.player, recipe);
        if (!can) {
            ctx.drawText(this.textRenderer, Text.translatable("message.arcane.craft_missing"),
                    x0, top + H - 66, 0xFFFF6060, false);
        }
    }

    private void renderCosmetics(DrawContext ctx, int mouseX, int mouseY) {
        Form sel = selectedForm();
        Form own = formByKey(ClientCosmetics.character());

        // сетка персонажей: по ячейке на каждого
        for (int i = 0; i < CHARACTERS.length; i++) {
            Form f = CHARACTERS[i];
            int x = cellX(i);
            int y = cellY(i);
            boolean hover = mouseX >= x && mouseX < x + 50 && mouseY >= y && mouseY < y + 50;
            int border = f == sel ? 0xFFFFD060 : (hover ? 0xFFB0B0C0 : 0xFF555560);
            ctx.fill(x, y, x + 50, y + 50, border);
            ctx.fill(x + 1, y + 1, x + 49, y + 49, hover ? 0xFF25252F : 0xFF181820);

            ctx.getMatrices().push();
            ctx.getMatrices().translate(x + 9, y + 4, 0.0f);
            ctx.getMatrices().scale(2.0f, 2.0f, 1.0f);
            ctx.drawItem(new ItemStack(iconOf(f)), 0, 0);
            ctx.getMatrices().pop();

            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("character.arcane." + f.key),
                    x + 25, y + 39, COLOR_TEXT);

            int total = 0;
            int have = 0;
            for (Cosmetics.Def d : Cosmetics.ALL) {
                if (d.form != f) continue;
                total++;
                if (ClientCosmetics.owns(d.id)) have++;
            }
            if (total > 0) {
                ctx.drawText(this.textRenderer, Text.literal(have + "/" + total), x + 3, y + 3,
                        have > 0 ? 0xFF7BE08A : COLOR_DIM, false);
            }
            if (f == own) {
                ctx.drawText(this.textRenderer, Text.literal("*"), x + 42, y + 3, COLOR_GOLD, false);
            }
        }
        // подпись над сеткой: девять персонажей - "Совет 9"
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.council"), left + 10, top + 33, COLOR_GOLD, false);
        ctx.fill(left + 10 + this.textRenderer.getWidth(Text.translatable("screen.arcane.council")) + 4, top + 37,
                left + 10 + 3 * 54 - 4, top + 38, 0xFF555560);
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.own_mark"), left + 10, top + 46 + 3 * 54 + 2, COLOR_DIM, false);

        // стрелка к будущим девяти: "Всадники тьмы"
        renderRidersArrow(ctx);

        // предпросмотр: игрок в форме выбранного персонажа с надетыми аксессуарами
        int bx = left + 176;
        ctx.fill(bx, top + 46, bx + 100, top + 208, 0xFF14141C);
        if (this.client != null && this.client.player != null) {
            StringBuilder faceBuilder = new StringBuilder();
            for (Cosmetics.Def d : Cosmetics.ALL) {
                if (d.form == sel && ClientCosmetics.worn(d.id)) {
                    if (faceBuilder.length() > 0) faceBuilder.append(',');
                    faceBuilder.append(d.id);
                }
            }
            String face = faceBuilder.toString();
            java.util.UUID id = this.client.player.getUuid();
            ClientForms.setPreview(id, sel.id);
            ClientCosmetics.setPreview(id, face);
            try {
                int px = bx + 50;
                int py = top + 196;
                InventoryScreen.drawEntity(ctx, px, py, 55, (float) (px - mouseX), (float) (py - 80 - mouseY), this.client.player);
            } finally {
                ClientForms.clearPreview();
                ClientCosmetics.clearPreview();
            }
        }
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.preview"), bx + 4, top + 50, COLOR_DIM, false);

        // правая колонка: аксессуары выбранного персонажа
        int x0 = RIGHT_X();
        ctx.drawText(this.textRenderer, Text.translatable("character.arcane." + sel.key), x0, top + 38, COLOR_GOLD, false);
        Cosmetics.Slot slot = slotFor(sel);
        ctx.drawText(this.textRenderer, Text.translatable(slot.langKey()), x0, top + 52, COLOR_TEXT, false);
        ItemStack wornFace = ItemStack.EMPTY;
        for (Cosmetics.Def d : Cosmetics.ALL) {
            if (d.slot == slot && d.form == sel && ClientCosmetics.worn(d.id)) wornFace = new ItemStack(d.item());
        }
        slotBox(ctx, x0 + 40, top + 47, wornFace);
        ctx.drawText(this.textRenderer, wornFace.isEmpty() ? Text.translatable("screen.arcane.slot_empty") : wornFace.getName(),
                x0 + 62, top + 52, COLOR_DIM, false);
        ctx.fill(x0, top + 74, x0 + 124, top + 75, 0xFF555560);

        int row = 0;
        for (Cosmetics.Def def : Cosmetics.ALL) {
            if (def.form != sel) continue;
            ItemStack stack = new ItemStack(def.item());
            boolean owned = ClientCosmetics.owns(def.id);
            int y = top + 82 + row * 46;
            slotBox(ctx, x0, y, stack);
            // редкость "Аркана" - название фиолетовым, как у эпических предметов
            Text itemName = def.arcane ? stack.getName().copy().formatted(net.minecraft.util.Formatting.LIGHT_PURPLE) : stack.getName();
            ctx.drawText(this.textRenderer, itemName, x0 + 24, y + 1, owned ? COLOR_TEXT : COLOR_DIM, false);
            if (!owned && def.hintKey != null) {
                String hint = this.textRenderer.trimToWidth(Text.translatable(def.hintKey).getString(), 98);
                ctx.drawText(this.textRenderer, hint, x0 + 24, y + 11, COLOR_GOLD, false);
            } else {
                ctx.drawText(this.textRenderer, Text.translatable("tooltip.arcane.cosmetic.slot", Text.translatable(def.slot.langKey())),
                        x0 + 24, y + 11, COLOR_DIM, false);
            }
            row++;
            if (row >= 3) break;
        }

        int y = top + 82 + Math.max(row, 1) * 46;
        if (row == 0) {
            drawWrapped(ctx, Text.translatable("screen.arcane.no_cosmetics"), x0, top + 84, 124);
        } else {
            drawWrapped(ctx, Text.translatable("screen.arcane.transform_only"), x0, y - 2, 124);
        }
    }

    /** Стрелка вниз-вправо от "Совета 9" к будущим девяти персонажам с другой механикой (НПС вместо способностей). */
    private void renderRidersArrow(DrawContext ctx) {
        int color = 0xFF8A2030;
        int x = left + 14;
        int y = top + 46 + 3 * 54 + 14;
        // древко и наконечник стрелки (рисуем прямоугольниками)
        ctx.fill(x, y + 3, x + 34, y + 5, color);
        ctx.fill(x + 34, y, x + 36, y + 8, color);
        ctx.fill(x + 36, y + 1, x + 38, y + 7, color);
        ctx.fill(x + 38, y + 2, x + 40, y + 6, color);
        ctx.fill(x + 40, y + 3, x + 42, y + 5, color);
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.riders"), x + 48, y, 0xFFE0506A, false);
        ctx.drawText(this.textRenderer, Text.translatable("screen.arcane.riders_soon"), x + 48, y + 10, COLOR_DIM, false);
    }

    private void drawWrapped(DrawContext ctx, Text text, int x, int y, int width) {
        for (net.minecraft.text.OrderedText line : this.textRenderer.wrapLines(text, width)) {
            ctx.drawText(this.textRenderer, line, x, y, COLOR_DIM, false);
            y += 10;
        }
    }
}

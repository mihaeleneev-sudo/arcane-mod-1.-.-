package com.arcane.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Шкала концентрации Раздора (слева внизу экрана). При слиянии показывает оставшееся время. */
public final class DiscordHud {
    private static final int BAR_W = 100;
    private static int meter = -1;       // -1: проклятия нет
    private static int mergeLeft = -1;   // тиков до конца слияния, -1: нет слияния
    private static boolean summoned = false;

    private DiscordHud() {}

    public static void set(int m, int merge, boolean here) {
        meter = m;
        mergeLeft = merge;
        summoned = here;
    }

    public static void clear() {
        meter = -1;
        mergeLeft = -1;
        summoned = false;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (meter < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int x = 10;
        int y = mc.getWindow().getScaledHeight() - 58;

        boolean merged = mergeLeft >= 0;
        Text title = merged
                ? Text.translatable("hud.arcane.discord_merged", (mergeLeft + 19) / 20)
                : Text.translatable("hud.arcane.discord_meter").append(Text.literal(" " + meter + "/100"));
        int titleColor = merged ? 0xFFE0A0FF : (summoned ? 0xFFC890F0 : 0xFF8A7A9A);
        ctx.drawTextWithShadow(mc.textRenderer, title, x, y - 11, titleColor);

        ctx.fill(x - 1, y - 1, x + BAR_W + 1, y + 9, 0xCC000000);
        int value = merged ? 100 * mergeLeft / 400 : meter;
        int fill = BAR_W * Math.max(0, Math.min(100, value)) / 100;
        int body = merged ? 0xFFB040E0 : (meter >= 100 ? 0xFFA030D0 : 0xFF6A2A9A);
        ctx.fill(x, y, x + fill, y + 8, body);
        ctx.fill(x, y, x + fill, y + 2, merged ? 0xFFE090FF : 0xFFB070E0);
    }
}

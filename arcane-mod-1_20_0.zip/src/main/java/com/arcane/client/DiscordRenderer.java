package com.arcane.client;

import com.arcane.DiscordEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Раздор: фигура в ромбах арлекина, чуть горбатая (наклонена вперёд). Текстура textures/entity/discord.png (64x64). */
public class DiscordRenderer extends BipedEntityRenderer<DiscordEntity, PlayerEntityModel<DiscordEntity>> {
    private static final Identifier TEXTURE = new Identifier("arcane", "textures/entity/discord.png");

    public DiscordRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(DiscordEntity entity) {
        return TEXTURE;
    }

    /** Горб: всё тело наклонено вперёд от стоп. */
    @Override
    protected void setupTransforms(DiscordEntity entity, MatrixStack matrices, float animationProgress, float bodyYaw, float tickDelta) {
        super.setupTransforms(entity, matrices, animationProgress, bodyYaw, tickDelta);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-14.0f));
    }

    @Override
    protected void scale(DiscordEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.05f, 1.05f, 1.05f);
    }
}
